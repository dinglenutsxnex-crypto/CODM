var Consumable=(function(){function Consumable(settings){if(!Check.IDInRange(settings.ID,consumablesIDRange)){throw new Error("ID ("+settings.ID+") \u0440\u0430\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u043B\u0435\u0436\u0430\u0442\u044C \u0432 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0435 "+consumablesIDRange[0]+" - "+consumablesIDRange[1]+".");}
for(var key in settings)
this[key]=settings[key];}
return Consumable;}());