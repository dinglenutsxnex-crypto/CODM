var __assign=(this&&this.__assign)||Object.assign||function(t){for(var s,i=1,n=arguments.length;i<n;i++){s=arguments[i];for(var p in s)if(Object.prototype.hasOwnProperty.call(s,p))
t[p]=s[p];}
return t;};var Consumables=__assign({},ActiveConsumables,PassiveConsumables);var ConsumablesMap=createIDMap(Consumables);function createConsumableCollection(arrayID){var collection={};arrayID.forEach(function(ID){var rarity=ConsumablesMap.get(ID).rarity;if(collection[rarity]){collection[rarity].push(ID);}
else{collection[rarity]=[ID];}});return collection;}
var ConsumableCollection=createConsumableCollection(ConsumablesMap.getKeys());