var PromoApiHelper=(function(){function PromoApiHelper(){}
PromoApiHelper.createPlayerPromosMap=function(promos){var result={};for(var _i=0,promos_1=promos;_i<promos_1.length;_i++){var promo=promos_1[_i];result[promo.id]=promo;}
return result;};PromoApiHelper.getAllPromos=function(promoBelonging,type,abTag){var result=[];for(var i=0;i<promoBelonging.length;i++){var belonging=promoBelonging[i];var listOfPromos=[];var dictOfPromos=Promo.allPromos[belonging][type]?Promo.allPromos[belonging][type]:{};for(var _i=0,_a=Object.keys(dictOfPromos);_i<_a.length;_i++){var promoId=_a[_i];if(abTag in dictOfPromos[promoId]){listOfPromos.push(dictOfPromos[promoId][abTag]);}
else if("main"in dictOfPromos[promoId]){listOfPromos.push(dictOfPromos[promoId]["main"]);}}
result=result.concat(listOfPromos);}
return result;};return PromoApiHelper;}());var PlayerPromoArg=(function(){function PlayerPromoArg(arg){this.id=arg.id;this.finishDate=arg.finishDate;this.totalPurchaseCnt=arg.totalPurchaseCnt;}
return PlayerPromoArg;}());function getPromos(playerState,promoTypesToBelonings){var state=new GetPromosPlayerState(playerState);checkCriticalUndef(PromoMap,"getPromos","PromoMap");if(QA_TOOLS&&QA_NO_PROMO_GENERATION&&QA_NO_MARATHON_GENERATION)
return{promosID:[],gachaPromosID:[],boardPromosID:[],points:state.points?state.points:0};var pInf=new PlayerInfo(playerState.pInf,{level:getLevelByMainBattle(playerState.pInf.mainBattleID,playerState.pInf.level)});var playerDan=(playerState.currentRating)?getDanByRating(getReslRating(playerState.currentRating)):1;var lastPromoRecord=null;for(var _i=0,_a=state.playerPromos;_i<_a.length;_i++){var promo=_a[_i];if((!lastPromoRecord||lastPromoRecord.finishDate<promo.finishDate)&&promo.totalPurchaseCnt)
lastPromoRecord=promo;}
var lastPromo=lastPromoRecord?PromoMap.get(lastPromoRecord.id):null;function filterExpiredPromos(promos){var filtred=[];var filterGroup={};for(var selectPromo in promos){var promo=PromoMap.get(promos[selectPromo].id);if(promo){if(promo.pointsGroup){if(filterGroup[promo.pointsGroup]){filterGroup[promo.pointsGroup].push(promos[selectPromo]);}
else{filterGroup[promo.pointsGroup]=[promos[selectPromo]];}}
else if(promos[selectPromo].totalPurchaseCnt==0)
filtred.push(promos[selectPromo]);}}
for(var selectFilterGroup in filterGroup){var pointGroup=filterGroup[selectFilterGroup];for(var i=0;i<pointGroup.length;i++){if(pointGroup[i].totalPurchaseCnt>0){break;}
if(pointGroup.length==(i+1)){filtred.push(pointGroup[i]);}}}
return filtred;}
function getPlayerCohort(playerPoints){for(var cohort in PromoCohorts){if(PromoCohorts[cohort].minPoint<=playerPoints&&PromoCohorts[cohort].maxPoint>=playerPoints)
return PromoCohorts[cohort];}}
function calcPoints(promos,playerPoints){var expiredPromos=[];var playerCohort=getPlayerCohort(playerPoints);for(var selectPromo in promos){var promo=promos[selectPromo];if(promo.finishDate>state.invokeTime&&promo.finishDate<=state.currentTime){expiredPromos.push(promo);}}
expiredPromos=filterExpiredPromos(expiredPromos);for(var selectPromo in expiredPromos){var promo=PromoMap.get(expiredPromos[selectPromo].id);if(playerPoints>0&&promo&&InAppPurchaseMap.get(promo.inApp)){var firstInApp=InAppPurchaseMap.get(promo.inApp[0]);if(firstInApp.points){var ignoreInApp=false;if(firstInApp.noExpireInCohorts){for(var cohort in firstInApp.noExpireInCohorts){if(firstInApp.noExpireInCohorts[cohort]==playerCohort)
ignoreInApp=true;}}
playerPoints=(playerPoints>firstInApp.points.expirePoints&&!ignoreInApp)?(playerPoints+firstInApp.points.expirePoints):0;}}}
return playerPoints;}
function promosToProductGroups(playerPromos){if(playerPromos===void 0){playerPromos=[];}
var result=[];for(var _i=0,playerPromos_1=playerPromos;_i<playerPromos_1.length;_i++){var playerPromo=playerPromos_1[_i];var promoModel=PromoMap.get(playerPromo.id);if(promoModel&&promoModel.productGroup&&result.indexOf(promoModel.productGroup)<0){result.push(promoModel.productGroup);}}
return result;}
function checkPromoCollection(promo,playerLevel,rawObjInventory){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var selected=CollectionCalculate.selectCollectionsByConditions(objInventory,promo.collectionCondition);return!!selected.collectionIDs.length;}
function hasPromo(playerPromos,promo){if(promo.eraseOnExpire){return false;}
if(playerPromos[promo.ID]){return true;}
else{return false;}}
function hasGachaPromo(playerGachaGames,promo){return promo.gachaGame&&playerGachaGames[promo.gachaGame]!==undefined;}
function hasBoardPromo(playerBoardGames,promo){return promo.boardGame&&playerBoardGames[promo.boardGame]!==undefined;}
function getPromo(playerPromos,id){for(var _i=0,playerPromos_2=playerPromos;_i<playerPromos_2.length;_i++){var promo=playerPromos_2[_i];if(promo.id==id)
return promo;}
return null;}
function passFilterBySpecificPromo(promo,mainBattleId,productIds,battleStats,playerDan){var promoType=promo.type;if(promo.dan){promoType=PromoType.DAN_REACHED;}
switch(promoType){case PromoType.BATTLE_LOSE:return false;case PromoType.SERIAL:return true;case PromoType.DAN_REACHED:case PromoType.SEASON_END:var promoDan=checkNotNull(promo.dan,"promo="+promo.ID+" type="+promoType+" dan is null");return promoDan.indexOf(playerDan)>-1;default:return true;}}
function isIntersectedByProductGroup(promo,usedProductGroups){if(promo.productGroup==null)
return false;return usedProductGroups.indexOf(promo.productGroup)>-1;}
function filterByCountryCode(countryCode,filteredPromos){var result=[];for(var _i=0,filteredPromos_1=filteredPromos;_i<filteredPromos_1.length;_i++){var promo=filteredPromos_1[_i];if(!!promo.countries&&promo.countries.length>0){if(!!countryCode&&promo.countries.indexOf(countryCode)>-1){result.push(promo);}}
else{result.push(promo);}}
return result;}
function toIds(promos){var result=[];for(var _i=0,promos_2=promos;_i<promos_2.length;_i++){var promo=promos_2[_i];result.push(promo.ID);}
return result;}
function isSubMarathon(id){return Object.keys(SubsOfferQuestPromos).some(function(x){return SubsOfferQuestPromos[x].ID==id;});}
function getCurrentSubsMarathonID(){if(subRestrictPlatforms.indexOf(state.platform)>-1){return-1;}
var sortedMarathons=SubsOfferQuestPromoSortingOrder;var promos=sortedMarathons.map(function(x){return PromoMap.get(x);});var tempArr=[];for(var index in sortedMarathons){if(ConditionChecker.checks.mainBattleID(promos[index].conditions,state)){tempArr.push(sortedMarathons[index]);}}
sortedMarathons=tempArr;var intervals=sortedMarathons.map(function(x){return PromoMap.get(x).duration;});var fullCycleTime=intervals.reduce(function(a,b){return a+b;},0);var helperPromo=getPromo(state.playerPromos,SpecialPromos.SUBSCRIPTION_MARATHON_HELPER.ID);if(helperPromo){var milestone=helperPromo.finishDate+Math.floor(Math.max(state.currentTime-helperPromo.finishDate,0)/fullCycleTime)*fullCycleTime;for(var index in intervals){milestone+=intervals[index];if(milestone>state.currentTime)
return sortedMarathons[index];}}
return sortedMarathons[0];}
var result=[];var gachaPromos=[];var boardPromos=[];var allPlayerPromos=PromoApiHelper.createPlayerPromosMap(playerState.playerPromos);var allGachaGames=PromoApiHelper.createPlayerPromosMap(playerState.playerGachaGames);var allBoardGames=PromoApiHelper.createPlayerPromosMap(playerState.playerBoardGames);var resultPoints=calcPoints(state.playerPromos,state.points);for(var promoType in promoTypesToBelonings){checkArgument(PromoType[promoType]!=null&&+promoType!=PromoType.UNKNOWN_PROMO_TYPE,"invalid promo type: "+promoType);var allPromos=PromoApiHelper.getAllPromos(promoTypesToBelonings[promoType],+promoType,playerState.abTag);var usedProductGroups=promosToProductGroups(state.playerPromos);for(var _b=0,allPromos_1=allPromos;_b<allPromos_1.length;_b++){var promo=allPromos_1[_b];if(!promo.enable)
continue;if(promo.type!=+promoType)
continue;if(hasPromo(allPlayerPromos,promo))
continue;if(hasGachaPromo(allGachaGames,promo))
continue;if(hasBoardPromo(allBoardGames,promo))
continue;if(!promo.inGenerationTimeRange(playerState.currentTime))
continue;if(!promo.inSumOfPaymentsRange(playerState.sumOfPayments,playerState.platform))
continue;if(!promo.inPointsRange(playerState.points,playerState.platform))
continue;if(!passFilterBySpecificPromo(promo,pInf.mainBattleID,playerState.playerProductIds,playerState.battleStats,playerDan))
continue;if(isIntersectedByProductGroup(promo,usedProductGroups)){continue;}
if(!!promo.isSubPromo&&!state.subscribed)
continue;if(!promo.isTriggeredByLastPromo(lastPromo))
continue;if(!promo.isParentMarathonCompleted(state.marathonProgresses))
continue;if(isSubMarathon(promo.ID)&&promo.ID!=getCurrentSubsMarathonID())
continue;if(!ConditionChecker.checkConditions(promo.conditions,state))
continue;if(!!promo.collectionCondition){if(!checkPromoCollection(promo,pInf.level,state.objInventory))
continue;}
if(promo.productGroup!=null)
usedProductGroups.push(promo.productGroup);if(promo.gachaGame){gachaPromos.push(promo);}
else if(promo.boardGame){boardPromos.push(promo);}
else{result.push(promo);}}}
result=filterByCountryCode(state.countryCode,result);gachaPromos=filterByCountryCode(state.countryCode,gachaPromos);return{promosID:toIds(result),gachaPromosID:toIds(gachaPromos),boardPromosID:toIds(boardPromos),points:resultPoints};}
var GameUpdateType;(function(GameUpdateType){GameUpdateType[GameUpdateType["Config"]=0]="Config";GameUpdateType[GameUpdateType["Client"]=1]="Client";})(GameUpdateType||(GameUpdateType={}));function getGameUpdatePromo(playerInfo,oldVersion,newVersion,updateType){var newPlayerVersion=new Version(newVersion);var oldPlayerVersion=new Version(oldVersion);var state=new GetPromosPlayerState({pInf:playerInfo});switch(updateType){case GameUpdateType.Config:var arrayOfPromo=PromoMap.getKeys().map(function(ID){return PromoMap.get(ID);});var configUpdatePromo=arrayOfPromo.filter(function(promo){return promo.type===PromoType.GAME_UPDATE_GIFT&&promo.updateVersion&&promo.updateVersion.moreOrEqualTo(ConfigWhiteListForVersions.firstVersion)&&promo.updateVersion.lessOrEqualTo(ConfigWhiteListForVersions.lastVersion)&&promo.updateVersion.isNewForPlayer(oldPlayerVersion,newPlayerVersion)&&ConditionChecker.checks.mainBattleID(promo.conditions,state);})[0];return(configUpdatePromo&&configUpdatePromo.ID)?configUpdatePromo.ID:null;default:return null;}}
function migratePromos(promos,now,oldVersionRaw,currentVersionRaw,points,sumOfPayments){var oldVersion=new Version(oldVersionRaw);var currentVersion=new Version(currentVersionRaw);var result=[];var timeToEraseOldPromo=new Date(now);timeToEraseOldPromo.setMonth(timeToEraseOldPromo.getMonth()-promoStorageTimeInMonths);var pointsResult=points?points:0;if(sumOfPayments){if(oldVersion.lessThan(new Version("1.21.0.9"))&&currentVersion.moreOrEqualTo(new Version("1.21.0.9"))){if(sumOfPayments<4.99){pointsResult=Math.round(sumOfPayments*20-5);}
if((sumOfPayments>=4.99)&&(sumOfPayments<149.99)){pointsResult=Math.round((sumOfPayments*80+2500)/29-5);}
if(sumOfPayments>=149.99){pointsResult=Math.round(sumOfPayments*5-255);}}}
for(var _i=0,promos_3=promos;_i<promos_3.length;_i++){var arg=promos_3[_i];var promo=new PlayerPromoArg(arg);var promoModel=PromoMap.get(promo.id);if((promo.finishDate>timeToEraseOldPromo.getTime())||(promoModel&&promoModel.migrationDisabled)){result.push(promo);}}
pointsResult=pointsResult?Math.max(0,pointsResult):0;return{promos:result,points:pointsResult};}
function getPopUp(trigger,shownPopUpGroups,playerActivePromos,gridPromoPurchasedInAppsNumber,playerInfo){for(var currentPromo in playerActivePromos){var promo=PromoMap.get(playerActivePromos[currentPromo]);if(promo&&promo.popUpSettings&&promo.popUpSettings.trigger==trigger&&shownPopUpGroups.indexOf(promo.popUpSettings.popUpGroup)==-1){var unskippable=(promo.popUpSettings.unskippable)?promo.popUpSettings.unskippable:0;return{promoId:promo.ID,localGroup:promo.popUpSettings.popUpGroup,unskippable:unskippable};}}
return{promoId:-1,localGroup:-1,unskippable:0};}
function getPromoMap(abTag){if(abTag===null||ABPromos[abTag]===undefined||getABPromos(abTag)===null){return PromoMap;}
return OrderMap.merge(PromoMap,ABPromoMap[abTag]);}