var PlayerInfo=(function(){function PlayerInfo(playerInfo,override){for(var key in playerInfo){this[key]=playerInfo[key];}
if(override){for(var key in override){this[key]=override[key];}}}
return PlayerInfo;}());