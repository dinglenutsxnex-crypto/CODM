function getClanDefault(){return ClanDefault;}
function getClanCreationPrice(){return ClanCreationPrice;}
function getClanDefaultRole(){return ClanPlayerDefaultRole;}
function getClanRolePermissions(Role){return ClanRolePermissions[Role];}
function getClanRoleData(){return ClanRoleData;}
function getPlayerBestItemsPower(playerLevel,equipment){var bestItems=calcBestItems(playerLevel,equipment,EventItemsIDs);var bestItemsPower=Object.keys(bestItems).map(function(ID){return calcVisibleItemPower(bestItems[ID].SL,Number(bestItems[ID].Item.ID));});return bestItemsPower.reduce(function(powerSum,power,index){return powerSum+power;},0);}
function getClanJoinAllowedDate(lastLeaveDates){if(!lastLeaveDates||!lastLeaveDates.length||!lastLeaveDates[0])
return-1;var lastNDays=lastLeaveDates[0]-ClanLeaveCooldownInterval;var counter=0;for(var _i=0,lastLeaveDates_1=lastLeaveDates;_i<lastLeaveDates_1.length;_i++){var leaveTimeStamp=lastLeaveDates_1[_i];if(leaveTimeStamp!=null&&leaveTimeStamp>lastNDays){counter++;}}
return lastLeaveDates[0]+ClanLeavePunishment[counter];}
function getPlayerLadderRewards(playerInfo,playerPlace,playerContribution,clanCycle,clanPlace){var clanCycleId=QA_TOOLS&&QA_CLAN_CYCLE_ACTIVE?QA_CLAN_CYCLE_ID:clanCycle;var reward=new Loot();var normalizedClanPlace=clanPlace>=0?clanPlace+1:100;reward.combine(ClanLadder.getGuaranteedRewards(playerInfo,normalizedClanPlace,clanCycleId));reward.combine(ClanLadder.getVariableReward(playerInfo,playerContribution,normalizedClanPlace,clanCycleId));return reward;}
function getClanLadderRewards(clanPlace,clanCycle){var clanCycleId=QA_TOOLS&&QA_CLAN_CYCLE_ACTIVE?QA_CLAN_CYCLE_ID:clanCycle;var reward=new Loot();return reward;}
function getEmblemPaletteDefault(){return EmblemPaletteDefault;}
function getClanEmblemElements(){return ClanEmblemsMap;}
function getEmblemPresets(){return ClanEmblemPresets;}
function getEmblemPalettes(){return EmblemPaletteMap;}
function getEmblemElementPrice(elementID){var price=AllEmblemsElementsMap.get(elementID).price;return price?price:0;}
function getDefaultEnemyClanBattleTemplate(){return DefaultEnemyClanBattleTemplate;}
function isEmblemUnlocked(emblemElementID,clanLevel){return AllEmblemsElementsMap.get(emblemElementID).unlockLevel<=clanLevel;}
function calculateClanBattleEntryPrice(battleID,playerLevel){var zone=getZoneByLevel(playerLevel);var battle=ClanBattlesMap.get(battleID);var coinPrice=new RoundedPriceCurrencies({COIN:calcCoinZoneInflation(battle.EventEntryCost.COIN,zone)});var price=new RoundedPriceCurrencies(battle.EventEntryCost);price.add(coinPrice);return price.toMap();}
function getClanBattleIDs(){return ClanOutpostBattlesIDs;}
function getClanLeaderboardRewards(clanCycle){var clanCycleId=QA_TOOLS&&QA_CLAN_CYCLE_ACTIVE?QA_CLAN_CYCLE_ID:clanCycle;var playerInfo=PlayerInfoForPostLootGeneration;var result={};var cycleGuaranteed=clanCycleId;var cycleContribution=clanCycleId;var lastCycleGuaranteed=Math.max.apply(Math,Object.keys(LadderGuaranteedRewards).map(Number));var lastCycleContribution=Math.max.apply(Math,Object.keys(LadderContributionRewards).map(Number));if(clanCycleId==undefined||clanCycleId<=0||!LadderGuaranteedRewards[clanCycleId]||!LadderContributionRewards[clanCycleId]){cycleGuaranteed=lastCycleGuaranteed;cycleContribution=lastCycleContribution;}
else{cycleGuaranteed=Math.min(cycleGuaranteed,lastCycleGuaranteed);cycleContribution=Math.min(cycleContribution,lastCycleContribution);}
Object.keys(LadderGuaranteedRewards[cycleGuaranteed]).forEach(function(key){var contributionKeys=Object.keys(LadderContributionRewards[cycleContribution][key]).map(Number);result[key]={guarantee:ClanLadder.getGuaranteedRewards(playerInfo,Number(key),cycleGuaranteed),min:ClanLadder.getVariableReward(playerInfo,Math.min.apply(Math,contributionKeys),Number(key),cycleContribution),max:ClanLadder.getVariableReward(playerInfo,Math.max.apply(Math,contributionKeys),Number(key),cycleContribution)};});return result;}
function getExperienceForClanLevel(level){if(level>=ClanMaxLevel)
return-1;return ClanLevelProgression[level+1].experience;}