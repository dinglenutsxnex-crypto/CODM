var OfferQuest=(function(){function OfferQuest(settings){this.Alias='Default marathon alias';this.Description='Default_marathon_description';this.HideMaxPoints=false;this.Icon='NativeUI/Sprites/Icons/survival';this.IconColor='2FBBD4';this.LockRewardForNotSubscribers=false;this.RandomItemReward=false;this.ID=settings.ID;if(settings.Alias){this.Alias=settings.Alias;}
if(settings.Description){this.Description=settings.Description;}
if(settings.EventID){this.EventID=settings.EventID;}
if(settings.EventPromoCodes){this.EventPromoCodes=settings.EventPromoCodes;}
if(settings.HideMaxPoints){this.HideMaxPoints=settings.HideMaxPoints;}
if(settings.Icon){this.Icon=settings.Icon;}
if(settings.IconColor){this.IconColor=settings.IconColor;}
if(settings.IsUnlimitedMarathon){this.IsUnlimitedMarathon=settings.IsUnlimitedMarathon;}
if(settings.LockRewardForNotSubscribers){this.LockRewardForNotSubscribers=settings.LockRewardForNotSubscribers;}
if(settings.MarathonGroup){this.MarathonGroup=settings.MarathonGroup;}
if(settings.MarathonGroup&&settings.MarathonGroup.IsInitialMarathon){OfferQuest.MarathonGroups[settings.ID]=[settings.ID];}
if(settings.MaxProgress){this.MaxProgress=settings.MaxProgress;}
else{this.MaxProgress=this.getMaximumProgress(settings.Reward);}
this.Quest=settings.Quest;if(settings.RandomItemReward){this.RandomItemReward=settings.RandomItemReward;}
this.Reward={1:settings.Reward};this.SortingOrder=settings.SortingOrder;}
OfferQuest.prototype.fillMarathonGroup=function(initialMarathon){var group=OfferQuest.MarathonGroups[initialMarathon.ID];var partOfGroup=initialMarathon;while(partOfGroup.MarathonGroup){partOfGroup=OfferQuestMap.get(partOfGroup.MarathonGroup.NextMarathonID);group.push(partOfGroup.ID);}};OfferQuest.prototype.getMaximumProgress=function(rewards){return Math.max.apply(Math,Object.keys(rewards).map(function(points){return Number(points);}));};OfferQuest.fillMarathonGroups=function(){var arrayOfID=OfferQuestMap.getKeys();for(var _i=0,arrayOfID_1=arrayOfID;_i<arrayOfID_1.length;_i++){var ID=arrayOfID_1[_i];var marathon=OfferQuestMap.get(ID);if(marathon.MarathonGroup&&marathon.MarathonGroup.IsInitialMarathon){marathon.fillMarathonGroup(marathon);}}};OfferQuest.MarathonGroups={};return OfferQuest;}());