var ItemModel=(function(){function ItemModel(settings){for(var key in settings)
this[key]=settings[key];}
return ItemModel;}());