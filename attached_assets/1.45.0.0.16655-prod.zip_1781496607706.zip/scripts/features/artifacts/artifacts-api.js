function getArtifactAttributesFromInventory(inventory){var result=(_a={},_a[Attributes.PvP_ATTACK]=0,_a[Attributes.PvP_DEFENSE]=0,_a[Attributes.PvP_POWER]=0,_a);if(!inventory||!inventory.artifactSlots||!inventory.artifacts)
return result;var artifactsById={};for(var _i=0,_b=Object.keys(inventory.artifacts).map(function(x){return inventory.artifacts[x];});_i<_b.length;_i++){var a=_b[_i];artifactsById[a.id]=a;}
for(var slot in inventory.artifactSlots){var artifactId=inventory.artifactSlots[slot];var instance=artifactsById[artifactId];if(!instance)
continue;var attrs=ArtifactModel.getArtifactAttributesForLevel(artifactId,instance.level,{Battle:true,Visual:true,Ability:true,});result[Attributes.PvP_ATTACK]+=attrs[Attributes.PvP_ATTACK]||0;result[Attributes.PvP_DEFENSE]+=attrs[Attributes.PvP_DEFENSE]||0;result[Attributes.PvP_POWER]+=attrs[Attributes.PvP_POWER]||0;}
return result;var _a;}
function getArtifactAttributesBattle(artifactID,level,battleID,playerParameters){return ArtifactModel.getArtifactAttributesForLevel(artifactID,level,{Battle:true,Visual:false,Ability:false,});}
function getArtifactAttributesVisible(artifactID,level){var attributes=ArtifactModel.getArtifactAttributesForLevel(artifactID,level,{Battle:true,Visual:true,Ability:false,});return attributes;}
function getArtifactAttributesAbilityVisible(artifactID,level){var attributes=ArtifactModel.getArtifactAttributesForLevel(artifactID,level,{Battle:false,Visual:false,Ability:true,});return attributes;}
function getArtifactAttributesAbilityTriggers(artifactID,level){var attributes=ArtifactModel.getArtifactAttributesForLevel(artifactID,level,{Battle:false,Visual:false,Ability:true,ShowAbilityHidden:true,});return attributes;}
function getArtifactAttributeUIValues(artifactID,level){var attributes=getArtifactAttributesAbilityVisible(artifactID,level);var result=[];for(var _i=0,_a=Object.keys(attributes);_i<_a.length;_i++){var attribute=_a[_i];var value=attributes[attribute];var modifiedValue=EnhancementCalculate.attributeUIValue(attribute,value);result.push(modifiedValue.toString());}
return result;}
function getArtifactLastLevel(artifactId){var artifact=ArtifactsMap.checkedGet(artifactId);if(!artifact||!artifact.Leveling)
return 1;var subRarityMax=artifactMaxLevelBySubRarity[artifact.Rarity][artifact.SubRarity]||1;return Math.min(Math.max.apply(Math,Object.keys(artifact.Leveling).map(Number)),subRarityMax);}
function upgradeArtifact(artifactId,level){var nextLevel=level+1;return{nextLevel:nextLevel,cost:ArtifactModel.getArtifactUpgradeCost(artifactId,level)};}
function getArtifactTagsForLevel(artifactId,level){var artifact=ArtifactsMap.checkedGet(artifactId);if(!artifact||!artifact.Leveling)
return[];var levelSettings=artifact.Leveling[String(level)];if(!levelSettings||!levelSettings.Effects)
return[];var tags=[];for(var _i=0,_a=levelSettings.Effects;_i<_a.length;_i++){var effect=_a[_i];if(!effect.Tags)
continue;for(var _b=0,_c=effect.Tags;_b<_c.length;_b++){var tag=_c[_b];if(tags.indexOf(tag)===-1)
tags.push(tag);}}
return tags;}
function getArtifactCompensationCurrencies(artifactId){var artifact=ArtifactsMap.checkedGet(artifactId);if(!artifact)
return ArtifactDefaultCompensation;return ArtifactModel.getCompensationCurrencies(artifact);}