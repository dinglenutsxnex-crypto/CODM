var EnhancementCalculate;(function(EnhancementCalculate){function collection(source){var result=emptyCollection();var arrayID=source.getKeys();for(var _i=0,arrayID_1=arrayID;_i<arrayID_1.length;_i++){var ID=arrayID_1[_i];var enhancement=source.get(ID);if(enhancement.NoShop===1){continue;}
var minDropLevel=enhancement.MinDropZone?enhancement.MinDropZone.MinLevel:Zones.Zone1.MinLevel;var container=new CollectionObjectContainer(enhancement,1);result[enhancement.Rarity][enhancement.TargetFaction][minDropLevel].add(container);}
for(var _a=0,_b=[RARITY.COMMON,RARITY.RARE,RARITY.EPIC,RARITY.LEGENDARY];_a<_b.length;_a++){var rarity=_b[_a];for(var _c=0,_d=[FACTION.LEGION,FACTION.HERALDS,FACTION.DYNASTY];_c<_d.length;_c++){var faction=_d[_c];for(var level=1;level<=endgameZone.MaxLevel;level++){if(!result[rarity][faction][level]){result[rarity][faction][level]=result[rarity][faction][level-1];}
else if(result[rarity][faction][level-1]){result[rarity][faction][level].addAll(result[rarity][faction][level-1].list());}}}}
return result;}
EnhancementCalculate.collection=collection;function emptyCollection(){var result={};for(var _i=0,_a=[RARITY.COMMON,RARITY.RARE,RARITY.EPIC,RARITY.LEGENDARY];_i<_a.length;_i++){var rarity=_a[_i];result[rarity]={};for(var _b=0,_c=[FACTION.LEGION,FACTION.HERALDS,FACTION.DYNASTY];_b<_c.length;_b++){var faction=_c[_b];result[rarity][faction]={};for(var level in ZonesBaseLevelsMap){if(!ZonesBaseLevelsMap.hasOwnProperty(level)){continue;}
var zone=ZonesBaseLevelsMap[level];result[rarity][faction][zone.MinLevel]=new RandomCollection();}}}
return result;}
EnhancementCalculate.emptyCollection=emptyCollection;function equipmentsTags(source){var result=[];for(var ID in source){var item=ItemModelsMap.get(ID);item.Tags.forEach(function(tag){if(result.indexOf(tag)===-1){result.push(tag);}});}
return result;}
EnhancementCalculate.equipmentsTags=equipmentsTags;function perkWarriorLists(){var result={};for(var _i=0,_a=[FACTION.LEGION,FACTION.HERALDS,FACTION.DYNASTY];_i<_a.length;_i++){var faction=_a[_i];result[faction]={};for(var _b=0,_c=[ITEMTYPE.HELMET,ITEMTYPE.ARMOR,ITEMTYPE.WEAPON];_b<_c.length;_b++){var itemType=_c[_b];result[faction][itemType]={};for(var _d=0,_e=[RARITY.COMMON,RARITY.RARE,RARITY.EPIC,RARITY.LEGENDARY];_d<_e.length;_d++){var rarity=_e[_d];result[faction][itemType][rarity]=[];}}}
var arrayID=PerksMap.getKeys();for(var _f=0,arrayID_2=arrayID;_f<arrayID_2.length;_f++){var ID=arrayID_2[_f];var perk=PerksMap.get(ID);if(!perk.NoShop){result[perk.TargetFaction][perk.TargetItemType][perk.Rarity].push(perk.ID);}}
return result;}
EnhancementCalculate.perkWarriorLists=perkWarriorLists;function mismatchedTag(value,restParameters){var equipmentsTags=EnhancementCalculate.equipmentsTags(restParameters[0]);var superMove=value.get();for(var _i=0,_a=superMove.TargetTag;_i<_a.length;_i++){var tag=_a[_i];if(equipmentsTags.indexOf(tag)===-1)
return true;}
return false;}
EnhancementCalculate.mismatchedTag=mismatchedTag;function playerAlreadyHas(value,restParameters){var playerEnhancements=restParameters[0];var superMove=value.get();if(playerEnhancements[superMove.ID]){return true;}
return false;}
EnhancementCalculate.playerAlreadyHas=playerAlreadyHas;})(EnhancementCalculate||(EnhancementCalculate={}));