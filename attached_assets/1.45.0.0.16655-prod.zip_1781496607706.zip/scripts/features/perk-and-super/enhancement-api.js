function calcVisibleEnhancementPower(enhancementsArray){var result=0;for(var _i=0,enhancementsArray_1=enhancementsArray;_i<enhancementsArray_1.length;_i++){var enhancement=enhancementsArray_1[_i];result+=EnhancementCalculate.powerForPlayer(enhancement.ModelID,enhancement.SL);}
return result;}
function getEnhancementLastStackLevel(enhancementID){var enhancement=PerkModelsMap.get(enhancementID);return enhancement.LastLevelStackLevel;}
function getEnhancementLevel(enhancementID,stackLevel){var enhancement=PerkModelsMap.get(enhancementID);return enhancement.getLevel(stackLevel);}
function getEnhancementStackLevel(level){return Enhancement.getStackLevel(level);}
function getEnhancementPower(enhancementID,stackLevel){return EnhancementCalculate.powerForPlayer(enhancementID,stackLevel);}
function getEnhancementSlots(modelID){var model=ItemModelsMap.get(modelID);return EnhancementCalculate.slots(model.Rarity,model.ItemType);}
function getArtifactsEnhancementSlots(modelID){var model=ArtifactsMap.get(modelID);return EnhancementCalculate.artifactSlots(model.Rarity,model.Type);}
function getPerkTypeRestrictions(){return _a={},_a[EnchantmentType.Perk]=3,_a[EnchantmentType.SuperMove]=1,_a;var _a;}
function getSuperMoveRarity(stackLevel){var numberLevel=EnhancementCalculate.levelByStackLevel(stackLevel);var lastRarity;for(var rarity in superMoveUpgradeCost){lastRarity=rarity;if(superMoveUpgradeCost[rarity][numberLevel]){return Number(rarity);}}
return Number(lastRarity);}
function upgradeEnhancement(enhancementID,stackLevel){var enhancement=PerkModelsMap.get(enhancementID);var nextStackLevel=stackLevel+enhancementStackLevelStep;return{nextStackLevel:nextStackLevel,cost:enhancement.getUpgradeCost(stackLevel,nextStackLevel).toMap()};}