var Check;(function(Check){function activeFromSort(array){array.sort(function(a,b){return a.activeFrom.getTime()-b.activeFrom.getTime();});}
Check.activeFromSort=activeFromSort;function IDInRange(ID,range){return range[0]<=ID&&ID<range[1];}
Check.IDInRange=IDInRange;function scheduleIntersection(array,instance){function hasIntersection(firstObject,secondObject){return Check.timelineIntersection(firstObject.activeTo,secondObject.activeFrom)&&(Check.cohortsIntersection(firstObject.cohorts,secondObject.cohorts)||Check.spRangeIntersection(firstObject.spRange,secondObject.spRange));}
Check.activeFromSort(array);for(var i=0;i<array.length-1;i++)
for(var j=i+1;j<array.length;j++)
if(hasIntersection(array[i],array[j]))
throw new Error("Intersection in "+instance+" schedule: "+array[i].ID+" and "+array[j].ID+". Please check activeFrom, activeTo, cohorts, spRange fields.");}
Check.scheduleIntersection=scheduleIntersection;function timelineIntersection(to,from){return to>from;}
Check.timelineIntersection=timelineIntersection;function cohortsIntersection(firstCohorts,secondCohorts){function hasIntersection(firstCohort,secondCohort){return(firstCohort.minPoint===secondCohort.minPoint)&&(firstCohort.maxPoint===secondCohort.maxPoint);}
if(firstCohorts===undefined||secondCohorts===undefined)
return true;for(var i=0;i<firstCohorts.length;i++)
for(var j=0;j<secondCohorts.length;j++)
if(hasIntersection(firstCohorts[i],secondCohorts[j]))
return true;return false;}
Check.cohortsIntersection=cohortsIntersection;function spRangeIntersection(firstSpRange,secondSpRange){function getCorrectedRange(range){return new MinMaxValue(range.MinValue===-1?Number.NEGATIVE_INFINITY:range.MinValue,range.MaxValue===-1?Number.POSITIVE_INFINITY:range.MaxValue);}
var first=getCorrectedRange(firstSpRange);var second=getCorrectedRange(secondSpRange);switch(first.MinValue<=second.MinValue){case true:if(first.MaxValue>=second.MinValue)
return true;break;case false:if(first.MinValue<=second.MaxValue)
return true;}
return false;}
Check.spRangeIntersection=spRangeIntersection;})(Check||(Check={}));