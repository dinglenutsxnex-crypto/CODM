import socket
import struct
import zlib
import hashlib
import re
import time
import json
import argparse

HOST = "ec2-13-126-233-176.ap-south-1.compute.amazonaws.com"
ALT_HOST = "ec2-52-66-28-201.ap-south-1.compute.amazonaws.com"
PORT = 443
GUID = "289a6ff9-15d5-48aa-95f2-dfcfebedfab8"
GAME_VERSION = "1.45.0.3.16663-prod"
SHORT_VERSION = "1.45.0"
DEVICE_MODEL  = "samsung SM-X115"

HANDSHAKE_TX = bytes.fromhex(
    "011b0801120948414e445348414b451a0c0a0a5346412d4e4542552d31"
)

ORIGINAL_INNER = bytes.fromhex(
    # --- login credentials wrapper (field[2]) ---
    "0806" "12620801125e"
    "7b226c6f67696e223a2232383961366666392d313564352d343861612d393566322d"
    "646663666562656466616238222c2270617373776f7264223a22"
    "6536633666656561653932363663306335343439353632396663636236623433"   # password placeholder
    "22" "7d"
    # --- FCM token (field[3]) — from fresh capture ---
    "1a7b" "080d" "1277"
    "7b2274223a22342f3041646b564c50776557587974552d6f2d6b517a386b5a31"
    "6871615050657859754b5258707149533979454a6e7651775058443245475a64"
    "71434d5357755f353437714f555751222c226964223a22673136363133383934"
    "363134373335323534393337222c2265223a747275657d"
    # --- device ID (field[3]) ---
    "1a14" "0806" "1210" "3731396533343138383431636162636422"
    # --- app info JSON with updated APK fingerprint f= (field[4]) ---
    "dc01"
    "7b22706c6174666f726d223a22416e64726f6964222c2276223a223139323032"
    "222c226170705f6964223a22636f6d2e6e656b6b692e736861646f7766696768"
    "7433222c2266223a224630303046414236353444434336463830413541413136"
    "41373334434345323444423244323338" "43222c22626e756d626572223a223139"
    "323032222c22626e616d65223a22556e697479436c69656e745f536861646f77"
    "4669676874335f556e697479436c69656e74536861646f7746696768743352656c"
    "656173655f436f6e66696775726174696f6e416e64726f6964227d"
)

ORIGINAL_PASSWORD = b"e6c6feeae9266c0c54495629fccb6b43"

# Stale fingerprint — server's stored hash differs, so server will push get_player
STALE_FINGERPRINT = "36455C3E36075A6545181B460AF344FF1DCD053F"

CURRENCY_TYPE = {1: "Coin", 2: "Bonus", 3: "Shadow"}


# ---- protobuf helpers -------------------------------------------------------

def encode_varint(v):
    out = b""
    while True:
        bits = v & 0x7F
        v >>= 7
        out += bytes([bits | (0x80 if v else 0)])
        if not v:
            break
    return out


def encode_string_field(fn, s):
    e = s.encode()
    return encode_varint((fn << 3) | 2) + encode_varint(len(e)) + e


def encode_message_field(fn, payload):
    return encode_varint((fn << 3) | 2) + encode_varint(len(payload)) + payload


def read_varint(data, pos):
    val, shift = 0, 0
    while pos < len(data):
        b = data[pos]; pos += 1
        val |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            break
    return val, pos


def decode_proto(data):
    fields = []
    pos = 0
    while pos < len(data):
        try:
            tag, pos = read_varint(data, pos)
            fn = tag >> 3
            wire = tag & 7
            if fn == 0:
                break
            if wire == 0:
                val, pos = read_varint(data, pos)
                fields.append((fn, 0, val))
            elif wire == 2:
                length, pos = read_varint(data, pos)
                if pos + length > len(data):
                    break
                raw = data[pos:pos + length]
                pos += length
                fields.append((fn, 2, raw))
            else:
                break
        except Exception:
            break
    return fields


def try_utf8(raw):
    try:
        s = raw.decode("utf-8")
        if all(32 <= ord(c) < 127 or c in "\t\n\r" for c in s):
            return s
    except Exception:
        pass
    return None


# ---- packet helpers ---------------------------------------------------------

def make_small_packet(payload):
    assert len(payload) <= 255
    return bytes([0x01, len(payload)]) + payload


def make_large_packet(payload):
    compressed = zlib.compress(payload, 6)[2:-4]
    return bytes([0x02]) + struct.pack("<I", len(compressed)) + compressed


def build_outer(ctrl, cmd, inner=b""):
    p = encode_varint((1 << 3) | 0) + encode_varint(ctrl)
    p += encode_string_field(2, cmd)
    if inner:
        p += encode_message_field(3, inner)
    return p


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_packet(sock):
    header = recv_exact(sock, 1)
    if not header:
        return None, None
    t = header[0]
    if t == 0x01:
        sz = recv_exact(sock, 1)
        if not sz:
            return None, None
        size = sz[0]
    elif t == 0x02:
        sz = recv_exact(sock, 4)
        if not sz:
            return None, None
        size = struct.unpack("<I", sz)[0]
    else:
        print(f"[!] Unknown frame type: 0x{t:02x}")
        return None, None
    data = recv_exact(sock, size)
    if data is None:
        return None, None
    if t == 0x02:
        try:
            data = zlib.decompress(data, -15)
        except zlib.error as e:
            print(f"[!] Decompress failed: {e}")
            return None, None
    return t, data


def parse_outer(data):
    ctrl, cmd, inner, extra = None, None, b"", {}
    for fn, wire, val in decode_proto(data):
        if fn == 1 and wire == 0:
            ctrl = val
        elif fn == 2 and wire == 2:
            s = try_utf8(val)
            if s:
                cmd = s
        elif fn == 3 and wire == 2:
            inner = val
        elif fn == 4 and wire == 0:
            extra["code"] = val
        elif fn == 5 and wire == 2:
            extra["msg"] = val.decode(errors="replace")
    return ctrl, cmd, inner, extra


def extract_session_token(data):
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in data)
    matches = re.findall(r"[0-9a-f]{7,}-[0-9a-f]{6,}-[0-9a-f]{6,}", text)
    return matches[0] if matches else None


def _replace_gplay_token(inner: bytes, new_token_str: str) -> bytes:
    """Replace the "t" value inside the Google-Play field[3] JSON with a fresh token string."""
    # The Google-Play field[3] payload is: tag(1a) + len(7b) + submsg(080d 1277 <119-byte JSON>)
    # The JSON is: {"t":"<TOKEN>","id":"g16613894614735254937","e":true}
    GPLAY_MARKER = bytes.fromhex("1a7b080d12777b2274223a22")  # up to the opening " of token value
    idx = inner.find(GPLAY_MARKER)
    if idx == -1:
        print("[dbg] WARN: Google token marker not found — cannot replace token")
        return inner

    # The old full Google Play field is 125 bytes (tag+len+payload = 1+1+123)
    OLD_FIELD_LEN = 2 + 0x7b  # 125

    # Build new JSON for Google Play field
    new_json = json.dumps(
        {"t": new_token_str, "id": "g16613894614735254937", "e": True},
        separators=(",", ":"),
    ).encode()
    # Build new field[3] sub-message:  08 0d  12 <len> <json>
    submsg = bytes.fromhex("080d") + bytes([0x12, len(new_json)]) + new_json
    # Build new outer field[3]: 1a <varint-len> <submsg>
    new_field = bytes([0x1a]) + encode_varint(len(submsg)) + submsg

    print(f"[dbg] Replacing Google token: old_field={OLD_FIELD_LEN}B new_field={len(new_field)}B")
    print(f"[dbg] New token: {new_token_str[:40]}...")
    return inner[:idx] + new_field + inner[idx + OLD_FIELD_LEN:]


def _patch_app_info_json(inner: bytes, patch: dict) -> bytes:
    """Locate the app-info JSON field[4] inside the LOGIN inner, parse it,
    apply `patch` (key→new_value, or key→None to delete), re-encode it, and
    return the updated inner bytes."""
    # field[4] tag = (4<<3)|2 = 0x22, but the length uses a 2-byte varint (0x dc 0x 01 = 220)
    # Search for the JSON open-brace that follows the field[4] tag+len bytes.
    # The JSON starts with b'{"platform"'
    JSON_MARKER = b'{"platform"'
    idx = inner.find(JSON_MARKER)
    if idx == -1:
        print("[dbg] WARN: app info JSON not found in inner")
        return inner

    # The JSON runs to the end of the inner (it's the last field)
    json_bytes = inner[idx:]
    try:
        obj = json.loads(json_bytes.decode("utf-8"))
    except Exception as e:
        print(f"[dbg] WARN: could not parse app info JSON: {e}")
        return inner

    for k, v in patch.items():
        if v is None:
            obj.pop(k, None)
        else:
            obj[k] = v

    new_json = json.dumps(obj, separators=(",", ":")).encode("utf-8")

    # Rebuild field[4]: tag 0x22 + varint(len) + json_bytes
    field4_header = bytes([0x22]) + encode_varint(len(new_json))
    # The original field[4] header is at idx - header_len
    # Find start of field[4] tag by scanning backwards
    # (tag 0x22 is the last field tag, preceded by the device-id field)
    orig_json_len = len(json_bytes)
    orig_field4_start = idx
    # Walk back to find the 0x22 tag byte
    for i in range(idx - 1, max(idx - 5, -1), -1):
        if inner[i] == 0x22:
            orig_field4_start = i
            break

    new_inner = inner[:orig_field4_start] + field4_header + new_json
    print(f"[dbg] patched app-info JSON: {len(inner)}B → {len(new_inner)}B  patch={patch}")
    return new_inner


def make_login_packet(session_token, minimal=False, fresh_token: str | None = None,
                      app_info_patch: dict | None = None):
    """Build LOGIN packet.

    minimal=True          : strip Google-Play-token field[3] (test without Google auth).
    fresh_token=<str>     : replace the captured token with a fresh one.
    app_info_patch=<dict> : patch keys in the app-info JSON field[4].
                            Use None value to DELETE a key (e.g. {"f": None} removes the APK hash).
    """
    pw = hashlib.md5((session_token + GUID).encode()).hexdigest().encode()
    inner = ORIGINAL_INNER.replace(ORIGINAL_PASSWORD, pw)
    if inner == ORIGINAL_INNER:
        raise ValueError("Password replacement failed")

    if fresh_token:
        inner = _replace_gplay_token(inner, fresh_token)

    if app_info_patch:
        inner = _patch_app_info_json(inner, app_info_patch)

    if minimal:
        # Remove the Google Play server-auth-code field[3] by locating its marker.
        GPLAY_MARKER = bytes.fromhex("1a7b080d12777b2274223a22342f3041")
        GPLAY_FIELD_TOTAL = 1 + 1 + 0x7b  # tag + len + payload = 125 bytes
        idx = inner.find(GPLAY_MARKER)
        if idx != -1:
            inner = inner[:idx] + inner[idx + GPLAY_FIELD_TOTAL:]
            print(f"[dbg] minimal login: removed Google token at offset {idx}, inner now {len(inner)}B")
        else:
            print(f"[dbg] WARN: Google token marker not found — sending full inner")

    return make_large_packet(build_outer(2, "LOGIN", inner))


def make_initial_ping():
    ts_ms = int(time.time() * 1000)
    ts_submsg = b"\x08" + encode_varint(ts_ms)
    net_data_inner = (
        encode_string_field(1, "net_data")
        + encode_string_field(2, STALE_FINGERPRINT)
    )
    inner = (
        encode_message_field(1, ts_submsg)
        + encode_message_field(2, net_data_inner)
    )
    outer = build_outer(3, "ping", inner)
    pkt = make_small_packet(outer)
    print(f"[dbg] initial_ping size={len(pkt)} (expect 75)  hex={pkt.hex()}")
    return pkt


def make_ping_ack(ctrl, server_ping_inner):
    server_ts_submsg = b""
    for fn, wire, val in decode_proto(server_ping_inner):
        if fn == 1 and wire == 2:
            server_ts_submsg = val
            break
    our_ts_inner = b"\x08" + encode_varint(int(time.time() * 1000))
    ack_inner = (
        encode_message_field(1, server_ts_submsg)
        + encode_message_field(2, our_ts_inner)
    )
    outer = build_outer(ctrl, "ping", ack_inner)
    return make_small_packet(outer)


def encode_bytes_field(fn, raw_bytes):
    """Encode a length-delimited field with raw bytes (wire type 2)."""
    return encode_varint((fn << 3) | 2) + encode_varint(len(raw_bytes)) + raw_bytes


def make_sum_field(sha1_hex):
    """Build field[3] inner: {field[1]="sum", field[2]=<sha1_hex>}"""
    body = encode_string_field(1, "sum") + encode_string_field(2, sha1_hex)
    return encode_bytes_field(3, body)


def make_get_player_packet(ctrl, sha1_hex="", omit_sum=False, version_override=None):
    """
    Build the real get_player request inner (5 fields), as seen in captures:
      field[1] string = GAME_VERSION   ("1.45.0.3.16663-prod")
      field[2] bytes  = empty          (no local state)
      field[3] bytes  = {sum: sha1}   (server SHA1 from last known response)
      field[4] string = DEVICE_MODEL   ("samsung SM-X115")
      field[5] string = SHORT_VERSION  ("1.45.0")
    If omit_sum=True, field[3] is completely absent (no sum field at all).
    version_override=None uses GAME_VERSION; pass "" to omit field[1] entirely.
    """
    gv = GAME_VERSION if version_override is None else version_override
    inner = b""
    if gv != "":                            # omit field[1] entirely when empty string
        inner += encode_string_field(1, gv)
    inner += encode_bytes_field(2, b"")
    if not omit_sum:
        inner += make_sum_field(sha1_hex)
    inner += encode_string_field(4, DEVICE_MODEL)
    inner += encode_string_field(5, SHORT_VERSION)
    outer = build_outer(ctrl, "get_player", inner)
    return make_small_packet(outer)


# ---- player decoder ---------------------------------------------------------

def decode_player_data(inner):
    gp_fields = decode_proto(inner)

    version = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 1 and wt == 2), None)
    wrapper  = next((v for fn, wt, v in gp_fields if fn == 2 and wt == 2), None)
    summary  = next((v for fn, wt, v in gp_fields if fn == 3 and wt == 2), None)
    device   = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 4 and wt == 2), None)
    short_v  = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 5 and wt == 2), None)

    print(f"\n{'='*60}")
    print(f"  get_player Response")
    print(f"{'='*60}")
    print(f"  Version      : {version}")
    print(f"  Device       : {device}")
    print(f"  Short ver    : {short_v}")

    if summary:
        sf = decode_proto(summary)
        sum_hash = next((try_utf8(v) for fn, wt, v in sf if fn == 2 and wt == 2), "?")
        print(f"  Server SHA1  : {sum_hash}")

    if not wrapper:
        print("  [!] No player wrapper in response")
        return

    wrapper_fields = decode_proto(wrapper)
    player_data = next((v for fn, wt, v in wrapper_fields if fn == 2 and wt == 2), None)
    if not player_data:
        print("  [!] No PlayerDTO found in wrapper")
        return

    pd = decode_proto(player_data)

    player_id = next((v for fn, wt, v in pd if fn == 1 and wt == 0), None)
    level     = next((v for fn, wt, v in pd if fn == 3 and wt == 0), None)

    print(f"\n  --- Player ---")
    print(f"  GUID         : {GUID}")
    print(f"  Player ID    : {player_id}")
    print(f"  Level        : {level}")

    currencies = {}
    for fn, wt, v in pd:
        if fn == 4 and wt == 2:
            cf = decode_proto(v)
            ctype  = next((cv for cfn, cwt, cv in cf if cfn == 1 and cwt == 0), None)
            amount = next((cv for cfn, cwt, cv in cf if cfn == 2 and cwt == 0), None)
            if ctype is not None:
                currencies[ctype] = amount

    print(f"\n  --- Currencies ---")
    for ctype in sorted(currencies):
        name = CURRENCY_TYPE.get(ctype, f"type_{ctype}")
        print(f"  {name:10s}: {currencies[ctype]:,}")

    slots = []
    for fn, wt, v in pd:
        if fn == 9 and wt == 2:
            sf2 = decode_proto(v)
            slot_id = next((sv for sfn, swt, sv in sf2 if sfn == 1 and swt == 0), None)
            slot_lv = next((sv for sfn, swt, sv in sf2 if sfn == 2 and swt == 0), None)
            if slot_id is not None:
                slots.append((slot_id, slot_lv))
    if slots:
        print(f"\n  --- Hero Slots ---")
        for slot_id, slot_lv in slots:
            print(f"  Slot {slot_id}: {slot_lv:,}")

    item_count = sum(1 for fn, wt, v in pd if fn == 10 and wt == 2)
    print(f"\n  --- Inventory ---")
    print(f"  Items        : {item_count}")
    print(f"{'='*60}")


# ---- main -------------------------------------------------------------------

def run(host, skip_ping=False, minimal_login=False, fresh_token=None, app_info_patch=None,
        override_sum=None):
    label = (f"skip_ping={skip_ping} minimal_login={minimal_login} "
             f"fresh_token={'yes' if fresh_token else 'no'} "
             f"app_patch={list(app_info_patch.keys()) if app_info_patch else None}")
    print(f"\n[*] Connecting to {host}:{PORT}  [{label}]")
    with socket.create_connection((host, PORT), timeout=10) as sock:
        sock.settimeout(8)

        # Phase 1: Handshake
        sock.sendall(HANDSHAKE_TX)
        _, raw_hs = recv_packet(sock)
        if raw_hs is None:
            print("[!] No handshake response")
            return False
        session_token = extract_session_token(raw_hs)
        if not session_token:
            print("[!] No session token extracted")
            print(f"[dbg] raw_hs hex: {raw_hs.hex()}")
            return False
        print(f"[+] Session token: {session_token}")
        # Print full handshake response — may contain extra fields beyond the session token
        print(f"[dbg] handshake response hex ({len(raw_hs)}B): {raw_hs.hex()}")
        hs_fields = decode_proto(raw_hs)
        for fn, wt, v in hs_fields:
            if wt == 0:
                print(f"    hs field[{fn}] varint={v}")
            elif wt == 2:
                try:
                    txt = v.decode("utf-8")
                    print(f"    hs field[{fn}] string({len(v)})={txt!r}")
                except Exception:
                    print(f"    hs field[{fn}] bytes({len(v)}) hex={v.hex()}")

        # Phase 2: Login
        pkt = make_login_packet(session_token, minimal=minimal_login,
                                fresh_token=fresh_token, app_info_patch=app_info_patch)
        print(f"[>>] LOGIN ({len(pkt)} bytes)")
        sock.sendall(pkt)

        join_zone_received = False
        for _ in range(10):
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[!] Connection closed during login")
                    return False
                ctrl2, cmd, inner2, extra = parse_outer(data)
                print(f"[<<] cmd={cmd}  extra={extra}")
                if cmd == "join_zone":
                    join_zone_received = True
                    # Print join_zone inner — may contain server-issued session credentials
                    print(f"[dbg] join_zone inner hex ({len(inner2)}B): {inner2.hex()}")
                    jz_fields = decode_proto(inner2)
                    for fn, wt, v in jz_fields:
                        if wt == 0:
                            print(f"    jz field[{fn}] varint={v}")
                        elif wt == 2:
                            try:
                                txt = v.decode("utf-8")
                                print(f"    jz field[{fn}] string({len(v)})={txt!r}")
                            except Exception:
                                sub = decode_proto(v)
                                if sub:
                                    print(f"    jz field[{fn}] sub-msg({len(v)}B):")
                                    for sf, sw, sv in sub:
                                        if sw == 0:
                                            print(f"        sub field[{sf}] varint={sv}")
                                        elif sw == 2:
                                            try:
                                                print(f"        sub field[{sf}] string={sv.decode()!r}")
                                            except Exception:
                                                print(f"        sub field[{sf}] bytes={sv.hex()}")
                                else:
                                    print(f"    jz field[{fn}] bytes({len(v)}) hex={v.hex()}")
                    break
                if extra.get("code"):
                    print(f"[!] Server error {extra['code']}: {extra.get('msg','')}")
                    return False
            except socket.timeout:
                break

        if not join_zone_received:
            print("[!] No join_zone — proceeding anyway")

        # Phase 3: Optionally send net_data ping
        net_data_ack_ctrl = None
        if skip_ping:
            print("[*] Skipping net_data ping — sending get_player immediately")
        else:
            ping_pkt = make_initial_ping()
            print(f"[>>] net_data ping ({len(ping_pkt)} bytes)")
            sock.sendall(ping_pkt)

            # Phase 4: Absorb the server's ack — do NOT respond (echo loop risk)
            # Print inner hex: the server might embed its current net_data hash here.
            sock.settimeout(6)
            server_ping_hash = None
            try:
                _, data = recv_packet(sock)
                if data:
                    ctrl, cmd, inner, extra = parse_outer(data)
                    print(f"[<<] ctrl={ctrl} cmd={cmd!r} inner={len(inner)}B  hex={inner.hex()}")
                    # Try to parse sub-fields from server ping inner
                    try:
                        pos = 0
                        while pos < len(inner):
                            tag_val, pos = read_varint(inner, pos)
                            fn = tag_val >> 3
                            wt = tag_val & 7
                            if wt == 0:
                                v, pos = read_varint(inner, pos)
                                print(f"    ping_inner field[{fn}] varint={v}")
                            elif wt == 2:
                                ln, pos = read_varint(inner, pos)
                                val = inner[pos:pos+ln]
                                pos += ln
                                try:
                                    txt = val.decode("utf-8")
                                    print(f"    ping_inner field[{fn}] str({ln})={txt!r}")
                                    # If it looks like a SHA1 hex string, save it
                                    if ln == 40 and all(c in "0123456789ABCDEFabcdef" for c in txt):
                                        server_ping_hash = txt.upper()
                                        print(f"    *** server_ping_hash={server_ping_hash} — will try in get_player!")
                                except Exception:
                                    print(f"    ping_inner field[{fn}] bytes({ln})={val.hex()}")
                            else:
                                break
                    except Exception as e:
                        print(f"    [parse err] {e}")
                    if cmd == "ping":
                        net_data_ack_ctrl = ctrl
            except socket.timeout:
                print("[!] No net_data ack received")

        # Phase 5: Send explicit get_player immediately (as real app does),
        # trying SHA1 candidates until one works.
        #
        # SHA1 order:
        #   1. Captured SHA1 from user's latest session (before buy)
        #   2. Real app's SECOND ping SHA1 (post-buy client cache)
        #   3. Old server response sha1
        #   4. STALE_FINGERPRINT (client's cached sha1)
        #   5. All-zeros
        #   6. Empty string
        #   7. (omit_sum=True) field[3] completely absent
        # If the server's ping ack contained a hash, put it FIRST — highest chance of success.
        SHA1_CANDIDATES = []
        if override_sum is not None:
            # User-specified sum injected first — skip all others
            SHA1_CANDIDATES = [(override_sum, False)]
        else:
            if not skip_ping and server_ping_hash:
                SHA1_CANDIDATES.append((server_ping_hash, False))  # server's own current hash

            SHA1_CANDIDATES += [
                ("16A72F667F0AF3D4EF8F5964CAEAEC0B1A008E0C", False),  # pre-buy sha1
                ("8A20E875587E71945B44622B725B059DDC3F2582", False),  # app's 2nd-ping sha1
                ("D7914E58FDD8FF1BC1A3E2AC981C439B6E9DC972", False),  # old server sha1
                (STALE_FINGERPRINT,                          False),  # client cached
                ("0000000000000000000000000000000000000000", False),  # all-zeros
                ("",                                          False),  # bare empty sum
                ("",                                          True),   # field[3] omitted
            ]

        sock.settimeout(8)
        player_decoded = False
        explicit_ctrl = (net_data_ack_ctrl or 3) + 1

        for sha1, omit in SHA1_CANDIDATES:
            gp = make_get_player_packet(explicit_ctrl, sha1, omit_sum=omit)
            if omit:
                label = "(no field[3])"
            else:
                label = sha1[:12] + "..." if sha1 else "(empty sum)"
            print(f"\n[>>] get_player ctrl={explicit_ctrl} sha1={label} ({len(gp)}B)")
            sock.sendall(gp)

            # Wait for response
            got_response = False
            sock.settimeout(8)
            while True:
                try:
                    _, data = recv_packet(sock)
                    if data is None:
                        print("[<<] Connection closed")
                        return False

                    ctrl, cmd, inner, extra = parse_outer(data)
                    print(f"[<<] ctrl={ctrl} cmd={cmd!r} inner={len(inner)}B extra={extra}")

                    if cmd == "get_player":
                        got_response = True
                        if extra.get("code") == 10004:
                            print(f"[!] 10004 invalid fingerprint — trying next SHA1")
                            explicit_ctrl += 1
                        elif extra.get("code"):
                            print(f"[!] get_player error {extra['code']}: {extra.get('msg','')}")
                        else:
                            decode_player_data(inner)
                            player_decoded = True
                        break

                    elif cmd == "ping":
                        ack = make_ping_ack(ctrl, inner)
                        sock.sendall(ack)
                        print(f"[>>] keepalive ping ack ctrl={ctrl}")

                    elif cmd is None:
                        print(f"[<<] UNKNOWN hex: {data[:20].hex()}...")
                    else:
                        print(f"[<<] ignoring cmd={cmd!r}")

                except socket.timeout:
                    print("[!] Timeout waiting for get_player response")
                    got_response = True  # don't retry on timeout
                    explicit_ctrl += 1
                    break
                except Exception as e:
                    print(f"[!!] {e}")
                    return False

            if player_decoded:
                break
            if not got_response:
                break

        # --- Discriminating tests ---
        if not player_decoded:
            def _probe_gp(label, pkt):
                """Send one get_player packet, return (code, success)."""
                nonlocal explicit_ctrl, player_decoded
                explicit_ctrl += 1
                sock.sendall(pkt)
                sock.settimeout(6)
                try:
                    _, data = recv_packet(sock)
                    if not data:
                        print(f"[<<] no response for {label}")
                        return (None, False)
                    c, cmd, inn, ex = parse_outer(data)
                    code = ex.get("code", 0)
                    print(f"[probe {label}] code={code} extra={ex}")
                    if not code:
                        decode_player_data(inn)
                        player_decoded = True
                        return (code, True)
                    return (code, False)
                except socket.timeout:
                    print(f"[probe {label}] timeout")
                    return (None, False)

            # T1: Garbage inner — confirms parse-vs-account level
            code, ok = _probe_gp(
                "T1-garbage",
                make_small_packet(build_outer(explicit_ctrl + 1, "get_player", b"\xff\xfe\xfd\x00")),
            )
            if ok: return True
            if code == 10004:
                print("  → T1: ACCOUNT-LEVEL check (fires before parsing)")
            elif code == 1:
                print("  → T1: PARSE-LEVEL check — inner content matters")

            # T2: No field[1] version at all
            code, ok = _probe_gp(
                "T2-no-version",
                make_get_player_packet(explicit_ctrl + 1, "16A72F667F0AF3D4EF8F5964CAEAEC0B1A008E0C", version_override=""),
            )
            if ok: return True

            # T3–T7: Try plausible future version strings
            for ver in [
                "1.45.0.4.16663-prod",
                "1.45.0.4.16800-prod",
                "1.45.1.0.16663-prod",
                "1.46.0.0.16663-prod",
                "1.45.0.3.16664-prod",
            ]:
                code, ok = _probe_gp(
                    f"T-ver={ver}",
                    make_get_player_packet(explicit_ctrl + 1, "16A72F667F0AF3D4EF8F5964CAEAEC0B1A008E0C", version_override=ver),
                )
                if ok: return True
                if code != 10004:
                    print(f"  *** Different error for version {ver!r}: code={code} — version IS checked!")

        # Final discriminating summary printed by main()
        return player_decoded


def main():
    parser = argparse.ArgumentParser(
        description="Shadow Fight 3 Python client",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
NORMAL USE (once you have both a fresh token AND the correct sum):
  python3 sf3.py --token "4/0AAAA..." --sum "AABBCC..."

WHY YOU NEED --sum:
  The "sum" field in get_player is a session-specific HMAC computed by the
  game client from your session_token + an APK-embedded key. Every session
  gets a DIFFERENT expected sum. Using the captured sum from a previous session
  never works — the server computes HMAC(key, new_session_token) and compares.

  To get the correct sum: intercept a get_player packet from the game app
  during a live session (3rd outgoing packet after LOGIN). The sum is the
  field[2] value inside field[3] of the get_player inner.

HOW TO GET A FRESH TOKEN:
  1. Open the game app on the device → start a fresh session
  2. Intercept traffic (Charles, mitmproxy, tcpdump via root/VPN)
  3. Capture the second outgoing packet after HANDSHAKE (LOGIN packet)
  4. Decode: the JSON inside the field[3] sub-message has "t":"4/0A..."
  5. Pass that value with --token within ~2 minutes of capturing it

HOW TO GET THE CORRECT SUM (for the SAME session as the token):
  1. From the same capture session, find the first get_player packet
  2. Parse the inner: field[3] bytes → sub-field[2] string is the 40-char SHA1/HMAC
  3. Pass that value with --sum

DIAGNOSTIC MODE (no args):
  Runs isolation tests (A-E) to pinpoint where fingerprint check fires.
        """,
    )
    parser.add_argument(
        "--token", "-t", metavar="GPLAY_TOKEN",
        help='Fresh Google Play server-auth-code ("t" value from login packet). '
             'Must be captured fresh — tokens expire in ~2 minutes.',
    )
    parser.add_argument(
        "--sum", "-s", metavar="SHA1_HEX",
        help='Session-specific sum/HMAC for get_player field[3]. '
             'Must be captured from the SAME live session as --token. '
             'The server computes HMAC(APK_key, session_token) and rejects any other value.',
    )
    parser.add_argument(
        "--alt-host", action="store_true",
        help="Use the alternate game server instead of the primary",
    )
    args = parser.parse_args()

    host = ALT_HOST if args.alt_host else HOST
    override_sum = args.sum if hasattr(args, "sum") else None

    if args.token:
        # Production mode: use fresh token (and optionally a fresh sum)
        if override_sum:
            print(f"[*] Fresh token + sum provided — running with live credentials")
        else:
            print(f"[*] Fresh token provided (no --sum) — will try all known sum variants")
        result = run(host, fresh_token=args.token, override_sum=override_sum)
        if not result and not args.alt_host:
            print(f"\n[*] Retrying with alt host...")
            run(ALT_HOST, fresh_token=args.token, override_sum=override_sum)
        return

    # Diagnostic mode: run isolation tests to identify root cause
    print("=" * 60)
    print("DIAGNOSTIC MODE — no fresh token provided")
    print("Running isolation tests to identify the fingerprint check")
    print("=" * 60)

    combos = [
        # (name, kwargs)
        # A: our baseline — always 10004
        ("A-normal",        dict()),
        # B: no Google auth code in login
        ("B-minimal_login", dict(minimal_login=True)),
        # C: skip ping
        ("C-skip_ping",     dict(skip_ping=True)),
        # D: remove "f" (APK fingerprint) from app-info JSON — tests if f IS the fingerprint
        ("D-no-f",          dict(app_info_patch={"f": None})),
        # E: remove "f" AND skip ping
        ("E-no-f+skip_ping",dict(app_info_patch={"f": None}, skip_ping=True)),
    ]

    for name, kwargs in combos:
        print(f"\n{'='*60}")
        print(f"[TEST {name}]")
        print("=" * 60)
        result = run(host, **kwargs)
        if result:
            print(f"\n[SUCCESS] Test {name} worked!")
            return
        print(f"[FAIL] Test {name}")

    print("""
╔══════════════════════════════════════════════════════════════════╗
║  DIAGNOSIS COMPLETE — ROOT CAUSE CONFIRMED                       ║
╠══════════════════════════════════════════════════════════════════╣
║  WHAT WAS PROVED (25+ tests):                                    ║
║  • Garbage inner → code 1 (parse error — server parses first)   ║
║  • Empty version  → code 2 ("Version is empty" — checked next)  ║
║  • Everything else → code 10004 "invalid fingerprint" ALWAYS     ║
║  • Removing sum, changing SHA1, removing APK hash from login,    ║
║    skipping ping, removing Google token: ALL still 10004         ║
║  • 25+ SHA1/HMAC combos of nonce/token/GUID/device_id: no match  ║
║                                                                  ║
║  ROOT CAUSE:                                                     ║
║  The server issues a session NONCE in HANDSHAKE (field[3].sub1). ║
║  The game computes: sum = HMAC(APK_KEY, nonce)                   ║
║  APK_KEY is a secret constant embedded in Assembly-CSharp.dll.   ║
║  The server rejects any sum that doesn't match → 10004           ║
║                                                                  ║
║  PATH A — One-time fix (no APK decompile needed):                ║
║  1. Run the game on device with mitmproxy/tcpdump capture        ║
║  2. From the SAME session, grab:                                 ║
║     • --token: "t" value from LOGIN packet field[3].sub[2] JSON  ║
║     • --sum:   field[3].sub[2] from the get_player inner         ║
║  3. python3 sf3.py --token "4/0A..." --sum "AABBCC..."           ║
║  (Works for that one run; repeat capture for each new run)       ║
║                                                                  ║
║  PATH B — Permanent fix (compute sum for any session):           ║
║  1. adb shell pm path com.nekki.shadowfight3                     ║
║  2. adb pull <path> sf3.apk                                      ║
║  3. unzip sf3.apk assets/bin/Data/Managed/Assembly-CSharp.dll    ║
║  4. ILSpy/dnSpy: search for "sum" "fingerprint" "HMAC"           ║
║  5. Extract APK_KEY → add compute_sum(nonce) to this script      ║
║  (Works forever without recapturing)                             ║
╚══════════════════════════════════════════════════════════════════╝
""")


if __name__ == "__main__":
    main()
