# SF3 Server Recon — Research Notes

## Status
Login flow fully understood. Custom client ready to run.

---

## What We Have

| Item | Value |
|---|---|
| GUID | `289a6ff9-15d5-48aa-95f2-dfcfebedfab8` |
| Device | samsung SM-X115 |
| ANDROID_ID (from log packet) | `719e3418841cabcd` |
| Game version | `1.45.0.2.16662-prod` |
| Server | `ec2-13-126-233-176.ap-south-1.compute.amazonaws.com:443` |
| Alternate server | `ec2-52-66-28-201.ap-south-1.compute.amazonaws.com:443` |
| Balancer | `https://sf3lb.nekki.com/balance` |

Session token is **volatile** — fresh one every connection, don't hardcode it.

---

## What Worked

### 1. Packet framing (reverse engineered from captures)

NOT standard SFS2X binary framing as the docs describe. Actual format:

```
Small packets (payload <= 255 bytes):
  [0x01][1B length][raw protobuf payload]

Large packets:
  [0x02][4B little-endian length][raw-deflate compressed protobuf payload]
```

Large packets are compressed with raw deflate (zlib with no header/trailer, `wbits=-15`).
The 0x80/BIG_SIZED framing described in the decompiled source is wrong for this server version.

### 2. Outer protobuf envelope

Every packet payload is a protobuf:
```
field[1] varint  = controller  (1=system, 3=extension)
field[2] string  = command     ("HANDSHAKE", "LOGIN", "ping", etc.)
field[3] bytes   = nested params protobuf
```

### 3. Handshake

Send the fixed handshake bytes (doesn't change between sessions):
```
011b0801120948414e445348414b451a0c0a0a5346412d4e4542552d31
```

Server responds with session token in `field[3] > field[2]` (nested proto string).
Token looks like: `1174xxxx-000cxxxx-xxxxxxxx`

### 4. Auth formula

```python
password = MD5(session_token + guid).hexdigest()
```

Direct string concatenation, no separator. Verified against live capture.

### 5. Login packet structure

```
outer: field[1]=1, field[2]="LOGIN", field[3]=inner
inner: field[1]=6, field[2]=login_request_proto
login_request_proto:
  field[1] varint = 2  (version)
  field[2] bytes  = auth_token_proto
  field[4] string = '{"platform":"Android"}'
auth_token_proto:
  field[1] varint = 1  (DEVICE auth type)
  field[2] string = '{"login":"<guid>","password":"<md5>"}'
```

### 6. GUID extraction

The login packet payload is raw-deflate compressed. After decompressing, the GUID and MD5 password are plaintext JSON inside the protobuf. Got it from the PCAPdroid capture of a live session.

### 7. Known commands (from SFCMD.cs + live captures)

From source:
`ping`, `get_player`, `create_player`, `generate_shop`, `buy_item`, `equip`,
`insert_perk`, `open_booster`, `buy_booster`, `finish_fight`, `refresh_battles`,
`set_chapter`, `log`, `brawler_start`, `brawler_finish`, `process_offline_batch`,
`cheat_reset_player`, `cheat_add_item`, `cheat_add_perk`, `cheat_reset_perks`,
`cheat_set_currency`, `cheat_set_experience`, `cheat_generate_battle`,
`cheat_get_player`, `cheat_set_player`, `cheat_set_appearance`, `cheat_set_all_items`

Extra commands found in live captures (not in source):
`clan_get_full_info`, `clan_get_full_feed`, `clan_refresh_battles`,
`chat_list_rooms`, `chat_subscribe`, `chat_room_population`, `set_settings`

---

## What Didn't Work

### Keychain decryption
- `keyChainStore.dat` in the leaked source zip is 96 bytes ciphertext — doesn't match expected 136 bytes for a `com.nekki.shadowfight3|<UUID>` payload. Wrong device or truncated.
- Latest game version changed keychain format to `ENC1...` prefix — different crypto entirely, no source for it.
- ANDROID_ID `8ce5dd47c9d72efb` doesn't decrypt the old keychain. Wrong key.

### Replaying captured login packet raw
- Server rejects it with `Invalid login or password` — MD5 password is bound to the original session token which is gone.
- Expected behavior, not a bug.

### Probing commands without login
- Server accepts `ping` and `get_player` silently (empty response), then closes the connection on the 3rd unauthenticated packet with a broken pipe.
- No useful data returned without being logged in.

### SFS2X binary framing from the decompiled source
- The `[0x80][2B BE size]` format described in the source doesn't match actual captures.
- Real framing is `[0x01/0x02][1B or 4B LE size]` as documented above.

### Inferring session token from anything static
- Token is server-generated per connection, no way to predict it. Must always do the handshake first.

---

## Flow to Authenticate

```
1. TCP connect to game server :443 (plain TCP, no TLS)
2. Send fixed HANDSHAKE_TX bytes
3. Parse session token from server response field[3].field[2]
4. Compute password = MD5(token + GUID)
5. Build login proto with GUID + password
6. Send login packet
7. Server responds with join_zone push event
8. Send get_player to load account state
```

All of this is implemented in `sf3_login.py`.

---

## Next Steps

- Run `sf3_login.py` and verify login succeeds
- After login, send `get_player` and decode the player protobuf (schema in `sf3DTO/`)
- Explore cheat commands — unknown if they're gated server-side or just open
- `cheat_get_player` returns a `StringValue` per source — likely JSON dump of full player state
