import socket
import struct
import zlib
import hashlib
import re
import time

HOST = "ec2-13-126-233-176.ap-south-1.compute.amazonaws.com"
PORT = 443
GUID = "289a6ff9-15d5-48aa-95f2-dfcfebedfab8"
GAME_VERSION = "1.45.0.2.16662-prod"

HANDSHAKE_TX = bytes.fromhex(
    "011b0801120948414e445348414b451a0c0a0a5346412d4e4542552d31"
)

ORIGINAL_INNER = bytes.fromhex(
    "080612620801125e7b226c6f67696e223a2232383961366666392d313564352d343861"
    "612d393566322d646663666562656466616238222c2270617373776f7264223a226431"
    "363435326564366639383633633631313138623432663339303932343561"
    "227d1a7b080d12777b2274223a22342f3041646b564c5077453748774543742d4a555737"
    "526c46463554624e7547577a48506b41565969777573565236326c4156336a493379514352635a7069706d6e"
    "4443445f667941222c226964223a22673136363133383934363134373335323534393337"
    "222c2265223a747275657d1a14080612103731396533343138383431636162636422dc01"
    "7b22706c6174666f726d223a22416e64726f6964222c2276223a223139323032222c22"
    "6170705f6964223a22636f6d2e6e656b6b692e736861646f77666967687433222c2266"
    "223a2241433631453146303336363646384432354541324238353330434339414635"
    "454538303745363836222c22626e756d626572223a223139323032222c22626e616d65"
    "223a22556e697479436c69656e745f536861646f774669676874335f556e697479436c"
    "69656e74536861646f7746696768743352656c656173655f436f6e66696775726174696f"
    "6e416e64726f6964227d"
)

ORIGINAL_PASSWORD = b"d16452ed6f9863c61118b42f3909245a"

# CurrencyType enum from sf3DTO/CurrencyType.cs
CURRENCY_TYPE = {0: "Unknown", 1: "Coin", 2: "Bonus", 3: "Shadow"}

# ---- protobuf helpers -------------------------------------------------------

def encode_varint(v):
    out = b""
    while True:
        bits = v & 0x7F
        v >>= 7
        out += bytes([bits | (0x80 if v else 0)])
        if not v:
            break
    return out


def encode_string_field(field_num, s):
    encoded = s.encode()
    return encode_varint((field_num << 3) | 2) + encode_varint(len(encoded)) + encoded


def encode_message_field(field_num, payload):
    return encode_varint((field_num << 3) | 2) + encode_varint(len(payload)) + payload


def read_varint(data, pos):
    val, shift = 0, 0
    while True:
        b = data[pos]; pos += 1
        val |= (b & 0x7F) << shift; shift += 7
        if not (b & 0x80):
            break
    return val, pos


def decode_proto(data, depth=0):
    """Recursively decode a protobuf blob. Returns list of (field_num, wire, value) tuples."""
    fields = []
    pos = 0
    while pos < len(data):
        try:
            tag, pos = read_varint(data, pos)
            field_num = tag >> 3
            wire = tag & 0x07
            if wire == 0:
                val, pos = read_varint(data, pos)
                fields.append((field_num, 0, val))
            elif wire == 1:
                val = struct.unpack_from("<d", data, pos)[0]
                pos += 8
                fields.append((field_num, 1, val))
            elif wire == 2:
                length, pos = read_varint(data, pos)
                raw = data[pos:pos + length]; pos += length
                fields.append((field_num, 2, raw))
            elif wire == 5:
                val = struct.unpack_from("<f", data, pos)[0]
                pos += 4
                fields.append((field_num, 5, val))
            else:
                break  # unknown wire type, stop
        except Exception:
            break
    return fields


def try_utf8(raw):
    try:
        s = raw.decode("utf-8")
        return s if all(c >= " " or c in "\t\n\r" for c in s) else None
    except Exception:
        return None


# ---- packet builders --------------------------------------------------------

def make_small_packet(outer_payload):
    assert len(outer_payload) <= 255
    return bytes([0x01, len(outer_payload)]) + outer_payload


def make_large_packet(outer_payload):
    compressed = zlib.compress(outer_payload, 6)[2:-4]
    return bytes([0x02]) + struct.pack("<I", len(compressed)) + compressed


def build_outer(controller, command, inner=b""):
    payload = encode_varint((1 << 3) | 0) + encode_varint(controller)
    payload += encode_string_field(2, command)
    if inner:
        payload += encode_message_field(3, inner)
    return payload


def make_login_packet(session_token):
    new_password = hashlib.md5((session_token + GUID).encode()).hexdigest().encode()
    inner = ORIGINAL_INNER.replace(ORIGINAL_PASSWORD, new_password)
    if inner == ORIGINAL_INNER:
        raise ValueError("Password replacement failed — ORIGINAL_PASSWORD not found in ORIGINAL_INNER")
    outer = build_outer(2, "LOGIN", inner)
    return make_large_packet(outer)


def make_ping_response(ctrl, server_ping_inner):
    """
    Client ping response mirrors the server's timestamp (field[1] of inner)
    and adds the current millisecond timestamp as field[2].
    Observed format from captures (cap[6], cap[23]):
      01 1c 08 <ctrl> 12 04 ping 1a 12
        0a 07 08 <server_ts_6bytes>   -- echo server ts
        12 07 08 <client_ts_6bytes>   -- our current ts
    """
    # extract field[1] submessage from server's ping inner
    server_ts_submsg = b""
    for fn, wire, val in decode_proto(server_ping_inner):
        if fn == 1 and wire == 2:
            server_ts_submsg = val
            break

    our_ts_varint = encode_varint(int(time.time() * 1000))
    our_ts_submsg = b"\x08" + our_ts_varint

    inner = encode_message_field(1, server_ts_submsg) + encode_message_field(2, our_ts_submsg)
    outer = build_outer(ctrl, "ping", inner)
    return make_small_packet(outer)


def make_get_player_packet(ctrl):
    # GetPlayerRequest: field[1] = version string
    inner = encode_string_field(1, GAME_VERSION)
    outer = build_outer(ctrl, "get_player", inner)
    return make_small_packet(outer)


# ---- recv helpers -----------------------------------------------------------

def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_packet(sock):
    header = recv_exact(sock, 1)
    if not header:
        return None, None
    t = header[0]
    if t == 0x01:
        size_raw = recv_exact(sock, 1)
        if not size_raw:
            return None, None
        size = size_raw[0]
    elif t == 0x02:
        size_raw = recv_exact(sock, 4)
        if not size_raw:
            return None, None
        size = struct.unpack("<I", size_raw)[0]
    else:
        return None, None
    data = recv_exact(sock, size)
    if data is None:
        return None, None
    if t == 0x02:
        try:
            data = zlib.decompress(data, -15)
        except Exception:
            pass
    return t, data


def parse_outer(data):
    """Extract (controller, command, inner_bytes) from a decoded packet payload."""
    fields = decode_proto(data)
    controller, command, inner = None, None, b""
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            controller = val
        elif fn == 2 and wire == 2:
            s = try_utf8(val)
            if s:
                command = s
        elif fn == 3 and wire == 2:
            inner = val
    return controller, command, inner


def extract_session_token(data):
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in data)
    tokens = re.findall(r"[0-9a-f]{7,}-[0-9a-f]{6,}-[0-9a-f]{6,}", text)
    return tokens[0] if tokens else None


# ---- player decoder ---------------------------------------------------------

def decode_currencies(raw):
    fields = decode_proto(raw)
    ctype, value = 0, 0
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            ctype = val
        elif fn == 2 and wire == 0:
            value = val
    name = CURRENCY_TYPE.get(ctype, f"type_{ctype}")
    return name, value


def decode_item(raw):
    fields = decode_proto(raw)
    model_id, stack_level, equipped = 0, 0.0, False
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            model_id = val
        elif fn == 2 and wire == 1:
            stack_level = val
        elif fn == 3 and wire == 0:
            equipped = bool(val)
    return model_id, stack_level, equipped


def decode_short_player(raw):
    """ShortPlayer: field[1]=playerId(int64), field[2]=nickname, field[3]=displayName, field[4]=level"""
    fields = decode_proto(raw)
    info = {}
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            info["playerId"] = val
        elif fn == 2 and wire == 2:
            info["nickname"] = try_utf8(val) or ""
        elif fn == 3 and wire == 2:
            info["displayName"] = try_utf8(val) or ""
        elif fn == 4 and wire == 0:
            info["level"] = val
    return info


def decode_public_player(raw):
    """PublicPlayer: field[1]=shortPlayer"""
    fields = decode_proto(raw)
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            return decode_short_player(val)
    return {}


def decode_inventory(raw):
    fields = decode_proto(raw)
    items, perks, boosters = [], [], []
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            items.append(decode_item(val))
        elif fn == 2 and wire == 2:
            perks.append(val)
        elif fn == 3 and wire == 2:
            boosters.append(val)
    return items, perks, boosters


def decode_player(raw):
    """
    Player proto (sf3DTO/Player.cs):
      1=publicPlayer  2=permissions  3=experience  4=currencies[]
      5=appearance    6=shop         7=inventory   8=battleData
      9=chapterId    10=offlineStateId  11=abTag   12=logData
     13=rating(double) 14=brawlerFight
    Response outer inner starts with ExtendedPlayer or similar wrapper.
    We try Player directly first, then fall back to ExtendedPlayer.field[1].
    """
    fields = decode_proto(raw)
    result = {"currencies": [], "items": []}

    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            # Could be ExtendedPlayer.primaryPlayer (Player) or Player.publicPlayer (PublicPlayer)
            # Try both: if sub-fields contain "playerId" it's PublicPlayer
            sub = decode_proto(val)
            # Check if this is a string (version) — ExtendedPlayer response wrapper quirk
            s = try_utf8(val)
            if s and len(s) > 5:
                result["version"] = s
            else:
                # Try as publicPlayer
                pp = decode_public_player(val)
                if pp:
                    result.update(pp)
                else:
                    # Try as Player (ExtendedPlayer.field[1] = primaryPlayer)
                    inner_result = decode_player(val)
                    result.update(inner_result)
        elif fn == 2 and wire == 0:
            result["permissions"] = val
        elif fn == 3 and wire == 0:
            result["experience"] = val
        elif fn == 4 and wire == 2:
            name, value = decode_currencies(val)
            result["currencies"].append((name, value))
        elif fn == 5 and wire == 2:
            pass  # appearance (skip for now)
        elif fn == 7 and wire == 2:
            items, perks, boosters = decode_inventory(val)
            result["items"] = items
            result["perk_count"] = len(perks)
            result["booster_count"] = len(boosters)
        elif fn == 9 and wire == 0:
            result["chapterId"] = val
        elif fn == 10 and wire == 0:
            result["offlineStateId"] = val
        elif fn == 11 and wire == 2:
            s = try_utf8(val)
            if s:
                result["abTag"] = s
        elif fn == 13 and wire == 1:
            result["rating"] = round(val, 2)

    return result


def decode_extended_player(raw):
    """
    ExtendedPlayer: field[1]=primaryPlayer, field[2]=secondaryPlayer,
                    field[3]=primaryAccount, field[4]=secondaryAccount,
                    field[5]=timestamp, field[6]=brawlerFinish
    The get_player response inner is wrapped in this.
    """
    fields = decode_proto(raw)
    result = {}
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            result = decode_player(val)
            result["_source"] = "primaryPlayer"
        elif fn == 2 and wire == 2:
            # secondaryPlayer — ignore for now
            pass
        elif fn == 3 and wire == 2:
            # primaryAccount: field[1]=login(string), field[2]=authType
            acc_fields = decode_proto(val)
            for afn, awire, aval in acc_fields:
                if afn == 1 and awire == 2:
                    s = try_utf8(aval)
                    if s:
                        result["account_login"] = s
    return result


def print_player(data):
    print("\n" + "="*60)
    print("  PLAYER DATA")
    print("="*60)

    # Try ResponseAndStateId wrapper (field[1]=offlineStateId varint, field[2]=bytes)
    # Then ExtendedPlayer, then raw Player
    fields = decode_proto(data)
    
    # Detect wrapper type by looking at field types
    f1_wire = next((w for fn, w, v in fields if fn == 1), None)
    
    # Check for version string at field[1] — this means the response IS the inner of
    # outer.field[3], and the server response inner is an ExtendedPlayer-like wrapper
    # where field[1] might be a string (version echo) or a sub-message.
    # We just try ExtendedPlayer first.
    player = decode_extended_player(data)
    
    # If ExtendedPlayer didn't find anything useful, try raw Player
    if not player.get("nickname") and not player.get("experience"):
        player = decode_player(data)

    if not player:
        print("  Could not decode player data")
        return

    if "version" in player:
        print(f"  Server version : {player['version']}")
    if "displayName" in player or "nickname" in player:
        print(f"  Nickname       : {player.get('nickname', '?')}")
        print(f"  Display name   : {player.get('displayName', '?')}")
    if "playerId" in player:
        print(f"  Player ID      : {player['playerId']}")
    if "level" in player:
        print(f"  Level          : {player['level']}")
    if "experience" in player:
        print(f"  Experience     : {player['experience']}")
    if "chapterId" in player:
        print(f"  Chapter        : {player['chapterId']}")
    if "rating" in player:
        print(f"  Rating         : {player['rating']}")
    if "account_login" in player:
        print(f"  Account login  : {player['account_login']}")

    if player.get("currencies"):
        print(f"\n  Currencies:")
        for name, val in player["currencies"]:
            print(f"    {name:<10} : {val:,}")

    if player.get("items"):
        equipped = [(m, s) for m, s, e in player["items"] if e]
        unequipped = [(m, s) for m, s, e in player["items"] if not e]
        print(f"\n  Inventory      : {len(player['items'])} items ({len(equipped)} equipped)")
        if equipped:
            print(f"  Equipped items :")
            for model_id, stack in equipped:
                print(f"    model {model_id:<6} stack={stack:.2f}")

    if "perk_count" in player:
        print(f"  Perks          : {player['perk_count']}")
    if "booster_count" in player:
        print(f"  Boosters       : {player['booster_count']}")

    if "offlineStateId" in player:
        print(f"\n  Offline state  : {player['offlineStateId']}")
    if "abTag" in player:
        print(f"  AB tag         : {player['abTag']}")
    if "permissions" in player:
        print(f"  Permissions    : {player['permissions']}")

    print("="*60)


# ---- main -------------------------------------------------------------------

def main():
    print(f"[*] Connecting to {HOST}:{PORT}")
    with socket.create_connection((HOST, PORT), timeout=10) as sock:
        sock.settimeout(8)

        # Handshake
        sock.sendall(HANDSHAKE_TX)
        _, raw_hs = recv_packet(sock)
        session_token = extract_session_token(raw_hs)
        print(f"[+] Handshake OK")
        print(f"[+] Session token: {session_token}")

        if not session_token:
            print("[!] No session token, aborting")
            return

        password = hashlib.md5((session_token + GUID).encode()).hexdigest()
        print(f"[+] GUID:     {GUID}")
        print(f"[+] Password: {password}")

        # Login
        pkt = make_login_packet(session_token)
        print(f"\n[>>] Sending LOGIN ({len(pkt)} bytes)")
        sock.sendall(pkt)

        # --- Phase 2: drain login pushes, wait for join_zone ---
        # The ctrl counter is shared and sequential.
        # HANDSHAKE=1, LOGIN=2, then server sends ping=3, client echoes 3,
        # then client sends get_player=4, server responds with 4.
        join_zone_received = False
        for _ in range(10):
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed during login phase")
                    return
                _, cmd, _ = parse_outer(data)
                print(f"[<<] {len(data)} bytes  cmd={cmd}")
                if cmd == "join_zone":
                    join_zone_received = True
                    break
            except socket.timeout:
                break

        if not join_zone_received:
            print("[!] Did not receive join_zone — proceeding anyway")

        # --- Phase 3: receive server ping (ctrl=3), respond, get next ctrl ---
        # Server sends ping right after join_zone. We MUST respond before
        # sending get_player, and the get_player ctrl = ping_ctrl + 1.
        get_player_ctrl = 4  # default if we miss the ping
        sock.settimeout(4)
        try:
            _, data = recv_packet(sock)
            if data:
                ctrl, cmd, inner = parse_outer(data)
                print(f"[<<] {len(data)} bytes  ctrl={ctrl}  cmd={cmd}")
                if cmd == "ping":
                    resp = make_ping_response(ctrl, inner)
                    print(f"[>>] Sending ping response ctrl={ctrl} ({len(resp)} bytes)")
                    sock.sendall(resp)
                    get_player_ctrl = ctrl + 1
                else:
                    # Not a ping — unexpected, still proceed
                    print(f"[!] Expected ping, got {cmd!r} — using ctrl=4 for get_player")
        except socket.timeout:
            print("[!] No ping received from server — using ctrl=4 for get_player")

        # --- Phase 4: send get_player ---
        sock.settimeout(10)
        gp = make_get_player_packet(get_player_ctrl)
        print(f"\n[>>] Sending get_player ctrl={get_player_ctrl} ({len(gp)} bytes)")
        print(f"     hex: {gp.hex()}")
        sock.sendall(gp)

        # --- Phase 5: receive and decode get_player response ---
        player_decoded = False
        while True:
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed")
                    break
                ctrl, cmd, inner = parse_outer(data)
                print(f"[<<] {len(data)} bytes  ctrl={ctrl}  cmd={cmd}  inner={len(inner)}b")
                print(f"     hex: {data.hex()}")

                if cmd == "get_player":
                    if inner:
                        print_player(inner)
                        player_decoded = True
                    else:
                        print("[!] get_player response has no inner payload (server error/empty)")
                    break
                elif cmd == "ping":
                    # Server may send another ping — respond and keep waiting
                    resp = make_ping_response(ctrl, inner)
                    sock.sendall(resp)
                    print(f"[>>] Ping responded ctrl={ctrl}")

            except socket.timeout:
                print("[<<] timeout")
                break
            except Exception as e:
                print(f"[!!] {e}")
                break

        if not player_decoded:
            print("[!] Never received get_player response")


if __name__ == "__main__":
    main()