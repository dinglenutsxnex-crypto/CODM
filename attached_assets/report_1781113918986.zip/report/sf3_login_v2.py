import socket
import struct
import zlib
import hashlib
import re
import time

HOST = "ec2-13-126-233-176.ap-south-1.compute.amazonaws.com"
PORT = 443
GUID = "289a6ff9-15d5-48aa-95f2-dfcfebedfab8"
GAME_VERSION = "1.45.0.2.16662-prod"

HANDSHAKE_TX = bytes.fromhex(
    "011b0801120948414e445348414b451a0c0a0a5346412d4e4542552d31"
)

ORIGINAL_INNER = bytes.fromhex(
    "080612620801125e7b226c6f67696e223a2232383961366666392d313564352d343861"
    "612d393566322d646663666562656466616238222c2270617373776f7264223a226431"
    "363435326564366639383633633631313138623432663339303932343561"
    "227d1a7b080d12777b2274223a22342f3041646b564c5077453748774543742d4a555737"
    "526c46463554624e7547577a48506b41565969777573565236326c4156336a493379514352635a7069706d6e"
    "4443445f667941222c226964223a22673136363133383934363134373335323534393337"
    "222c2265223a747275657d1a14080612103731396533343138383431636162636422dc01"
    "7b22706c6174666f726d223a22416e64726f6964222c2276223a223139323032222c22"
    "6170705f6964223a22636f6d2e6e656b6b692e736861646f77666967687433222c2266"
    "223a2241433631453146303336363646384432354541324238353330434339414635"
    "454538303745363836222c22626e756d626572223a223139323032222c22626e616d65"
    "223a22556e697479436c69656e745f536861646f774669676874335f556e697479436c"
    "69656e74536861646f7746696768743352656c656173655f436f6e66696775726174696f"
    "6e416e64726f6964227d"
)

ORIGINAL_PASSWORD = b"d16452ed6f9863c61118b42f3909245a"

# Stale fingerprint from a real captured session of the same account.
# The server compares this SHA1 against its own stored player-data checksum.
# If they don't match → server pushes get_player.
# All-zeros ("0"*40) triggers a "fresh install" code path on the server that
# does NOT push — the server just sits in keepalive pings waiting for something.
# Using a real (but outdated) SHA1 forces the mismatch path and gets the push.
# Do NOT use the server's own checksum ("D7914E58...") — that would match and
# suppress the push ("client is up to date").
STALE_FINGERPRINT = "36455C3E36075A6545181B460AF344FF1DCD053F"

CURRENCY_TYPE = {0: "Unknown", 1: "Coin", 2: "Bonus", 3: "Shadow"}


# ---- protobuf helpers -------------------------------------------------------

def encode_varint(v):
    out = b""
    while True:
        bits = v & 0x7F
        v >>= 7
        out += bytes([bits | (0x80 if v else 0)])
        if not v:
            break
    return out


def encode_string_field(field_num, s):
    encoded = s.encode()
    return encode_varint((field_num << 3) | 2) + encode_varint(len(encoded)) + encoded


def encode_message_field(field_num, payload):
    return encode_varint((field_num << 3) | 2) + encode_varint(len(payload)) + payload


def read_varint(data, pos):
    val, shift = 0, 0
    while True:
        b = data[pos]; pos += 1
        val |= (b & 0x7F) << shift; shift += 7
        if not (b & 0x80):
            break
    return val, pos


def decode_proto(data, depth=0):
    fields = []
    pos = 0
    while pos < len(data):
        try:
            tag, pos = read_varint(data, pos)
            field_num = tag >> 3
            wire = tag & 0x07
            if wire == 0:
                val, pos = read_varint(data, pos)
                fields.append((field_num, 0, val))
            elif wire == 1:
                val = struct.unpack_from("<d", data, pos)[0]
                pos += 8
                fields.append((field_num, 1, val))
            elif wire == 2:
                length, pos = read_varint(data, pos)
                raw = data[pos:pos + length]; pos += length
                fields.append((field_num, 2, raw))
            elif wire == 5:
                val = struct.unpack_from("<f", data, pos)[0]
                pos += 4
                fields.append((field_num, 5, val))
            else:
                break
        except Exception:
            break
    return fields


def try_utf8(raw):
    try:
        s = raw.decode("utf-8")
        return s if all(c >= " " or c in "\t\n\r" for c in s) else None
    except Exception:
        return None


# ---- packet builders --------------------------------------------------------

def make_small_packet(outer_payload):
    assert len(outer_payload) <= 255
    return bytes([0x01, len(outer_payload)]) + outer_payload


def make_large_packet(outer_payload):
    compressed = zlib.compress(outer_payload, 6)[2:-4]
    return bytes([0x02]) + struct.pack("<I", len(compressed)) + compressed


def build_outer(controller, command, inner=b""):
    payload = encode_varint((1 << 3) | 0) + encode_varint(controller)
    payload += encode_string_field(2, command)
    if inner:
        payload += encode_message_field(3, inner)
    return payload


def make_login_packet(session_token):
    new_password = hashlib.md5((session_token + GUID).encode()).hexdigest().encode()
    inner = ORIGINAL_INNER.replace(ORIGINAL_PASSWORD, new_password)
    if inner == ORIGINAL_INNER:
        raise ValueError("Password replacement failed — ORIGINAL_PASSWORD not found in ORIGINAL_INNER")
    outer = build_outer(2, "LOGIN", inner)
    return make_large_packet(outer)


def make_initial_ping():
    """
    Client-initiated ping sent immediately after join_zone.

    Exact structure from request_6 capture:
      ctrl=3 cmd="ping"
      inner:
        [1] { [1] = <current_unix_ms> }            -- client's own timestamp
        [2] { [1] = "net_data", [2] = "<SHA1>" }   -- fingerprint of local player cache

    The server compares the SHA1 against its own checksum of the player state.
    Mismatch → server pushes full get_player blob.
    We send STALE_FINGERPRINT so the server always detects a mismatch
    and pushes, since we have no local cache.

    The server echoes [1] back and adds its own timestamp as [2] in its ack.
    get_player arrives right after that ack.

    NOTE: the client is NOT responding to a server ping here — it initiates.
    The server does NOT send a ping first. Waiting for one causes a timeout.
    """
    ts_ms = int(time.time() * 1000)
    # Submessage = { field[1] varint = ts_ms }
    # Must encode as: 0x08 (field 1 wire 0 tag) + varint bytes
    # NOT just raw varint — that omits the field tag and produces a malformed 8-byte
    # submessage instead of the correct 9-byte one, causing the server to ignore net_data.
    ts_inner = encode_varint((1 << 3) | 0) + encode_varint(ts_ms)  # 0x08 + varint
    ts_submsg = encode_message_field(1, ts_inner)
    net_data_inner = encode_string_field(1, "net_data") + encode_string_field(2, STALE_FINGERPRINT)
    inner = ts_submsg + encode_message_field(2, net_data_inner)
    outer = build_outer(3, "ping", inner)
    pkt = make_small_packet(outer)
    assert len(pkt) == 75, f"Ping size mismatch: {len(pkt)} != 75"
    return pkt


def make_ping_ack(ctrl, server_ping_inner):
    """Respond to any subsequent server-initiated pings to keep the session alive."""
    server_ts_submsg = b""
    for fn, wire, val in decode_proto(server_ping_inner):
        if fn == 1 and wire == 2:
            server_ts_submsg = val
            break
    ts_ms = int(time.time() * 1000)
    our_ts_submsg = encode_message_field(1, encode_varint(ts_ms))
    inner = encode_message_field(1, server_ts_submsg) + encode_message_field(2, our_ts_submsg)
    outer = build_outer(ctrl, "ping", inner)
    return make_small_packet(outer)


# ---- recv helpers -----------------------------------------------------------

def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_packet(sock):
    """
    Framing (verified from captures):
      0x01 [1B len] [payload]                      -- small, plain
      0x02 [4B LE len] [raw-deflate payload]        -- large, compressed
    Any other first byte is an unknown frame type and returns (None, None).
    """
    header = recv_exact(sock, 1)
    if not header:
        return None, None
    t = header[0]
    if t == 0x01:
        size_raw = recv_exact(sock, 1)
        if not size_raw:
            return None, None
        size = size_raw[0]
    elif t == 0x02:
        size_raw = recv_exact(sock, 4)
        if not size_raw:
            return None, None
        size = struct.unpack("<I", size_raw)[0]
        if size > 4 * 1024 * 1024:  # sanity: reject >4MB
            print(f"[!] Oversized packet ({size}B) — probably an encrypted frame, stopping")
            return None, None
    else:
        print(f"[!] Unknown framing byte 0x{t:02x} — not an SF3 packet (encrypted sub-protocol?), stopping")
        return None, None
    data = recv_exact(sock, size)
    if data is None:
        return None, None
    if t == 0x02:
        try:
            data = zlib.decompress(data, -15)
        except Exception as e:
            print(f"[!] Decompress failed: {e}")
            return None, None
    return t, data


def parse_outer(data):
    fields = decode_proto(data)
    controller, command, inner = None, None, b""
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            controller = val
        elif fn == 2 and wire == 2:
            s = try_utf8(val)
            if s:
                command = s
        elif fn == 3 and wire == 2:
            inner = val
    return controller, command, inner


def extract_session_token(data):
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in data)
    tokens = re.findall(r"[0-9a-f]{7,}-[0-9a-f]{6,}-[0-9a-f]{6,}", text)
    return tokens[0] if tokens else None


# ---- player decoder ---------------------------------------------------------

def decode_currencies(raw):
    fields = decode_proto(raw)
    ctype, value = 0, 0
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            ctype = val
        elif fn == 2 and wire == 0:
            value = val
    name = CURRENCY_TYPE.get(ctype, f"type_{ctype}")
    return name, value


def decode_item(raw):
    fields = decode_proto(raw)
    model_id, stack_level, equipped = 0, 0.0, False
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            model_id = val
        elif fn == 2 and wire == 1:
            stack_level = val
        elif fn == 3 and wire == 0:
            equipped = bool(val)
    return model_id, stack_level, equipped


def decode_short_player(raw):
    fields = decode_proto(raw)
    info = {}
    for fn, wire, val in fields:
        if fn == 1 and wire == 0:
            info["playerId"] = val
        elif fn == 2 and wire == 2:
            info["nickname"] = try_utf8(val) or ""
        elif fn == 3 and wire == 2:
            info["displayName"] = try_utf8(val) or ""
        elif fn == 4 and wire == 0:
            info["level"] = val
    return info


def decode_public_player(raw):
    fields = decode_proto(raw)
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            return decode_short_player(val)
    return {}


def decode_inventory(raw):
    fields = decode_proto(raw)
    items, perks, boosters = [], [], []
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            items.append(decode_item(val))
        elif fn == 2 and wire == 2:
            perks.append(val)
        elif fn == 3 and wire == 2:
            boosters.append(val)
    return items, perks, boosters


def decode_player(raw):
    fields = decode_proto(raw)
    result = {"currencies": [], "items": []}
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            s = try_utf8(val)
            if s and len(s) > 5:
                result["version"] = s
            else:
                pp = decode_public_player(val)
                if pp:
                    result.update(pp)
                else:
                    inner_result = decode_player(val)
                    result.update(inner_result)
        elif fn == 2 and wire == 0:
            result["permissions"] = val
        elif fn == 3 and wire == 0:
            result["experience"] = val
        elif fn == 4 and wire == 2:
            name, value = decode_currencies(val)
            result["currencies"].append((name, value))
        elif fn == 5 and wire == 2:
            pass
        elif fn == 7 and wire == 2:
            items, perks, boosters = decode_inventory(val)
            result["items"] = items
            result["perk_count"] = len(perks)
            result["booster_count"] = len(boosters)
        elif fn == 9 and wire == 0:
            result["chapterId"] = val
        elif fn == 10 and wire == 0:
            result["offlineStateId"] = val
        elif fn == 11 and wire == 2:
            s = try_utf8(val)
            if s:
                result["abTag"] = s
        elif fn == 13 and wire == 1:
            result["rating"] = round(val, 2)
    return result


def decode_extended_player(raw):
    fields = decode_proto(raw)
    result = {}
    for fn, wire, val in fields:
        if fn == 1 and wire == 2:
            result = decode_player(val)
            result["_source"] = "primaryPlayer"
        elif fn == 3 and wire == 2:
            acc_fields = decode_proto(val)
            for afn, awire, aval in acc_fields:
                if afn == 1 and awire == 2:
                    s = try_utf8(aval)
                    if s:
                        result["account_login"] = s
    return result


def print_player(data):
    print("\n" + "=" * 60)
    print("  PLAYER DATA")
    print("=" * 60)

    player = decode_extended_player(data)
    if not player.get("nickname") and not player.get("experience"):
        player = decode_player(data)

    if not player:
        print("  Could not decode player data")
        return

    if "version" in player:
        print(f"  Server version : {player['version']}")
    if "displayName" in player or "nickname" in player:
        print(f"  Nickname       : {player.get('nickname', '?')}")
        print(f"  Display name   : {player.get('displayName', '?')}")
    if "playerId" in player:
        print(f"  Player ID      : {player['playerId']}")
    if "level" in player:
        print(f"  Level          : {player['level']}")
    if "experience" in player:
        print(f"  Experience     : {player['experience']}")
    if "chapterId" in player:
        print(f"  Chapter        : {player['chapterId']}")
    if "rating" in player:
        print(f"  Rating         : {player['rating']}")
    if "account_login" in player:
        print(f"  Account login  : {player['account_login']}")
    if player.get("currencies"):
        print(f"\n  Currencies:")
        for name, val in player["currencies"]:
            print(f"    {name:<10} : {val:,}")
    if player.get("items"):
        equipped = [(m, s) for m, s, e in player["items"] if e]
        unequipped = [(m, s) for m, s, e in player["items"] if not e]
        print(f"\n  Inventory      : {len(player['items'])} items ({len(equipped)} equipped)")
        if equipped:
            print(f"  Equipped items :")
            for model_id, stack in equipped:
                print(f"    model {model_id:<6} stack={stack:.2f}")
    if "perk_count" in player:
        print(f"  Perks          : {player['perk_count']}")
    if "booster_count" in player:
        print(f"  Boosters       : {player['booster_count']}")
    if "offlineStateId" in player:
        print(f"\n  Offline state  : {player['offlineStateId']}")
    if "abTag" in player:
        print(f"  AB tag         : {player['abTag']}")
    if "permissions" in player:
        print(f"  Permissions    : {player['permissions']}")
    print("=" * 60)


# ---- main -------------------------------------------------------------------

def main():
    print(f"[*] Connecting to {HOST}:{PORT}")
    with socket.create_connection((HOST, PORT), timeout=10) as sock:
        sock.settimeout(8)

        # --- Phase 1: Handshake ---
        sock.sendall(HANDSHAKE_TX)
        _, raw_hs = recv_packet(sock)
        session_token = extract_session_token(raw_hs)
        print(f"[+] Handshake OK")
        print(f"[+] Session token: {session_token}")

        if not session_token:
            print("[!] No session token, aborting")
            return

        password = hashlib.md5((session_token + GUID).encode()).hexdigest()
        print(f"[+] GUID:     {GUID}")
        print(f"[+] Password: {password}")

        # --- Phase 2: Login ---
        pkt = make_login_packet(session_token)
        print(f"\n[>>] Sending LOGIN ({len(pkt)} bytes)")
        sock.sendall(pkt)

        # Drain login pushes, wait for join_zone
        join_zone_received = False
        for _ in range(10):
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed during login phase")
                    return
                _, cmd, _ = parse_outer(data)
                print(f"[<<] {len(data)} bytes  cmd={cmd}")
                if cmd == "join_zone":
                    join_zone_received = True
                    break
            except socket.timeout:
                break

        if not join_zone_received:
            print("[!] Did not receive join_zone — proceeding anyway")

        # --- Phase 3: Send initial ping with net_data fingerprint ---
        #
        # ACTUAL FLOW (from captures — client initiates, not the server):
        #   client → server  ping ctrl=3  { ts, net_data="<SHA1>" }   ← we send this
        #   server → client  ping ack     { echo_ts, server_ts }
        #   server → client  get_player   PUSHED (19KB+), not requested
        #
        # The net_data SHA1 is the fingerprint of the client's locally cached player
        # state. Mismatch with server → server pushes full player blob.
        # We send STALE_FINGERPRINT so server always detects mismatch and pushes.
        #
        # WRONG assumption in v1: server pings first, client responds.
        # Reality: client sends ping immediately after join_zone.
        # Waiting for server ping → 4s timeout → get_player never comes.

        ping_pkt = make_initial_ping()
        print(f"[>>] Sending initial ping with net_data ctrl=3 ({len(ping_pkt)} bytes)")
        sock.sendall(ping_pkt)

        # --- Phase 4: Wait for server-pushed get_player ---
        #
        # Server sends: ping ack (small) → get_player push (large ~9KB compressed)
        # We drain until we see get_player.

        sock.settimeout(10)
        player_decoded = False
        print("[*] Waiting for server to push get_player...")

        while True:
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed or unknown frame")
                    break
                ctrl, cmd, inner = parse_outer(data)
                hex_preview = data[:32].hex()
                print(f"[<<] {len(data)} bytes  ctrl={ctrl}  cmd={cmd}  inner={len(inner)}B  hex={hex_preview}")

                if cmd == "get_player":
                    if inner:
                        print_player(inner)
                        player_decoded = True
                    else:
                        print("[!] get_player push had no inner payload")
                    break
                elif cmd == "ping":
                    # Server may send additional pings — respond to keep session alive
                    resp = make_ping_ack(ctrl, inner)
                    sock.sendall(resp)
                    print(f"[>>] Ping ack ctrl={ctrl}")
                elif cmd is None:
                    # Unrecognised packet — dump full hex for analysis
                    print(f"[<<] UNKNOWN cmd=None  full hex: {data.hex()}")
                else:
                    print(f"[<<] Ignoring push: {cmd}")

            except socket.timeout:
                print("[<<] Timeout waiting for get_player push")
                break
            except Exception as e:
                print(f"[!!] {e}")
                break

        if not player_decoded:
            print("[!] Never received get_player push")


if __name__ == "__main__":
    main()