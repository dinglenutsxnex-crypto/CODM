"""
sf3_login_v3.py — Shadow Fight 3 game-server client (fixed)

BUGS FIXED VS v2
================
1. make_ping_ack malformed proto: v2 used encode_varint(ts_ms) alone as the
   submessage; the 0x08 field-tag prefix was missing.  Fixed: inner submessage
   is now b"\x08" + encode_varint(ts_ms) → correct wire-type-0 field[1].

2. Infinite ping-pong loop: v2 responded to the server's ack of the net_data
   ping, which caused the server to keep echoing at ~0.3 s intervals, blocking
   the get_player push.  Fixed: first ping ack is received, then an explicit
   get_player request is sent (see Phase 3 notes below).

PROTOCOL NOTES (reverse-engineered from 43 captured packets)
=============================================================
Framing
  Small (payload ≤ 255 B): 0x01 [1B len] [raw protobuf]
  Large (any):              0x02 [4B LE len] [raw-deflate compressed protobuf]

Outer protobuf envelope
  field[1] varint  = controller  (1=system, 2=auth, 3=extension, 4=game)
  field[2] string  = command     ("HANDSHAKE", "LOGIN", "ping", "get_player" …)
  field[3] bytes   = nested params protobuf
  field[4] varint  = error code  (server → client only, on errors)
  field[5] bytes   = error msg   (server → client only, on errors)

Auth flow
  C→S: fixed HANDSHAKE_TX bytes
  S→C: session token in field[3].field[2]
  C→S: LOGIN with password = MD5(session_token + GUID)
  S→C: LOGIN ack (empty inner), then join_zone push

net_data ping (ctrl=3) inner structure
  field[1] bytes = ts_submsg  {field[1] varint = timestamp_ms}
  field[2] bytes = net_data_submsg {
      field[1] string = "net_data"
      field[2] string = SHA1_hex_fingerprint   ← client's cached state hash
  }
  → Server acks immediately (same ctrl=3, two ts sub-messages)
  → If SHA1 mismatches server's stored hash the server PUSHES get_player.
    This push is independent — no explicit get_player request needed.

get_player push / response inner structure
  field[1] string = game version echo ("1.45.0.2.16662-prod")
  field[2] bytes  = player data wrapper
      field[2] bytes = PlayerDTO protobuf
          field[1]  varint = player_id (internal)
          field[3]  varint = level
          field[4]  bytes  = currency {field[1]=type, field[2]=amount}
          field[5]  bytes  = battle records (17 KB)
          field[6]  varint = some checksum
          field[7]  bytes  = perk entries
          field[8]  varint = hash
          field[9]  bytes  = hero slot data
          field[10] bytes  = item entries
          field[12] bytes  = chapter progress
          field[13] varint = another checksum
          field[14] bytes  = additional entries
  field[3] bytes = summary {
      field[1] string = "sum"
      field[2] string = SHA1_hex  ← server's CURRENT player-state hash
                                     client must store and send in next ping
  }
  field[4] string = device model   ("samsung SM-X115")
  field[5] string = short version  ("1.45.0")

FINGERPRINT / SECURITY NOTE
============================
As of the current server version, an explicit get_player request (any value in
field[1] of the inner) always returns error 10004 "invalid fingerprint".  This
appears to be a server-side device-binding check added after the original
session was captured.  The auto-push via net_data SHA1 mismatch is also blocked
for sessions using replayed credentials.

Known values from the original capture:
  CLIENT_SHA1 = "36455C3E36075A6545181B460AF344FF1DCD053F"  (client's cached)
  SERVER_SHA1 = "D7914E58FDD8FF1BC1A3E2AC981C439B6E9DC972"  (server's stored)

Player data has been successfully decoded from the captured req_8.bin.
Player ID 60644, Level 55, Coin=131,909,667, Shadow=221,650.
"""

import socket
import struct
import zlib
import hashlib
import re
import sys
import time

HOST = "ec2-13-126-233-176.ap-south-1.compute.amazonaws.com"
ALT_HOST = "ec2-52-66-28-201.ap-south-1.compute.amazonaws.com"
PORT = 443
GUID = "289a6ff9-15d5-48aa-95f2-dfcfebedfab8"
GAME_VERSION = "1.45.0.2.16662-prod"

HANDSHAKE_TX = bytes.fromhex(
    "011b0801120948414e445348414b451a0c0a0a5346412d4e4542552d31"
)

ORIGINAL_INNER = bytes.fromhex(
    "080612620801125e7b226c6f67696e223a2232383961366666392d313564352d343861"
    "612d393566322d646663666562656466616238222c2270617373776f7264223a226431"
    "363435326564366639383633633631313138623432663339303932343561"
    "227d1a7b080d12777b2274223a22342f3041646b564c5077453748774543742d4a555737"
    "526c46463554624e7547577a48506b41565969777573565236326c4156336a493379514352635a7069706d6e"
    "4443445f667941222c226964223a22673136363133383934363134373335323534393337"
    "222c2265223a747275657d1a14080612103731396533343138383431636162636422dc01"
    "7b22706c6174666f726d223a22416e64726f6964222c2276223a223139323032222c22"
    "6170705f6964223a22636f6d2e6e656b6b692e736861646f77666967687433222c2266"
    "223a2241433631453146303336363646384432354541324238353330434339414635"
    "454538303745363836222c22626e756d626572223a223139323032222c22626e616d65"
    "223a22556e697479436c69656e745f536861646f774669676874335f556e697479436c"
    "69656e74536861646f7746696768743352656c656173655f436f6e66696775726174696f"
    "6e416e64726f6964227d"
)

ORIGINAL_PASSWORD = b"d16452ed6f9863c61118b42f3909245a"

# SHA1 from captured session (client's cached hash sent in net_data ping).
# Server's stored hash at capture time: D7914E58FDD8FF1BC1A3E2AC981C439B6E9DC972
STALE_FINGERPRINT = "36455C3E36075A6545181B460AF344FF1DCD053F"

CURRENCY_TYPE = {
    1: "Coin",
    2: "Bonus",
    3: "Shadow",
}


# ---- protobuf helpers -------------------------------------------------------

def encode_varint(v):
    out = b""
    while True:
        bits = v & 0x7F
        v >>= 7
        out += bytes([bits | (0x80 if v else 0)])
        if not v:
            break
    return out


def encode_string_field(field_num, s):
    encoded = s.encode()
    return encode_varint((field_num << 3) | 2) + encode_varint(len(encoded)) + encoded


def encode_message_field(field_num, payload):
    return encode_varint((field_num << 3) | 2) + encode_varint(len(payload)) + payload


def read_varint(data, pos):
    val, shift = 0, 0
    while pos < len(data):
        b = data[pos]; pos += 1
        val |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            break
    return val, pos


def decode_proto(data):
    """Yield (field_num, wire_type, value) tuples from raw protobuf bytes."""
    fields = []
    pos = 0
    while pos < len(data):
        try:
            tag, pos = read_varint(data, pos)
            fn = tag >> 3
            wire = tag & 7
            if fn == 0:
                break
            if wire == 0:
                val, pos = read_varint(data, pos)
                fields.append((fn, 0, val))
            elif wire == 2:
                length, pos = read_varint(data, pos)
                if pos + length > len(data):
                    break
                raw = data[pos:pos + length]
                pos += length
                fields.append((fn, 2, raw))
            else:
                break
        except Exception:
            break
    return fields


def try_utf8(raw):
    """Return UTF-8 decoded string if printable, else None."""
    try:
        s = raw.decode("utf-8")
        if all(32 <= ord(c) < 127 or c in "\t\n\r" for c in s):
            return s
    except Exception:
        pass
    return None


# ---- packet helpers ---------------------------------------------------------

def make_small_packet(payload):
    assert len(payload) <= 255, f"Payload too large for small packet: {len(payload)}"
    return bytes([0x01, len(payload)]) + payload


def make_large_packet(payload):
    compressed = zlib.compress(payload, 6)[2:-4]
    return bytes([0x02]) + struct.pack("<I", len(compressed)) + compressed


def build_outer(ctrl, cmd, inner=b""):
    p = encode_varint((1 << 3) | 0) + encode_varint(ctrl)
    p += encode_string_field(2, cmd)
    if inner:
        p += encode_message_field(3, inner)
    return p


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_packet(sock):
    """Receive one framed packet; return (frame_type, decompressed_bytes)."""
    header = recv_exact(sock, 1)
    if not header:
        return None, None
    t = header[0]
    if t == 0x01:
        sz = recv_exact(sock, 1)
        size = sz[0]
    elif t == 0x02:
        sz = recv_exact(sock, 4)
        size = struct.unpack("<I", sz)[0]
    else:
        return None, None
    data = recv_exact(sock, size)
    if data is None:
        return None, None
    if t == 0x02:
        try:
            data = zlib.decompress(data, -15)
        except zlib.error:
            return None, None
    return t, data


def parse_outer(data):
    """Return (ctrl, cmd, inner, extra_dict) from outer protobuf."""
    ctrl = None
    cmd = None
    inner = b""
    extra = {}
    for fn, wire, val in decode_proto(data):
        if fn == 1 and wire == 0:
            ctrl = val
        elif fn == 2 and wire == 2:
            s = try_utf8(val)
            if s:
                cmd = s
        elif fn == 3 and wire == 2:
            inner = val
        elif fn == 4 and wire == 0:
            extra["code"] = val
        elif fn == 5 and wire == 2:
            extra["msg"] = val.decode(errors="replace")
    return ctrl, cmd, inner, extra


# ---- session helpers --------------------------------------------------------

def extract_session_token(data):
    """Pull the session token string out of the HANDSHAKE response."""
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in data)
    matches = re.findall(r"[0-9a-f]{7,}-[0-9a-f]{6,}-[0-9a-f]{6,}", text)
    return matches[0] if matches else None


def make_login_packet(session_token):
    """Build the LOGIN packet with freshly-computed MD5 password."""
    pw = hashlib.md5((session_token + GUID).encode()).hexdigest().encode()
    inner = ORIGINAL_INNER.replace(ORIGINAL_PASSWORD, pw)
    return make_large_packet(build_outer(2, "LOGIN", inner))


# ---- packet builders --------------------------------------------------------

def make_initial_ping():
    """
    net_data ping (ctrl=3).  Inner structure:
      field[1] = ts_submsg      { field[1] varint = timestamp_ms }
      field[2] = net_data_inner { field[1] string = "net_data",
                                  field[2] string = SHA1_fingerprint }

    The SHA1 is the client's cached hash of the last server-pushed player state.
    Mismatch → server pushes get_player automatically (no explicit request needed).
    """
    ts_ms = int(time.time() * 1000)
    ts_submsg = b"\x08" + encode_varint(ts_ms)
    net_data_inner = (
        encode_string_field(1, "net_data")
        + encode_string_field(2, STALE_FINGERPRINT)
    )
    inner = (
        encode_message_field(1, ts_submsg)
        + encode_message_field(2, net_data_inner)
    )
    outer = build_outer(3, "ping", inner)
    return make_small_packet(outer)


def make_ping_ack(ctrl, server_ping_inner):
    """
    Respond to a server ping.  Mirrors the server's ts[1] submessage and
    appends our own timestamp as ts[2].

    FIX vs v2: the inner submessage must be   b"\\x08" + encode_varint(ts_ms)
    (field-tag 0x08 = field[1] wire-type-0 + value).  v2 omitted the tag.
    """
    server_ts_submsg = b""
    for fn, wire, val in decode_proto(server_ping_inner):
        if fn == 1 and wire == 2:
            server_ts_submsg = val
            break

    our_ts_inner = b"\x08" + encode_varint(int(time.time() * 1000))
    ack_inner = (
        encode_message_field(1, server_ts_submsg)
        + encode_message_field(2, our_ts_inner)
    )
    outer = build_outer(ctrl, "ping", ack_inner)
    return make_small_packet(outer)


def make_get_player_packet(ctrl):
    """
    Explicit get_player request.
    field[1] of inner = GAME_VERSION string.

    NOTE: As of the current server, this returns error 10004 "invalid
    fingerprint" for any value of field[1].  The server has added a
    device-binding check (likely validating the FCM/GCM token or device
    fingerprint from login) that rejects sessions using replayed credentials.
    The original auto-push via net_data SHA1 mismatch is the intended path.
    """
    inner = encode_string_field(1, GAME_VERSION)
    outer = build_outer(ctrl, "get_player", inner)
    return make_small_packet(outer)


# ---- player data decoder ----------------------------------------------------

def decode_player_data(inner):
    """
    Decode the get_player response inner and print human-readable player info.

    get_player inner layout:
      field[1] string  = game version echo
      field[2] bytes   = player data wrapper
          field[2] bytes = PlayerDTO protobuf
      field[3] bytes   = summary { field[1]="sum", field[2]=SHA1 }
      field[4] string  = device model
      field[5] string  = short version
    """
    result = {}
    gp_fields = decode_proto(inner)

    version = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 1 and wt == 2), None)
    wrapper  = next((v for fn, wt, v in gp_fields if fn == 2 and wt == 2), None)
    summary  = next((v for fn, wt, v in gp_fields if fn == 3 and wt == 2), None)
    device   = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 4 and wt == 2), None)
    short_v  = next((try_utf8(v) for fn, wt, v in gp_fields if fn == 5 and wt == 2), None)

    print(f"\n{'='*60}")
    print(f"  get_player Response")
    print(f"{'='*60}")
    print(f"  Version      : {version}")
    print(f"  Device       : {device}")
    print(f"  Short ver    : {short_v}")

    if summary:
        sf = decode_proto(summary)
        sum_label = next((try_utf8(v) for fn, wt, v in sf if fn == 1 and wt == 2), "?")
        sum_hash  = next((try_utf8(v) for fn, wt, v in sf if fn == 2 and wt == 2), "?")
        print(f"  Server SHA1  : {sum_hash}  (label={sum_label})")
        result["server_sha1"] = sum_hash

    if not wrapper:
        print("  [!] No player wrapper (field[2]) found")
        return result

    # Unwrap one level: field[2] of the wrapper
    wrapper_fields = decode_proto(wrapper)
    player_data = next((v for fn, wt, v in wrapper_fields if fn == 2 and wt == 2), None)
    if not player_data:
        print("  [!] No PlayerDTO (field[2][2]) found")
        return result

    pd = decode_proto(player_data)

    player_id = next((v for fn, wt, v in pd if fn == 1 and wt == 0), None)
    level      = next((v for fn, wt, v in pd if fn == 3 and wt == 0), None)

    print(f"\n  --- Player ---")
    print(f"  GUID         : {GUID}")
    print(f"  Player ID    : {player_id}")
    print(f"  Level        : {level}")
    result.update({"player_id": player_id, "level": level})

    # Currencies: field[4] repeated, each is {field[1]=type, field[2]=amount}
    currencies = {}
    for fn, wt, v in pd:
        if fn == 4 and wt == 2:
            cf = decode_proto(v)
            ctype  = next((cv for cfn, cwt, cv in cf if cfn == 1 and cwt == 0), None)
            amount = next((cv for cfn, cwt, cv in cf if cfn == 2 and cwt == 0), None)
            if ctype is not None:
                currencies[ctype] = amount

    print(f"\n  --- Currencies ---")
    named = [(ctype, currencies[ctype]) for ctype in sorted(currencies)
             if ctype in CURRENCY_TYPE]
    for ctype, amount in named:
        print(f"  {CURRENCY_TYPE[ctype]:10s}: {amount:,}")
    # Also show first few unrecognized types
    others = [(ctype, currencies[ctype]) for ctype in sorted(currencies)
              if ctype not in CURRENCY_TYPE][:5]
    if others:
        print(f"  ... and {len([c for c in currencies if c not in CURRENCY_TYPE])} "
              f"resource types (IDs {min(c for c in currencies if c not in CURRENCY_TYPE)}"
              f"–{max(c for c in currencies if c not in CURRENCY_TYPE)})")
    result["currencies"] = currencies

    # Hero slots: field[9], each {field[1]=slot_id, field[2]=level}
    slots = []
    for fn, wt, v in pd:
        if fn == 9 and wt == 2:
            sf2 = decode_proto(v)
            slot_id = next((sv for sfn, swt, sv in sf2 if sfn == 1 and swt == 0), None)
            slot_lv = next((sv for sfn, swt, sv in sf2 if sfn == 2 and swt == 0), None)
            if slot_id is not None:
                slots.append((slot_id, slot_lv))
    if slots:
        print(f"\n  --- Hero Slots (soul power) ---")
        for slot_id, slot_lv in slots:
            print(f"  Slot {slot_id}: {slot_lv:,}")

    # Item count
    item_count = sum(1 for fn, wt, v in pd if fn == 10 and wt == 2)
    print(f"\n  --- Inventory ---")
    print(f"  Items owned  : {item_count}")

    return result


# ---- main -------------------------------------------------------------------

def main():
    # --offline mode: decode the captured req_8.bin without connecting
    if "--offline" in sys.argv:
        import zipfile, os
        zip_path = "attached_assets/sf3_client_1780936284179.zip"
        if not os.path.exists(zip_path):
            print("[!] Capture zip not found; run from workspace root")
            return
        with zipfile.ZipFile(zip_path) as outer:
            for name in outer.namelist():
                if name.endswith(".zip"):
                    import io
                    inner_zip_data = outer.read(name)
                    with zipfile.ZipFile(io.BytesIO(inner_zip_data)) as inner:
                        req8 = inner.read("server_responce_extracted/request_8.bin")
        payload = zlib.decompress(req8[5:], -15)
        _, _, inner_data, _ = parse_outer(payload)
        if inner_data:
            decode_player_data(inner_data)
        else:
            print("[!] Could not find inner in req_8.bin")
        return

    print(f"[*] Connecting to {HOST}:{PORT}")
    with socket.create_connection((HOST, PORT), timeout=10) as sock:
        sock.settimeout(8)

        # --- Phase 1: Handshake ---
        sock.sendall(HANDSHAKE_TX)
        _, raw_hs = recv_packet(sock)
        session_token = extract_session_token(raw_hs)
        if not session_token:
            print("[!] No session token, aborting")
            return
        print(f"[+] Handshake OK")
        print(f"[+] Session token: {session_token}")

        password = hashlib.md5((session_token + GUID).encode()).hexdigest()
        print(f"[+] GUID:     {GUID}")
        print(f"[+] Password: {password}")

        # --- Phase 2: Login and wait for join_zone ---
        pkt = make_login_packet(session_token)
        print(f"\n[>>] Sending LOGIN ({len(pkt)} bytes)")
        sock.sendall(pkt)

        join_zone_received = False
        for _ in range(10):
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed during login phase")
                    return
                _, cmd, _, _ = parse_outer(data)
                print(f"[<<] {len(data)} bytes  cmd={cmd}")
                if cmd == "join_zone":
                    join_zone_received = True
                    break
            except socket.timeout:
                break

        if not join_zone_received:
            print("[!] Did not receive join_zone — proceeding anyway")

        # --- Phase 3: net_data ping → ack → explicit get_player ---
        #
        # Real flow from captures (req_6 → req_7 → req_8):
        #   C→S  ping ctrl=3  { ts_submsg, net_data SHA1 }
        #   S→C  ping ack     { echo_ts, server_ts }         ← auto-pushed response
        #   S→C  get_player PUSH                              ← NO explicit client request
        #
        # The server pushes get_player automatically when the client's SHA1
        # (in the net_data ping) differs from the server's stored player hash.
        #
        # CURRENT LIMITATION: the server now applies a device-fingerprint check
        # that blocks the auto-push and also rejects explicit get_player requests
        # with error 10004 "invalid fingerprint" for sessions using replayed
        # credentials.  The explicit request is sent as best-effort fallback.
        #
        ping_pkt = make_initial_ping()
        print(f"\n[>>] Sending net_data ping ctrl=3 ({len(ping_pkt)} bytes)")
        sock.sendall(ping_pkt)

        # --- Phase 4: Receive and handle responses ---
        sock.settimeout(10)
        player_decoded = False
        got_initial_ack = False

        print("[*] Waiting for get_player push (or explicit request response)...")

        while True:
            try:
                _, data = recv_packet(sock)
                if data is None:
                    print("[<<] Connection closed")
                    break

                ctrl, cmd, inner, extra = parse_outer(data)
                print(f"[<<] {len(data)} bytes  ctrl={ctrl}  cmd={cmd}  "
                      f"inner={len(inner)}B  hex={data[:28].hex()}")

                if cmd == "get_player":
                    if inner:
                        decode_player_data(inner)
                        player_decoded = True
                    else:
                        err_code = extra.get("code", "?")
                        err_msg  = extra.get("msg", "")
                        print(f"[!] get_player error {err_code}: {err_msg}")
                    break

                elif cmd == "ping":
                    if not got_initial_ack:
                        # First ping = server ack of our net_data ping.
                        # Respond, then immediately send explicit get_player.
                        got_initial_ack = True
                        ack = make_ping_ack(ctrl, inner)
                        sock.sendall(ack)
                        print(f"[>>] Ping ack ctrl={ctrl}")

                        # Explicit get_player (best-effort; likely blocked server-side)
                        gp_ctrl = ctrl + 1
                        gp_pkt = make_get_player_packet(gp_ctrl)
                        sock.sendall(gp_pkt)
                        print(f"[>>] Explicit get_player ctrl={gp_ctrl} ({len(gp_pkt)} bytes)")
                    else:
                        # Subsequent keepalive ping — respond to stay alive
                        ack = make_ping_ack(ctrl, inner)
                        sock.sendall(ack)
                        print(f"[>>] Keepalive ping ack ctrl={ctrl}")

                elif cmd is None:
                    print(f"[<<] UNKNOWN  full hex: {data.hex()}")
                else:
                    print(f"[<<] Ignoring cmd={cmd!r}")

            except socket.timeout:
                print("[<<] Timeout waiting for get_player")
                break
            except Exception as e:
                print(f"[!!] {e}")
                break

        if not player_decoded:
            print("\n[!] Never received get_player data from live server.")
            print("    Run with --offline to decode the captured req_8.bin instead.")


if __name__ == "__main__":
    main()
