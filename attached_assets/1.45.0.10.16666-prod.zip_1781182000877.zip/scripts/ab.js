var AbTestsGlobal=[];var AbTestsChina=[];var ABTests=getGlOrCn(AbTestsGlobal,AbTestsChina);checkPartSums(ABTests);var ABTestsMap=createABTestsMap(ABTests);createTestsPaths(ABTestsMap);function chooseABTag(state){RandomInstance.setSeed(positiveHashCode(state.deviceID)%MAX_SAFE_INTEGER);var randomNumber=RandomInstance.nextDouble();var partSum=0;for(var _i=0,ABTests_1=ABTests;_i<ABTests_1.length;_i++){var group=ABTests_1[_i];if((!group.Countries&&!group.ExcludeCountries)||(group.Countries&&group.Countries.indexOf(state.countryCode)!=-1)||(group.ExcludeCountries&&group.ExcludeCountries.indexOf(state.countryCode)==-1)){if(!group.Platform||group.Platform.indexOf(state.platform)!=-1){partSum+=group.Part;if(partSum>randomNumber){return group.Tag;}}}}
return null;}
function updateABTag(state){if(state.hostPlayerTag&&hasABTag(state.hostPlayerTag)){return state.hostPlayerTag;}
var exitGroupFlag=false;for(var _i=0,ABTests_2=ABTests;_i<ABTests_2.length;_i++){var group=ABTests_2[_i];if(group.Tag===state.playerTag){if(group.ExitCondition&&group.ExitCondition(state.playerID,state.countryCode,state.companyName)){exitGroupFlag=true;continue;}}
if(group.UpdateABTagCondition&&group.UpdateABTagCondition(state.playerTag,state.playerID,state.countryCode,state.mainBattleID,state.companyName)){return group.Tag;}}
if(exitGroupFlag||Object.keys(ABTestsMap).indexOf(state.playerTag)===-1){return null;}
else{return state.playerTag;}}
function hasABTag(tag){return ABTestsMap.hasOwnProperty(tag);}
function getABTagList(){return Object.keys(ABTestsMap).filter(function(tag){return!ABTestsMap[tag].IsLightWeight;});}
function getLightweightAbTagList(){return Object.keys(ABTestsMap).filter(function(tag){return ABTestsMap[tag].IsLightWeight;});}
function getPathByABTag(tag){return ABTestsMap[tag].Path;}
function checkPartSums(settings){var partSumsByPlatforms={};var _loop_1=function(group){if(!group.Countries){var platforms=group.Platform?group.Platform:allPlatforms;platforms.forEach(function(platform){partSumsByPlatforms[platform]=partSumsByPlatforms[platform]?partSumsByPlatforms[platform]+group.Part:group.Part;});}};for(var _i=0,settings_1=settings;_i<settings_1.length;_i++){var group=settings_1[_i];_loop_1(group);}
for(var platform in partSumsByPlatforms){if(partSumsByPlatforms[platform]>1){throw new Error("Part sum more than 1 for platform: "+Platform[platform]+".");}}}
function createABTestsMap(settings){var result={};for(var _i=0,settings_2=settings;_i<settings_2.length;_i++){var group=settings_2[_i];result[group.Tag]=group;}
return result;}
function createTestsPaths(ABTestsMap){for(var tag in ABTestsMap){var group=ABTestsMap[tag];group.Path="scripts/"+group.Tag;}}