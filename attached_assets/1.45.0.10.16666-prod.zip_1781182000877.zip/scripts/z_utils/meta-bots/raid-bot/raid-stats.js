var RaidPopulation=1000;var raidStats={powerTime:{100:[],300:[],1400:[],5000:[],15000:[],},placeTime:{1:[],2:[],3:[],4:[],5:[],},openChestTime:[],upgradePerkTime:{2:[],3:[],4:[],5:[],6:[],7:[],8:[],9:[],10:[],},};var RaidStats=(function(){function RaidStats(){this.maxFields=0;this.fieldCounter=0;this.statList=this.makePersonalStatList(raidStats);}
RaidStats.prototype.isCompleted=function(){return this.fieldCounter==this.maxFields;};RaidStats.makeAverageValuesList=function(obj){obj=obj!=undefined?obj:raidStats;var copy;if(null==obj||"object"!=typeof obj)
return obj;if(obj instanceof Array){if(obj[0]instanceof Array){var minLength=this.findShortestArrayLength(obj);copy=[];for(var i=0;i<minLength;i++){var tmp=[];for(var _i=0,obj_1=obj;_i<obj_1.length;_i++){var array=obj_1[_i];tmp.push(array[i]);}
copy.push(RaidStats.averageOfArray(tmp));}
return copy;}
if(!isNaN(Number(obj[0]))){copy=RaidStats.averageOfArray(obj);return copy;}}
if(obj instanceof Object){copy={};for(var attr in obj){if(obj.hasOwnProperty(attr)){copy[attr]=RaidStats.makeAverageValuesList(obj[attr]);}}
return copy;}
throw new Error("Unable to copy obj! Its type isn't supported.");};RaidStats.getStringStats=function(obj,tab){return"UNCOMMENT UTIL";};RaidStats.prototype.addStatsToCommonTable=function(objFrom,objTo){objFrom=objFrom!=undefined?objFrom:this.statList;objTo=objTo!=undefined?objTo:raidStats;if(!isNaN(Number(objFrom))&&objTo instanceof Array){objTo.push(objFrom);}
if(objFrom instanceof Array&&objTo instanceof Array){objTo.push(objFrom);}
if(objFrom instanceof Object){for(var attr in objFrom){if(objFrom.hasOwnProperty(attr)&&objTo.hasOwnProperty(attr)){this.addStatsToCommonTable(objFrom[attr],objTo[attr]);}}}};RaidStats.prototype.makePersonalStatList=function(obj){var copy;if(null==obj||"object"!=typeof obj)
return obj;if(obj instanceof Array){copy=Number(-1);this.maxFields++;return copy;}
if(obj instanceof Object){copy={};for(var attr in obj){if(obj.hasOwnProperty(attr)){copy[attr]=this.makePersonalStatList(obj[attr]);}}
return copy;}
throw new Error("Unable to copy obj! Its type isn't supported.");};RaidStats.averageOfArray=function(array){var sum=0;for(var _i=0,array_1=array;_i<array_1.length;_i++){var i=array_1[_i];sum+=i;}
return Math.round(sum*10/array.length)/10;};RaidStats.findShortestArrayLength=function(arrays){var length=MAX_SAFE_INTEGER;for(var _i=0,arrays_1=arrays;_i<arrays_1.length;_i++){var array=arrays_1[_i];length=Math.min(length,array.length);}
return length;};return RaidStats;}());