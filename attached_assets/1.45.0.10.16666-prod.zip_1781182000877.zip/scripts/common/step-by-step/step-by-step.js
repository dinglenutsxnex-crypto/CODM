var StepByStep=(function(){function StepByStep(settings){if(settings.leveling){this.leveling=settings.leveling;var levelingKeys=Object.keys(this.leveling||{}).map(Number);this.maxLevel=Math.max.apply(Math,levelingKeys);}
if(settings.points){this.points=settings.points;}}
return StepByStep;}());