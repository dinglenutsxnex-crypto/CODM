var __assign=(this&&this.__assign)||Object.assign||function(t){for(var s,i=1,n=arguments.length;i<n;i++){s=arguments[i];for(var p in s)if(Object.prototype.hasOwnProperty.call(s,p))
t[p]=s[p];}
return t;};var logBuffer=[];function createIDMap(map,mapName){var sortable=[];for(var name_1 in map){if(map.hasOwnProperty(name_1)){var value=map[name_1];value.Name=value.Name?value.Name:name_1;sortable.push([value.ID,value]);}}
sortable.sort(function(a,b){return a[0]-b[0];});var resultMap=new OrderMap(mapName);for(var _i=0,sortable_1=sortable;_i<sortable_1.length;_i++){var obj=sortable_1[_i];var o=resultMap.put(obj[0],obj[1]);if(o){throw new Error(obj[1].Name.toString()+" And "+o.Name.toString()+" has the same ID: "+obj[0]);}}
return resultMap;}
function extend(obj,src,reportConflicts){if(reportConflicts===void 0){reportConflicts=false;}
if(!src)
return obj;for(var key in src){if(reportConflicts&&(key in obj)){throw new Error("extend: key "+key+" present in both sources.");}
if(src.hasOwnProperty(key))
obj[key]=src[key];}
return obj;}
function deepCopy(obj){var copy;if(null==obj||"object"!=typeof obj)
return obj;if(obj instanceof Date){copy=new Date();copy.setTime(obj.getTime());return copy;}
if(obj instanceof Array){copy=[];for(var i=0,len=obj.length;i<len;i++){copy[i]=deepCopy(obj[i]);}
return copy;}
if(obj instanceof Object){copy={};for(var attr in obj){if(obj.hasOwnProperty(attr))
copy[attr]=deepCopy(obj[attr]);}
return copy;}
throw new Error("Unable to copy obj! Its type isn't supported.");}
function isPlainObject(v){if(v===null||typeof v!=="object"){return false;}
if(Array.isArray(v)||v instanceof Date){return false;}
var proto=Object.getPrototypeOf(v);return proto===Object.prototype||proto===null;}
function deepExtend(obj,src,opts){if(opts===void 0){opts={};}
var _a=opts.reportConflicts,reportConflicts=_a===void 0?false:_a,_b=opts.concatArrays,concatArrays=_b===void 0?false:_b,_c=opts.useDeepCopy,useDeepCopy=_c===void 0?false:_c;if(!src){return obj;}
if(!isPlainObject(obj)){throw new Error("deepExtend: target must be a plain object");}
var copy=function(v){return(useDeepCopy?deepCopy(v):v);};for(var _i=0,_d=Object.keys(src);_i<_d.length;_i++){var key=_d[_i];var baseVal=obj[key];var srcVal=src[key];var baseIsObj=isPlainObject(baseVal);var srcIsObj=isPlainObject(srcVal);if(baseIsObj&&srcIsObj){obj[key]=deepExtend(baseVal,srcVal,{reportConflicts:reportConflicts,concatArrays:concatArrays,useDeepCopy:useDeepCopy});continue;}
if(Array.isArray(baseVal)&&Array.isArray(srcVal)){if(reportConflicts&&baseVal.length>0){throw new Error("deepExtend: key '"+key+"' present in both sources.");}
obj[key]=concatArrays?baseVal.concat(srcVal):copy(srcVal);continue;}
if(baseVal!==undefined&&reportConflicts){var baseEmpty=baseVal===""||baseVal===null||baseVal===undefined||(Array.isArray(baseVal)&&baseVal.length===0);if(!baseEmpty){throw new Error("deepExtend: key '"+key+"' present in both sources.");}}
obj[key]=copy(srcVal);}
return obj;}
function ensureSetsCount(sets,required,schemeName){if(schemeName===void 0){schemeName="DefaultSchemeName";}
if(!isInteger(required)||required<=0){throw new Error(schemeName+": \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440 'required' \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0446\u0435\u043B\u044B\u043C \u0447\u0438\u0441\u043B\u043E\u043C");}
var got=Array.isArray(sets)?sets.length:0;if(got<required){throw new Error(schemeName+": \u043E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F "+required+" \u0441\u0435\u0442\u0430(\u043E\u0432), \u0430 \u043F\u0440\u0438\u0448\u043B\u043E "+got);}}
function typedDeepCopy(obj){var copy;if(null==obj||"object"!=typeof obj)
return obj;if(obj instanceof Date){copy=new Date();copy.setTime(obj.getTime());return copy;}
if(obj instanceof Array){copy=[];for(var i=0,len=obj.length;i<len;i++){copy[i]=typedDeepCopy(obj[i]);}
return copy;}
if(obj instanceof Object){copy={};for(var attr in obj){if(obj.hasOwnProperty(attr))
copy[attr]=typedDeepCopy(obj[attr]);}
return copy;}
throw new Error("Unable to copy obj! Its type isn't supported.");}
function overrideTemplate(template,override,deepCopyOverride){if(deepCopyOverride===void 0){deepCopyOverride=false;}
var propertySet=new BasicSet(Object.keys(template));propertySet.add(Object.keys(override));var properties=propertySet.values;var result={};properties.forEach(function(a){result[a]=(override.hasOwnProperty(a)&&override[a]!=undefined)?(deepCopyOverride?deepCopy(override[a]):override[a]):(template.hasOwnProperty(a)&&template[a]!=undefined)?deepCopy(template[a]):undefined;});return result;}
function makeCopyWithAddFields(obj,addObj){var copyObj=deepCopy(obj);for(var _i=0,_a=Object.keys(addObj);_i<_a.length;_i++){var key=_a[_i];copyObj[key]=deepCopy(addObj[key]);}
return copyObj;}
var PcgRandom=(function(){function PcgRandom(seedHi,seedLo,incHi,incLo){if(seedLo===void 0){seedLo=null;}
if(incHi===void 0){incHi=null;}
if(incLo===void 0){incLo=null;}
this.defaultIncHi=0x14057b7e;this.defaultIncLo=0xf767814f;this.MUL_HI=0x5851f42d>>>0;this.MUL_LO=0x4c957f2d>>>0;this.BIT_53=9007199254740992.0;this.BIT_27=134217728.0;this.state=[];this.initSeed(seedHi,seedLo,incHi,incLo);}
PcgRandom.prototype.setSeed=function(seed){this.initSeed(seed);};PcgRandom.prototype.nextInt=function(bound){return this.integer(bound);};PcgRandom.prototype.nextDouble=function(){return this.number();};PcgRandom.prototype.MAX_INTEGER=function(){return 2147483647;};PcgRandom.prototype.initSeed=function(seedHi,seedLo,incHi,incLo){if(seedLo===void 0){seedLo=null;}
if(incHi===void 0){incHi=null;}
if(incLo===void 0){incLo=null;}
if(seedLo==null&&seedHi==null){seedLo=(Math.random()*0xffffffff)>>>0;seedHi=0;}
else if(seedLo==null){seedLo=seedHi;seedHi=0;}
if(incLo==null&&incHi==null){incLo=this.state?this.state[3]:this.defaultIncLo;incHi=this.state?this.state[2]:this.defaultIncHi;}
else if(incLo==null){incLo=incHi;incHi=0;}
this.state=[0,0,incHi>>>0,(incLo|1)>>>0];this.next();this.add64(this.state,this.state[0],this.state[1],seedHi>>>0,seedLo>>>0);this.next();return this;};PcgRandom.prototype.getState=function(){return[this.state[0],this.state[1],this.state[2],this.state[3]];};PcgRandom.imul=function(a,b){var ah=(a>>>16)&0xffff,al=a&0xffff;var bh=(b>>>16)&0xffff,bl=b&0xffff;return((al*bl)+(((ah*bl+al*bh)<<16)>>>0)|0);};PcgRandom.prototype.mul64=function(out,aHi,aLo,bHi,bLo){var c1=(aLo>>>16)*(bLo&0xffff)>>>0;var c0=(aLo&0xffff)*(bLo>>>16)>>>0;var lo=((aLo&0xffff)*(bLo&0xffff))>>>0;var hi=((aLo>>>16)*(bLo>>>16))+((c0>>>16)+(c1>>>16))>>>0;c0=(c0<<16)>>>0;lo=(lo+c0)>>>0;if((lo>>>0)<(c0>>>0)){hi=(hi+1)>>>0;}
c1=(c1<<16)>>>0;lo=(lo+c1)>>>0;if((lo>>>0)<(c1>>>0)){hi=(hi+1)>>>0;}
hi=(hi+PcgRandom.imul(aLo,bHi))>>>0;hi=(hi+PcgRandom.imul(aHi,bLo))>>>0;out[0]=hi;out[1]=lo;};PcgRandom.prototype.add64=function(out,aHi,aLo,bHi,bLo){var hi=(aHi+bHi)>>>0;var lo=(aLo+bLo)>>>0;if((lo>>>0)<(aLo>>>0)){hi=(hi+1)|0;}
out[0]=hi;out[1]=lo;};PcgRandom.prototype.next=function(){var oldHi=this.state[0]>>>0;var oldLo=this.state[1]>>>0;this.mul64(this.state,oldHi,oldLo,this.MUL_HI,this.MUL_LO);this.add64(this.state,this.state[0],this.state[1],this.state[2],this.state[3]);var xsHi=oldHi>>>18;var xsLo=((oldLo>>>18)|(oldHi<<14))>>>0;xsHi=(xsHi^oldHi)>>>0;xsLo=(xsLo^oldLo)>>>0;var xorshifted=((xsLo>>>27)|(xsHi<<5))>>>0;var rot=oldHi>>>27;var rot2=((-rot>>>0)&31)>>>0;return((xorshifted>>>rot)|(xorshifted<<rot2))>>>0;};PcgRandom.prototype.integer=function(max){if(!max){return this.next();}
max=max>>>0;if((max&(max-1))===0){return this.next()&(max-1);}
var num=0;var skew=((-max>>>0)%max)>>>0;for(num=this.next();num<skew;num=this.next()){}
return num%max;};PcgRandom.prototype.number=function(){var hi=(this.next()&0x03ffffff)*1.0;var lo=(this.next()&0x07ffffff)*1.0;return((hi*this.BIT_27)+lo)/this.BIT_53;};PcgRandom.mixSeed=function(a,b){var h=a^b;h=PcgRandom.imul(h,0x9e3779b1);h=h^(h>>>16);return h|0;};return PcgRandom;}());var RandomInstance=new PcgRandom(1);var OrderMap=(function(){function OrderMap(name){if(name===void 0){name="";}
this.name=name;this.keys=[];this.values={};}
OrderMap.prototype.get=function(k){return this.values[k];};OrderMap.prototype.checkedGet=function(k){var result=this.values[k];if(!result)
throw new Error("checkedGet: map "+this.name+" does not contain ID "+k);return result;};OrderMap.prototype.put=function(k,v){var result=this.get(k);if(!result){this.keys.push(k);}
this.values[k]=v;return result;};OrderMap.prototype.getKeys=function(){return this.keys;};OrderMap.prototype.getSortedKeys=function(str){var _this=this;return!str?this.keys.sort(function(a,b){return a-b;}):this.keys.sort(function(a,b){return _this.get(a)[str]-_this.get(a)[str];});};OrderMap.prototype.getValues=function(){return this.values;};OrderMap.prototype.size=function(){return this.keys.length;};OrderMap.prototype.hasOwnValue=function(key){return this.values.hasOwnProperty(key.toString());};OrderMap.createCopy=function(map){return createIDMap(deepCopy(map.getValues()));};OrderMap.merge=function(map1,map2){var result=map1;map2.getKeys().forEach(function(key){result.put(key,map2.get(key));});return result;};return OrderMap;}());function shuffle(list,rnd){var size=list.length;for(var i=size;i>1;i--)
swap(list,i-1,rnd.nextInt(i));}
function randomShuffle(list,rnd){var size=list.length;for(var i=size;i>1;i--){if(rnd.nextInt(2)%2===0){swap(list,i-1,rnd.nextInt(i));}}}
function swap(list,i,j){var jElement=list[j];list[j]=list[i];list[i]=jElement;}
var ShuffledList=(function(){function ShuffledList(list,rnd){this._list=[];for(var _i=0,list_1=list;_i<list_1.length;_i++){var value=list_1[_i];this._list.push(value);}
shuffle(this._list,rnd);this._pointer=0;}
ShuffledList.prototype.next=function(){this._pointer++;return this._list[(this._pointer-1)%this._list.length];};return ShuffledList;}());var RandomShuffle=(function(){function RandomShuffle(source,shuffleGroups){this._shuffleGroups=[];this._groupIndices=[];for(var i=0;i<source.length;i++){this._groupIndices.push(null);}
var groupCounter=0;for(var _i=0,shuffleGroups_1=shuffleGroups;_i<shuffleGroups_1.length;_i++){var group=shuffleGroups_1[_i];if(!group.length){continue;}
this._shuffleGroups.push([]);for(var _a=0,group_1=group;_a<group_1.length;_a++){var index=group_1[_a];if(this._groupIndices[index]!=null){throw new Error("RandomShuffle: index "+index+" present in multiple groups");}
this._groupIndices[index]=groupCounter;this._shuffleGroups[groupCounter].push(source[index]);}
groupCounter++;}
for(var i=0;i<source.length;i++){if(this._groupIndices[i]==null){this._groupIndices[i]=groupCounter;this._shuffleGroups.push([source[i]]);groupCounter++;}}}
RandomShuffle.prototype.get=function(rnd){var shuffles=[];for(var _i=0,_a=this._shuffleGroups;_i<_a.length;_i++){var shuffleGroup=_a[_i];shuffles.push(new ShuffledList(shuffleGroup,rnd));}
var result=[];for(var i=0;i<this._groupIndices.length;i++){result.push(shuffles[this._groupIndices[i]].next());}
return result;};return RandomShuffle;}());function toArray(js){return js;}
function getValueByKey(js,key){return js.hasOwnProperty(key)?js[key]:checkNotNull(null,"Key["+key+"] not found");}
function getValueByKeyDefault(js,key,defaultValue){return js.hasOwnProperty(key)?js[key]:defaultValue;}
function defaultIfNull(js,key,defaultValue){var v=js[key];return v==null?defaultValue:v;}
var CollectionObjectContainer=(function(){function CollectionObjectContainer(item,weight){this.Object=item;this.Weight=weight;}
CollectionObjectContainer.prototype.getWeight=function(){return this.Weight;};CollectionObjectContainer.prototype.get=function(){return this.Object;};return CollectionObjectContainer;}());var RandomCollection=(function(){function RandomCollection(values){this.map=new OrderMap();this.mapSize=0;this.total=0;if(values){this.addAll(values);}}
RandomCollection.prototype.addAll=function(values){for(var _i=0,values_1=values;_i<values_1.length;_i++){var value=values_1[_i];this.add(value);}};RandomCollection.prototype.add=function(value,weightMultiplier){var weight=weightMultiplier?weightMultiplier*value.getWeight():value.getWeight();if(weight<=0)
return;this.total+=weight;this.map.put(this.total,value);this.mapSize++;};RandomCollection.prototype.next=function(rnd){if(this.mapSize==0)
return null;var rd=rnd.nextInt(this.total)+1;return this.ceilingValue(rd);};RandomCollection.prototype.ceilingValue=function(key){for(var _i=0,_a=this.map.getKeys();_i<_a.length;_i++){var obj=_a[_i];if(obj>=key){return this.map.get(obj);}}};RandomCollection.prototype.remove=function(value){var result=false;var all=this.map;this.clear();for(var _i=0,_a=all.getKeys();_i<_a.length;_i++){var key=_a[_i];var item=all.get(key);if(item===value){result=true;}
else{this.add(item);}}
return result;};RandomCollection.prototype.removeByCondition=function(condition){var restParameters=[];for(var _i=1;_i<arguments.length;_i++){restParameters[_i-1]=arguments[_i];}
var all=this.map;this.clear();for(var _a=0,_b=all.getKeys();_a<_b.length;_a++){var key=_b[_a];var item=all.get(key);if(!condition(item,restParameters)){this.add(item);}}
return this;};RandomCollection.prototype.size=function(){return this.mapSize;};RandomCollection.prototype.clear=function(){this.map=new OrderMap();this.mapSize=0;this.total=0;return this;};RandomCollection.prototype.copy=function(){var keys=this.map.getKeys();var result=new RandomCollection();for(var _i=0,keys_1=keys;_i<keys_1.length;_i++){var key=keys_1[_i];result.add(this.map.get(key));}
return result;};RandomCollection.prototype.list=function(extract){if(extract===void 0){extract=(function(x){return x;});}
var result=[];for(var _i=0,_a=this.map.getKeys();_i<_a.length;_i++){var obj=_a[_i];result.push(extract(this.map.get(obj)));}
return result;};RandomCollection.prototype.getWeight=function(){return this.total;};return RandomCollection;}());function hashCode(str){var hash=5381;var i=str.length;while(i){hash=(hash*33)^str.charCodeAt(--i);}
return hash;}
function positiveHashCode(str){return hashCode(str)>>>0;}
function isNumber(value){return!isNaN(parseFloat(value))&&isFinite(value);}
function isInteger(value){return isNumber(value)&&Math.floor(value)===Number(value);}
var MAX_SAFE_INTEGER=9007199254740991;var MAX_JAVA_INTEGER=2147483648;function isSafeInteger(value){return isInteger(value)&&Math.abs(value)<=MAX_SAFE_INTEGER;}
var UniformDistributedValue=(function(){function UniformDistributedValue(center,width){this._center=center;this._width=width;}
UniformDistributedValue.prototype.getValue=function(rnd){return this._center+(this._width*(rnd.nextDouble()*2-1));};UniformDistributedValue.prototype.getCenter=function(){return this._center;};UniformDistributedValue.prototype.getWidth=function(){return this._width;};UniformDistributedValue.prototype.getMin=function(){return this._center-this._width;};UniformDistributedValue.prototype.getMax=function(){return this._center+this._width;};return UniformDistributedValue;}());function bitwiseORArray(array){var result=0;for(var e in array){result=result|array[e];}
return result;}
function bitwiseOREnum(values){return bitwiseORArray(Object.keys(values).filter(function(k){return typeof values[k]==="string";}).map(function(e){return Number(e);}));}
var BasicSet=(function(){function BasicSet(collection){if(!collection){this._values={};}
else if(Array.isArray(collection)){this._values={};for(var _i=0,collection_1=collection;_i<collection_1.length;_i++){var item=collection_1[_i];this._values[item]=null;}}
else{this._values={};for(var _a=0,_b=collection.values;_a<_b.length;_a++){var item=_b[_a];this._values[item]=null;}}}
Object.defineProperty(BasicSet.prototype,"values",{get:function(){return Object.keys(this._values);},enumerable:true,configurable:true});BasicSet.prototype.add=function(E){if(typeof(E)=="number"||typeof(E)=="string"){this._values[E]=null;}
else if(Array.isArray(E)){for(var _i=0,E_1=E;_i<E_1.length;_i++){var item=E_1[_i];this._values[item]=null;}}
else if(E==undefined||E==null){throw new Error(" BasicSet: added element is "+E);}
else{for(var _a=0,_b=E.values;_a<_b.length;_a++){var item=_b[_a];this._values[item]=null;}}};BasicSet.prototype.sub=function(E){if(typeof(E)=="number"||typeof(E)=="string"){var newValues={};for(var _i=0,_a=this.values;_i<_a.length;_i++){var item=_a[_i];if(item!=String(E)){newValues[item]=null;}}
this._values=newValues;}
else if(Array.isArray(E)){var newValues={};for(var _b=0,_c=this.values;_b<_c.length;_b++){var item=_c[_b];if(!((E.indexOf(Number(item))>-1)||(E.indexOf(String(item))>-1))){newValues[item]=null;}}
this._values=newValues;}
else{var newValues={};for(var _d=0,_e=this.values;_d<_e.length;_d++){var item=_e[_d];if(E.values.indexOf(item)==-1){newValues[item]=null;}}
this._values=newValues;}};BasicSet.prototype.isect=function(E){if(typeof(E)=="number"||typeof(E)=="string"){if(this.values.indexOf(String(E))>-1){this._values={};this._values[E]=null;}
else{this._values={};}}
else if(Array.isArray(E)){var newValues={};for(var _i=0,_a=this.values;_i<_a.length;_i++){var item=_a[_i];if(((E.indexOf(Number(item))>-1)||(E.indexOf(String(item))>-1))){newValues[item]=null;}}
this._values=newValues;}
else{var newValues={};for(var _b=0,_c=this.values;_b<_c.length;_b++){var item=_c[_b];if(E.values.indexOf(item)>-1){newValues[item]=null;}}
this._values=newValues;}};Object.defineProperty(BasicSet.prototype,"isEmpty",{get:function(){return this.values.length<=0;},enumerable:true,configurable:true});Object.defineProperty(BasicSet.prototype,"length",{get:function(){return this.values.length;},enumerable:true,configurable:true});BasicSet.multAdd=function(){var sets=[];for(var _i=0;_i<arguments.length;_i++){sets[_i]=arguments[_i];}
var result=new BasicSet();for(var _a=0,sets_1=sets;_a<sets_1.length;_a++){var i=sets_1[_a];result.add(i);}
return result;};BasicSet.multIsect=function(){var sets=[];for(var _i=0;_i<arguments.length;_i++){sets[_i]=arguments[_i];}
var result=BasicSet.multAdd.apply(BasicSet,sets);for(var _a=0,sets_2=sets;_a<sets_2.length;_a++){var i=sets_2[_a];result.isect(i);}
return result;};BasicSet.prototype.nextItem=function(){return this.values[RandomInstance.nextInt(this.length)];};BasicSet.prototype.clear=function(){this._values={};};BasicSet.prototype.includes=function(value){return(this._values.hasOwnProperty(String(value)));};BasicSet.prototype.createIterator=function(){var keys=this.values;var index=0;return{next:function(){if(index<keys.length){return{value:keys[index++],done:false};}
else{return{done:true};}}};};BasicSet.prototype.sorted=function(){return this.values.slice().sort(function(a,b){return a.localeCompare(b,undefined,{numeric:true});});};return BasicSet;}());function uniqueConcatArrays(arr1,arr2){var set1=new BasicSet(arr1);var set2=new BasicSet(arr2);set2.sub(set1);set1.add(set2);return set1.values.map(function(x){return Number(x);});}
function javaDictToJs(obj){var result={};for(var key in obj){result[key]=obj[key];}
return result;}
function fieldCompare(a,b,field){return a.hasOwnProperty(field)&&b.hasOwnProperty(field)&&a[field]==b[field];}
function getEnumNumberValues(Enum){return Object.keys(Enum).filter(function(x){return Number(x);}).map(function(x){return Number(x);});}
function isInArray(array,param){if(!array||!param)
return false;return array.indexOf(param)>-1;}
function makeArrayCopy(array){var result=[];for(var _i=0,array_1=array;_i<array_1.length;_i++){var item=array_1[_i];result.push(item);}
return result;}
function subtractArray(baseArray,excludingArray){return baseArray.filter(function(x){return excludingArray.indexOf(x)==-1;});}
function concatRarityMap(main,secondary){for(var key in secondary){if(main[key])
main[key]=Math.max(main[key],secondary[key]);else
main[key]=secondary[key];}}
function addRarityMap(main,secondary){for(var key in secondary){if(main[key])
main[key]=main[key]+secondary[key];else
main[key]=secondary[key];}}
function getRarityOddsByRarityChancesMap(dropChances){var odds={};for(var _i=0,NUM_RARITY_1=NUM_RARITY;_i<NUM_RARITY_1.length;_i++){var rarity=NUM_RARITY_1[_i];if(rarity){var oddsString=getOddsString(dropChances[rarity]);if(oddsString){odds[rarity]=oddsString;}}}
return odds;}
function addRarityChances(chance1,chance2){chance1=chance1?Math.min(1,Math.max(0,chance1)):0;chance2=chance2?Math.min(1,Math.max(0,chance2)):0;return Math.min(1,Math.max(0,chance1+chance2-chance1*chance2));}
function addRarityChanceMaps(chanceMap1,chanceMap2){var result={};for(var _i=0,NUM_RARITY_2=NUM_RARITY;_i<NUM_RARITY_2.length;_i++){var rarity=NUM_RARITY_2[_i];if(rarity!=0){var chanses=addRarityChances(chanceMap1[rarity],chanceMap2[rarity]);if(chanses)
result[rarity]=chanses;}}
return result;}
function createInstances(targetMap,settingsMap,create,namePrefix){if(namePrefix===void 0){namePrefix="";}
Object.keys(settingsMap).forEach(function(x){targetMap[namePrefix+x]=create(settingsMap[x]);});}
function createInstancesFromTemplates(targetMap,templatesMap,settingsMap,create,namePrefix){if(namePrefix===void 0){namePrefix="";}
var overridedTemplates={};Object.keys(settingsMap).forEach(function(x){overridedTemplates[x]=overrideTemplate(templatesMap[x],settingsMap[x]);});createInstances(targetMap,overridedTemplates,create,namePrefix);}
function removingDuplicates(currencies){var uniqueTracker={};var result=[];currencies.forEach(function(currency){var key=Object.keys(currency)[0];var value=currency[key];if(!uniqueTracker[key]){uniqueTracker[key]=[value];result.push(currency);}
else if(!uniqueTracker[key].includes(value)){uniqueTracker[key].push(value);result.push(currency);}});return result;}
function arraysEqual(array1,array2){array1.sort();array2.sort();var i=array1.length;if(i!=array2.length)
return false;while(i--){if(array1[i]!==array2[i])
return false;}
return true;}
function getItemsByBattlesArray(gbArray){var itemsSet=new BasicSet();for(var _i=0,gbArray_1=gbArray;_i<gbArray_1.length;_i++){var gb=gbArray_1[_i];for(var _a=0,_b=gb.fights;_a<_b.length;_a++){var fight=_b[_a];for(var _c=0,_d=fight.rounds;_c<_d.length;_c++){var round=_d[_c];itemsSet.add(round.warrior.equipments);for(var _e=0,_f=round.rules;_e<_f.length;_e++){var rule_1=_f[_e];var id=rule_1.getId();if(id==4){itemsSet.add(rule_1.getAttribute(9).getValue());}}}}}
return itemsSet.values;}
function getShadowsByBattlesArray(gbArray){var shadowsSet=new BasicSet();for(var _i=0,gbArray_2=gbArray;_i<gbArray_2.length;_i++){var gb=gbArray_2[_i];for(var _a=0,_b=gb.fights;_a<_b.length;_a++){var fight=_b[_a];for(var _c=0,_d=fight.rounds;_c<_d.length;_c++){var round=_d[_c];var equips=round.warrior.equipments;for(var _e=0,equips_1=equips;_e<equips_1.length;_e++){var equipID=equips_1[_e];var eqip=ItemModelsMap.get(equipID);if(eqip.EnemyShadowMark){shadowsSet.add(eqip.EnemyShadowMark);}}
for(var _f=0,_g=round.rules;_f<_g.length;_f++){var rule_2=_g[_f];var id=rule_2.getId();if(id==4){var eqip=ItemModelsMap.get(rule_2.getAttribute(9).getValue());if(eqip.ShadowMark){shadowsSet.add(eqip.ShadowMark);}}}}}}
return shadowsSet.values;}
function getAppearancesByBattlesArray(gbArray){var appearancesSet=new BasicSet();for(var _i=0,gbArray_3=gbArray;_i<gbArray_3.length;_i++){var gb=gbArray_3[_i];for(var _a=0,_b=gb.fights;_a<_b.length;_a++){var fight=_b[_a];for(var _c=0,_d=fight.rounds;_c<_d.length;_c++){var round=_d[_c];appearancesSet.add(round.warrior.appearanceId);for(var _e=0,_f=round.rules;_e<_f.length;_e++){var rule_3=_f[_e];var id=rule_3.getId();if(id==RoundRules.SetAppearance.ID){appearancesSet.add(rule_3.getAttribute(9).getValue());}}}}}
return appearancesSet.values;}
function getTagsByBattlesArray(gbArray){var tagSet=new BasicSet();for(var _i=0,gbArray_4=gbArray;_i<gbArray_4.length;_i++){var gb=gbArray_4[_i];for(var _a=0,_b=gb.fights;_a<_b.length;_a++){var fight=_b[_a];for(var _c=0,_d=fight.rounds;_c<_d.length;_c++){var round=_d[_c];for(var _e=0,_f=round.rules;_e<_f.length;_e++){var rule_4=_f[_e];var id=rule_4.getId();if(id==6){tagSet.add(rule_4.getAttribute(10).getValue());}}}}}
return tagSet.values;}
function parseDateToMilliseconds(dateStr){var parts=dateStr.match(/(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)([+-])(\d{2})(\d{2})/);if(!parts){throw new Error('Invalid date format');}
var year=parseInt(parts[1],10);var month=parseInt(parts[2],10)-1;var day=parseInt(parts[3],10);var hours=parseInt(parts[4],10);var minutes=parseInt(parts[5],10);var seconds=parseInt(parts[6],10);var tzModifier=parts[7]==='+'?-1:1;var tzHours=parseInt(parts[8],10);var tzMinutes=parseInt(parts[9],10);var milliseconds=Date.UTC(year,month,day,hours,minutes,seconds);milliseconds+=tzModifier*(tzHours*3600000+tzMinutes*60000);return milliseconds;}
var DATE_UNIT;(function(DATE_UNIT){DATE_UNIT["YEAR"]="year";DATE_UNIT["MONTH"]="month";DATE_UNIT["DAY"]="day";DATE_UNIT["HOUR"]="hour";DATE_UNIT["MINUTE"]="minute";DATE_UNIT["SECOND"]="second";})(DATE_UNIT||(DATE_UNIT={}));var ScheduleHelper=(function(){function ScheduleHelper(){}
ScheduleHelper.toString=function(date,offsetMinutes){if(offsetMinutes===void 0){offsetMinutes=180;}
function formatOffset(num){return(num<10?"0":"")+num;}
var offsetHours=Math.floor(offsetMinutes/60);var offsetMinutesOnly=Math.abs(offsetMinutes%60);var offsetSign=offsetMinutes>=0?"+":"-";var formattedOffset=offsetSign+formatOffset(Math.abs(offsetHours))+formatOffset(offsetMinutesOnly);var copyDate=new Date(ScheduleHelper.getTime(date)+offsetMinutes*60000);var splitByT=copyDate.toISOString().split("T");var splitByPoint=splitByT[1].split(".");return splitByT[0]+"T"+(splitByPoint[0]+formattedOffset);};ScheduleHelper.formatCnDate=function(data){var times=IS_CHINA?chinaTime:defaultTime;var formatted={};Object.keys(data).forEach(function(key){formatted[key]=data[key].includes("T")?data[key]:data[key]+times[key];});return formatted;};ScheduleHelper.isLeapYear=function(year){return(year%4===0&&year%100!==0||year%400===0)?true:false;};ScheduleHelper.getTime=function(date){var millisecondsPerSecond=1000;var millisecondsPerMinute=60*millisecondsPerSecond;var millisecondsPerHour=60*millisecondsPerMinute;var millisecondsPerDay=24*millisecondsPerHour;var year=date.getUTCFullYear();var month=date.getUTCMonth();var day=date.getUTCDate();var hours=date.getUTCHours();var minutes=date.getUTCMinutes();var seconds=date.getUTCSeconds();var milliseconds=date.getUTCMilliseconds();var daysSinceEpoch=0;for(var y=1970;y<year;y++){daysSinceEpoch+=ScheduleHelper.isLeapYear(y)?366:365;}
var daysInMonth=[31,ScheduleHelper.isLeapYear(year)?29:28,31,30,31,30,31,31,30,31,30,31];for(var m=0;m<month;m++){daysSinceEpoch+=daysInMonth[m];}
daysSinceEpoch+=day-1;var totalMilliseconds=daysSinceEpoch*millisecondsPerDay;totalMilliseconds+=hours*millisecondsPerHour;totalMilliseconds+=minutes*millisecondsPerMinute;totalMilliseconds+=seconds*millisecondsPerSecond;totalMilliseconds+=milliseconds;return totalMilliseconds;};ScheduleHelper.print=function(date,title){console.log(title?"-------------------- "+title+" --------------------":"----------------------------------------------");var d=new Date(date);console.log("Ts Numeric      :      "+(isNumber(date)?date:ScheduleHelper.getTime(d)));console.log("Unix Numeric    :      "+ScheduleHelper.baseTsToUnix(isNumber(date)?date:ScheduleHelper.getTime(d)));console.log("Canada/Yukon  -7:      "+d.toLocaleString('ru-RU',{timeZone:'Canada/Yukon'}));console.log("Etc/Universal  0:      "+d.toLocaleString('ru-RU',{timeZone:'Etc/Universal'}));console.log("Europe/Moscow +3:      "+d.toLocaleString('ru-RU',{timeZone:'Europe/Moscow'}));};ScheduleHelper.printInterval=function(date1,date2,title){console.log(title?"-------------------- "+title+" --------------------":"----------------------------------------------");var d1=new Date(date1);var d2=new Date(date2);console.log("Ts Numeric      :      "+(isNumber(date1)?date1:ScheduleHelper.getTime(d1))+", "+(isNumber(date2)?date2:ScheduleHelper.getTime(d2)));console.log("Unix Numeric    :      "+ScheduleHelper.baseTsToUnix(isNumber(date1)?date1:ScheduleHelper.getTime(d1))+", "+ScheduleHelper.baseTsToUnix(isNumber(date2)?date2:ScheduleHelper.getTime(d2)));console.log("Canada/Yukon  -7:      "+d1.toLocaleString('ru-RU',{timeZone:'Canada/Yukon'})+" - "+d2.toLocaleString('ru-RU',{timeZone:'Canada/Yukon'}));console.log("Etc/Universal  0:      "+d1.toLocaleString('ru-RU',{timeZone:'Etc/Universal'})+" - "+d2.toLocaleString('ru-RU',{timeZone:'Etc/Universal'}));console.log("Europe/Moscow +3:      "+d1.toLocaleString('ru-RU',{timeZone:'Europe/Moscow'})+" - "+d2.toLocaleString('ru-RU',{timeZone:'Europe/Moscow'}));};ScheduleHelper.baseTsToUnix=function(date){var d=new Date(date);return Math.round(ScheduleHelper.getTime(d)/1000);};ScheduleHelper.unixToBaseTsNumeric=function(date){return Number(date)*1000;};ScheduleHelper.addTimeToISODate=function(date,unit,value){var d=new Date(parseDateToMilliseconds(date));var copyD;switch(unit){case DATE_UNIT.YEAR:copyD=new Date(date);copyD.setFullYear(d.getFullYear()+value);if(copyD.getMonth()!=d.getMonth()){d=ScheduleHelper.getLastDayOfPreviousMonth(copyD);}
else{d.setFullYear(d.getFullYear()+value);}
break;case DATE_UNIT.MONTH:copyD=new Date(date);copyD.setMonth(copyD.getMonth()+value);if(copyD.getMonth()-d.getMonth()!=value){d=ScheduleHelper.getLastDayOfPreviousMonth(copyD);}
else{d.setMonth(d.getMonth()+value);}
break;case DATE_UNIT.DAY:d.setDate(d.getDate()+value);break;case DATE_UNIT.HOUR:d.setHours(d.getHours()+value);break;case DATE_UNIT.MINUTE:d.setMinutes(d.getMinutes()+value);break;case DATE_UNIT.SECOND:d.setSeconds(d.getSeconds()+value);break;default:throw new Error("Invalid time unit: "+unit);}
return ScheduleHelper.toString(d);};ScheduleHelper.setTimeToISODate=function(date,unit,value){var d=new Date(date);var copyD;switch(unit){case DATE_UNIT.YEAR:copyD=new Date(date);copyD.setFullYear(value);if(d.getFullYear()%4===0&&copyD.getMonth()!=d.getMonth()){d=ScheduleHelper.getLastDayOfPreviousMonth(copyD);}
else{d.setFullYear(value);}
break;case DATE_UNIT.MONTH:copyD=new Date(date);copyD.setMonth(value-1);if(copyD.getMonth()!=value-1){d=ScheduleHelper.getLastDayOfPreviousMonth(copyD);}
else{d.setMonth(value-1);}
break;case DATE_UNIT.DAY:d.setDate(value);break;case DATE_UNIT.HOUR:d.setHours(value);break;case DATE_UNIT.MINUTE:d.setMinutes(value);break;case DATE_UNIT.SECOND:d.setSeconds(value);break;default:throw new Error("Invalid time unit: "+unit);}
return ScheduleHelper.toString(d);};ScheduleHelper.parseOffsetToMinutes=function(offsetStr){var match=/^([+-])(\d{2})(\d{2})$/.exec(offsetStr);if(!match){throw new Error("Invalid offset format");}
var sign=match[1]==="+"?1:-1;var hours=parseInt(match[2],10);var minutes=parseInt(match[3],10);return sign*(hours*60+minutes);};ScheduleHelper.parseStringDateToOffset=function(date){return date.substring(date.lastIndexOf("+")!==-1?date.lastIndexOf("+"):date.lastIndexOf("-"));};ScheduleHelper.splitInterval=function(start,end,n){var startTimeOffset=ScheduleHelper.parseStringDateToOffset(start);var endTimeOffset=ScheduleHelper.parseStringDateToOffset(end);var startDateOffsetMinutes=ScheduleHelper.parseOffsetToMinutes(startTimeOffset);var endDateOffsetMinutes=ScheduleHelper.parseOffsetToMinutes(endTimeOffset);var startTime=parseDateToMilliseconds(start);var endTime=parseDateToMilliseconds(end);var intervalLength=(endTime-startTime)/n;var intervals=[];for(var i=0;i<n;i++){var intervalStart=ScheduleHelper.toString(new Date(startTime+i*intervalLength),startDateOffsetMinutes);var intervalEnd=ScheduleHelper.toString(new Date(startTime+(i+1)*intervalLength-1000),endDateOffsetMinutes);intervals.push({startDate:intervalStart,endDate:intervalEnd});}
return intervals;};ScheduleHelper.getLastDayOfPreviousMonth=function(date){var previousMonth=new Date(date.getFullYear(),date.getMonth(),1,date.getHours(),date.getMinutes(),date.getSeconds());previousMonth.setDate(0);return previousMonth;};ScheduleHelper.formatSchedule=function(date,type,point){if(type===void 0){type='day';}
if(point===void 0){point='start';}
var time=getGlOrCn(promosDefaultSchedule[type].gl[point],promosDefaultSchedule[type].cn[point]);return date+"T"+time+"+0300";};return ScheduleHelper;}());function getRulesByBattlesArray(gbArray){var rulesSet=new BasicSet();for(var _i=0,gbArray_5=gbArray;_i<gbArray_5.length;_i++){var gb=gbArray_5[_i];for(var _a=0,_b=gb.fights;_a<_b.length;_a++){var fight=_b[_a];for(var _c=0,_d=fight.rounds;_c<_d.length;_c++){var round=_d[_c];for(var _e=0,_f=round.rules;_e<_f.length;_e++){var rule_5=_f[_e];var id=rule_5.getId();if(id!=6){rulesSet.add(id);}}}}}
return rulesSet.values;}
function getLocationsByBattlesArray(gbArray){var locationsSet=new BasicSet();var _loop_1=function(gb){var locations=[];gb.location.forEach(function(fightLocations){return locations.push(fightLocations);});locationsSet.add(locations.map(function(x){return x.LocationName;}));};for(var _i=0,gbArray_6=gbArray;_i<gbArray_6.length;_i++){var gb=gbArray_6[_i];_loop_1(gb);}
return locationsSet.values;}
function getCurrenciesIDsFromTemplateMap(currencies){var result=[];for(var cur in currencies){result.push(currencies[cur].ID);}
return result;}
var LOG_COLOR;(function(LOG_COLOR){LOG_COLOR[LOG_COLOR["BASE"]=0]="BASE";LOG_COLOR[LOG_COLOR["RED"]=1]="RED";})(LOG_COLOR||(LOG_COLOR={}));var logColors=(_a={},_a[LOG_COLOR.BASE]="\x1B[0m",_a[LOG_COLOR.RED]="\x1B[31m",_a);var LogHelper=(function(){function LogHelper(){}
LogHelper.setColor=function(value,color){return""+logColors[color]+value+logColors[LOG_COLOR.BASE];};return LogHelper;}());function createWeightedRandomSelector(weightedObjArray){var selector=new RandomCollection();weightedObjArray.forEach(function(x){return selector.add(new CollectionObjectContainer(x.Object,x.Weight));});if(selector.size()==0){throw new Error("createWeightedRandomSelector: size is 0");}
return selector;}
function reverseMap(mapToReverse){var reversedMap={};for(var ID in mapToReverse){for(var _i=0,_a=mapToReverse[ID];_i<_a.length;_i++){var newID=_a[_i];if(!reversedMap[newID]){reversedMap[newID]=[];}
reversedMap[newID].push(+ID);}}
return reversedMap;}
function getBaseLog(x,y){return Math.log(y)/Math.log(x);}
function mergeColletionUpgradeCosts(maps,maxLevel){if(maxLevel===void 0){maxLevel=6;}
if(!maps||maps.length==0){return{};}
else{var result=deepCopy(maps[0]);for(var level=1;level<=maxLevel;level++){for(var i=1;i<=maps.length-1;i++){var nextMap=deepCopy(maps[i]);if(nextMap[level]){if(result[level]){result[level]=result[level].concat(nextMap[level]);}
else{result[level]=nextMap[level];}
result[level]=result[level].slice(0,5);}}}
return result;}}
function sumNumbersMaps(array){var result={};array.forEach(function(map){Object.keys(map).forEach(function(key){if(result[key]){result[key]+=map[key];}
else{result[key]=map[key];}});});return result;}
function sumCollectionUpgradeCosts(map){if(!map){return{};}
else{var mapLength=Object.keys(map).length;if(mapLength==0){return{};}
var mapArray_1=[];for(var level=1;level<=mapLength;level++){map[level].forEach(function(slot){return mapArray_1.push(slot);});}
return sumNumbersMaps(mapArray_1);}}
function combineRewards(rewards){var combRew=rewards[0];for(var i=1;i<rewards.length;i++){combRew.combine(rewards[i]);}
return combRew;}
function createShardCurrency(aliasKey,settings){settings.alias=aliasKey+"_set_sphere";settings.description="HUD_hint_"+aliasKey+"_set_sphere";settings.cardTextureInReward="NativeUI/Sprites/ShardsTemporary/"+aliasKey+"_shard";settings.HUD_hint="HUD_hint_"+aliasKey+"_set_sphere";settings.HUD_hint_exchangeable="HUD_hint_"+aliasKey+"_set_sphere";settings.HUD_hint_zero_exchangeable="HUD_hint_"+aliasKey+"_set_sphere";return settings;}
function createFwResCurrency(aliasKey,settings){settings.alias="component_"+aliasKey+"_card";settings.description="tooltip_component_"+aliasKey+"_card";settings.HUD_hint="tooltip_component_"+aliasKey+"_card";settings.HUD_hint_exchangeable="tooltip_component_"+aliasKey+"_card";settings.HUD_hint_zero_exchangeable="tooltip_component_"+aliasKey+"_card";return settings;}
function getClonesArray(obj,count){var needDeepCopy=false;if(obj instanceof Object||obj instanceof Array){needDeepCopy=true;}
var result=[];if(needDeepCopy){for(var i=0;i<count;i++){result.push(deepCopy(obj));}}
else{for(var i=0;i<count;i++){result.push(obj);}}
return result;}
function generateTestShardLeveling(shard){var shardCurrency={};shardCurrency[shard]=1;return{1:[new Currencies(shardCurrency)],2:[new Currencies(shardCurrency)],3:[new Currencies(shardCurrency)],4:[new Currencies(shardCurrency)],5:[new Currencies(shardCurrency)]};}
function transformToRange(left,right){var i;if(left>right){i=-1;}
else{i=1;}
var result=[];while(left!=(right+i)){result.push(left+610000);left+=i;}
return result;}
var DEFAULT_WEIGHT=10;function transformKeysToWeightMap(keys,weight){if(weight===void 0){weight=DEFAULT_WEIGHT;}
var result={};for(var _i=0,keys_2=keys;_i<keys_2.length;_i++){var key=keys_2[_i];result[key]=weight;}
return result;}
function overrideAttrsExclude(attrsOld,attrsNew,excludedAttrs){for(var attr in attrsNew){if(excludedAttrs.indexOf(attr)==-1){attrsOld[attr]=attrsNew[attr];}}}
function convertSlotToNew(slots,idPrefix){return slots.map((function(slot,index){return new ShopSlotCombined({ID:index+idPrefix,price:{currency:new Currencies({BONUS:-1})},icons:[],limit:slot.Setting&&slot.Setting.MaxPurchaseCount?slot.Settings.MaxPurchaseCount:slot.maxPurchaseCount?slot.maxPurchaseCount:1,slotView:{},slotHeader:"",refreshable:true,lootContainer:slot});}));}
var Tagger=(function(){function Tagger(){}
Tagger.bold=function(text){text="<b>"+text+"</b>";return text;};Tagger.color=function(text,colorCode){text="<color=\""+colorCode+"\">"+text+"</color>";return text;};Tagger.italic=function(text){text="<i>"+text+"</i>";return text;};Tagger.underline=function(text){text="<u>"+text+"</u>";return text;};Tagger.raidDefault=function(text){text="<b><color=\"#F2CD4B\">"+text+"</color></b>";return text;};Tagger.raidUpgraded=function(text){text="<b><color=\"#51D160\">"+text+"</color></b>";return text;};return Tagger;}());function addToMapWithExclude(map1,map2,exclude){Object.keys(map2).forEach(function(x){map1[x]=map2[x];});exclude.forEach(function(item){if(map1[item]){delete map1[item];}});}
function isObjectsEqual(obj1,obj2){return JSON.stringify(obj1)===JSON.stringify(obj2);}
function arrayFill(obj,times){var result=[];for(var i=0;i<times;i++){result.push(obj);}
return result;}
var HTML_TAG;(function(HTML_TAG){HTML_TAG[HTML_TAG["BOLD"]=0]="BOLD";HTML_TAG[HTML_TAG["ITALIC"]=1]="ITALIC";HTML_TAG[HTML_TAG["WHITE"]=2]="WHITE";HTML_TAG[HTML_TAG["YELLOW"]=3]="YELLOW";})(HTML_TAG||(HTML_TAG={}));var HtmlTagSettingsMap=(_b={},_b[HTML_TAG.ITALIC]={Start:"\<i\>",End:"\</i\>",Priority:3},_b[HTML_TAG.BOLD]={Start:"\<b\>",End:"\</b\>",Priority:2},_b[HTML_TAG.WHITE]={Start:"\<color=#FFFFFF\>",End:"\</color\>",Priority:1},_b[HTML_TAG.YELLOW]={Start:"\<color=#fdbe11\>",End:"\</color\>",Priority:1},_b);var HtmlTagHelper=(function(){function HtmlTagHelper(){}
HtmlTagHelper.setTags=function(text,tags){var result=text;var tagSettingsArray=[];tags.forEach(function(tag){return tagSettingsArray.push(HtmlTagSettingsMap[tag]);});tagSettingsArray=tagSettingsArray.sort(function(a,b){return a.Priority-b.Priority;});for(var i=0;i<tagSettingsArray.length;i++){result=tagSettingsArray[i].Start+result+tagSettingsArray[i].End;}
return result;};return HtmlTagHelper;}());function fillKeys(mapObj,value,keys){var modifiedMap=__assign({},mapObj);keys.forEach(function(key){modifiedMap[String(key)]=value;});return modifiedMap;}
function invertNumMap(numMap){var result={};for(var key in numMap){var value=numMap[key];result[value]=Number(key);}
return result;}
function cumulativeSums(numMap){var result={};var sum=0;for(var key in numMap){result[Number(key)]=sum;sum+=numMap[key];}
var lastKey=Number(Object.keys(numMap).pop());result[lastKey+1]=sum;return result;}
function getCurDescWithSource(base,name,sourceActivity){if(sourceActivity===void 0){sourceActivity="";}
return"$"+base+" new_line relic_currency_source("+name+","+sourceActivity+")";}
var _a,_b;