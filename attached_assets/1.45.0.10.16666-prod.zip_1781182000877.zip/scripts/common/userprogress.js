var UserProgress=[];FillLevelProgress(60,100);function FillLevelProgress(AmountOfLevels){var startingExp=[];for(var _i=1;_i<arguments.length;_i++){startingExp[_i-1]=arguments[_i];}
for(var i=0;i<startingExp.length;i++){UserProgress.push(startingExp[i]);}
for(var i=startingExp.length;i<(AmountOfLevels);i++){UserProgress.push(Math.floor(UserProgress[i-1]*experienceInflation));}}
function calcRealExp(level,exp){var result=exp;for(var i=0;i<Math.min(level-1,UserProgress.length);++i){result+=UserProgress[i];}
return result;}
function calcLevelAndExp(exp){var curExp=exp;var level=1;while(level<UserProgress.length&&curExp>=UserProgress[level-1]){curExp-=UserProgress[level-1];++level;}
return{Level:level,Experience:curExp,LevelExperience:UserProgress[level-1]};}
function newLevelCalculate(level,exp,newExp){var newParams=calcLevelAndExp(calcRealExp(level,exp)+newExp);return{Level:newParams.Level,Experience:newParams.Experience,LevelExperience:UserProgress[newParams.Level-1]};}
function calcExpForLevelUp(oldLevel,newLevel,curExp){var newParams=newLevelCalculate(oldLevel,curExp,0);oldLevel=newParams.Level;curExp=newParams.Experience;if(newLevel<=oldLevel){return 0;}
var result=UserProgress[oldLevel-1]-curExp;for(var i=oldLevel;i+1<newLevel;++i){result+=UserProgress[i];}
return result;}