function calcCoinLevelInflationMultiplier(level,levelOffset){if(levelOffset===void 0){levelOffset=1;}
var powInflation=Math.pow(moneyInflation,Math.min(level-levelOffset,maxLevelPowInflation-levelOffset));var linearInflation=1+Math.max(level-maxLevelPowInflation,0)*moneyLinearInflation;return powInflation*linearInflation;}
function calcCoinLevelInflation(price,level){return price*calcCoinLevelInflationMultiplier(level);}
function calcBaseCoinPriceFromInflated(price,level){return price/calcCoinLevelInflationMultiplier(level);}
function reduceWPinStart(inputRelativePower,partOfChapter){var smallExp=2;var bigExp=5;var nerfPower=Math.pow(1-Math.pow(partOfChapter,smallExp),bigExp);var shift=nerfPower*inputRelativePower;return inputRelativePower-shift;}
function getWParrayForSurvival(wpParams,fightIndex,lastFightIndex,rounds){var result=[];var startPoint=wpParams.min;var length=wpParams.max-wpParams.min;var roundsLength=length*wpParams.width;var startingPointsLength=length-roundsLength;var beginIn=startPoint+(fightIndex/lastFightIndex*startingPointsLength);for(var i=0;i<rounds;i++){var valueWOnerf=beginIn+(i/(rounds-1)*roundsLength);var relativePosition=valueWOnerf-startPoint;relativePosition=reduceWPinStart(relativePosition,(valueWOnerf-startPoint)/length);if(!relativePosition){relativePosition=0;}
result.push(startPoint+relativePosition);}
return result;}
function calcCoinZoneInflation(price,zone){return price*calcCoinLevelInflationMultiplier(zone.MaxLevel,3);}
function calcBrawlerCoinZoneInflation(price,zone){return price*calcCoinLevelInflationMultiplier(zone.MaxLevel,3)*zone.BrawlerInf;}
function serverDictToObject(dict){var equipment={};for(var id in dict){if(ItemModelsMap.getValues().hasOwnProperty(id)){var item=ItemModelsMap.get(id);if(!item.NoShop&&dict[id]&&dict[id]!=null){equipment[id]=dict[id];}}
else{equipment[id]=dict[id];}}
return equipment;}
function equipFilterByRarity(equipment,rarities,level,notBest){var bestItems=calcBestItems(level,equipment,EventItemsIDs);var result={};for(var ID in equipment){var item=ItemModelsMap.get(ID);if(item){if(item.hasOwnProperty("Rarity")&&rarities.indexOf(item.Rarity)>-1&&!item.NoShop){if(notBest&&bestItems[item.ItemType]){var badItemSL=bestItems[item.ItemType]["SL"];if(equipment[item.ID]<badItemSL){result[ID]=equipment[ID];}}
result[ID]=equipment[ID];}}}
return result;}
function equipFilterByItemType(equip,types){var result={};for(var ID in equip){var item=ItemModelsMap.get(ID);if(item){if(item.hasOwnProperty("ItemType")&&types.indexOf(item.ItemType)>-1){result[ID]=equip[ID];}}}
return result;}
function equipFilterByMinDropLevel(equip,playerLevel){var result={};var zone=getZoneByLevel(playerLevel);var alternativeMaxLevel=zone.AlternativeMaxLevel?zone.AlternativeMaxLevel:playerLevel;for(var ID in equip){var item=ItemModelsMap.get(ID);if(item){if(item.hasOwnProperty("MinDropLevel")&&item.MinDropLevel>alternativeMaxLevel){continue;}
result[ID]=equip[ID];}}
return result;}
function getPower(stackLevel1,stackLevel2,rarity,levelDiff){var bar1=getProgressBar(stackLevel1,rarity);var bar2=getProgressBar(stackLevel2,rarity);var maxBar=stackLevel1>stackLevel2?bar1:bar2;var minBar=stackLevel1<stackLevel2?bar1:bar2;var cardsForStepBase=getRarityCardsForStepsBase(rarity);var cardsForStepInf=calcRarityCardsForStepInf(rarity,levelDiff);var deltaSteps=Math.abs(getDeltaSteps(stackLevel1,stackLevel2,rarity));return maxBar+1/(cardsForStepBase*Math.pow(cardsForStepInf,deltaSteps-minBar));}
function getBaseStackLevel(stackLevel,rarity){var stackPerStep=getRarityStackPerStep(rarity);return Math.floor(stackLevel/stackPerStep)*stackPerStep;}
function getNoFloorBaseStackLevel(stackLevel,rarity){var stackPerStep=getRarityStackPerStep(rarity);return stackLevel/stackPerStep*stackPerStep;}
function getDeltaSteps(stackLevel1,stackLevel2,rarity){var stackPerStep=getRarityStackPerStep(rarity);return(getBaseStackLevel(stackLevel2,rarity)-getBaseStackLevel(stackLevel1,rarity))/stackPerStep;}
function getPowerSteps(power,rarity,levelDiff){var inflation=calcRarityCardsForStepInf(rarity,levelDiff);return Math.floor(Math.log((inflation-1)*power+1)/Math.log(inflation));}
function calcBar(power,steps,rarity,levelDiff){var cardsForStepInf=calcRarityCardsForStepInf(rarity,levelDiff);var totalInf=Math.pow(cardsForStepInf,steps);return(power-(totalInf-1)/(cardsForStepInf-1))/totalInf;}
function mergeStackLevels(stackLevel1,stackLevel2,rarity){var levelDiff=Math.floor(Math.abs(stackLevel1-stackLevel2)/stackPerLevel);var power=getPower(stackLevel1,stackLevel2,rarity,levelDiff);var steps=getPowerSteps(power,rarity,levelDiff);var bar=calcBar(power,steps,rarity,levelDiff);var stackPerStep=getRarityStackPerStep(rarity);return(steps+bar)*stackPerStep+getBaseStackLevel(Math.max(stackLevel1,stackLevel2),rarity);}
function capStacklevel(stackLevelAdded){var cap=endgameZone.MaxLevel*stackPerLevel;if(stackLevelAdded>cap){stackLevelAdded=cap;}
return stackLevelAdded;}
function createOrMergeEquipment(modelID,stackLevelOwned,stackLevelAdded,playerLevel,newGameRateOwned,playerParameters){var model=ItemModelsMap.checkedGet(modelID);var newGameRateActual=getNGRByLevel(playerLevel);var resistance=getResistance(modelID,newGameRateOwned,newGameRateActual);var result={SL:null,Currencies:null,newGameRate:newGameRateActual,Parameters:(_a={},_a[PLAYER_PARAMETER.RESISTANCE]=resistance,_a)};if(stackLevelOwned!=null){result.SL=mergeStackLevels(stackLevelOwned,stackLevelAdded,model.Rarity);var oldBase=getBaseStackLevel(stackLevelOwned,model.Rarity);var newBase=getBaseStackLevel(result.SL,model.Rarity);if(true){var shadow=calcShadowPriceStackReward(playerLevel,model,newBase);result.Currencies=new RoundedCurrencies({SHADOW:shadow}).toMap();}}
else{result.SL=Math.max(stackLevelAdded,model.Level*stackPerLevel);}
return result;var _a;}
function createOrReplaceEquipment(modelID,stackLevelOwned,stackLevelAdded,playerLevel,newGameRateOwned,playerParameters){var model=ItemModelsMap.checkedGet(modelID);var newGameRateActual=getNGRByLevel(playerLevel);var resistance=getResistance(modelID,newGameRateOwned,newGameRateActual);var result={SL:stackLevelAdded,Currencies:null,newGameRate:newGameRateActual,Parameters:(_a={},_a[PLAYER_PARAMETER.RESISTANCE]=resistance,_a)};return result;var _a;}
function createOrReplaceArtifacts(modelID,stackLevelOwned,stackLevelAdded,playerLevel,newGameRateOwned,playerParameters){var model=ArtifactsMap.checkedGet(modelID);var result={Currencies:null,Parameters:(_a={},_a[PLAYER_PARAMETER.RESISTANCE]=0,_a),level:1};return result;var _a;}
function getResistance(itemID,newGameRateOwned,newGameRateActual){var item=ItemModelsMap.checkedGet(itemID);var resistance=0;if(newGameRateOwned==null){newGameRateOwned=0;}
for(var _i=0,NUM_NEW_GAME_RATES_1=NUM_NEW_GAME_RATES;_i<NUM_NEW_GAME_RATES_1.length;_i++){var currentNGR=NUM_NEW_GAME_RATES_1[_i];if(newGameRateActual&&currentNGR>newGameRateOwned&&currentNGR<=newGameRateActual&&ItemsResistanceRewards[currentNGR]){resistance+=ItemsResistanceRewards[currentNGR][item.Rarity].playerParameters.RESISTANCE;}}
return resistance;}
function getLevelUpCount(currentStackLevel,newStackLevel,rarity,updateType){switch(updateType){case UpdateType.Merge:return getDeltaSteps(currentStackLevel,mergeStackLevels(currentStackLevel,newStackLevel,rarity),rarity);case UpdateType.Replace:return getDeltaSteps(currentStackLevel,newStackLevel,rarity);}}
function getLevelUpBar(stackLevel1,stackLevel2,rarity){return getProgressBar(mergeStackLevels(stackLevel1,stackLevel2,rarity),rarity);}
function modifyAttributeWithFactor(attributeName,attributeValue,factor){switch(attributeName){case Attributes.COOLDOWN:case Attributes.CRITICAL_CHANCE:return attributeValue*factor;default:return Math.max(attributeValue+calculateAttributeFactor(factor),-MAX_SAFE_INTEGER);}}
function Atan(z){var absZ=Math.abs(z);if(absZ<=1){return z/(1+0.28*z*z);}
var inv=1/z;var atanInv=inv/(1+0.28*inv*inv);return z>0?Math.PI/2-atanInv:-Math.PI/2-atanInv;}
function Atan2(y,x){if(x===0){if(y>0)
return Math.PI/2;if(y<0)
return-Math.PI/2;return 0;}
var angle=Atan(y/x);if(x<0){angle+=y>=0?Math.PI:-Math.PI;}
return angle;}
function calcClanPowerFactor(deltaPower){var A=ClanPvPPowerFactorParams.A,B=ClanPvPPowerFactorParams.B,C=ClanPvPPowerFactorParams.C;var result=A+B*Atan2((deltaPower-144),C);return Math.min(Math.max(result,0),100000);}
function calcBasePowerFactor(delta,isPlayer,battle){var result=(delta/10)+1;var maxPowerFactor;if(isPlayer){maxPowerFactor=3;}
else{maxPowerFactor=4;}
return Math.min(Math.max(result,0.05),maxPowerFactor);}
function getRaidID(raidBattleID){for(var raidID in Raids){var raid=Raids[raidID];var raidLevels=raid.raidLevels.map(function(raidBattle){return raidBattle.id;});if(raid.raidLevels&&raidLevels.indexOf(raidBattleID)!=-1){return{id:raid.ID,lvl:raidLevels.indexOf(raidBattleID)+1,};}}}
function calcInputFactor(factors){var personalFactorsSum=1;var generalFactorsSum=1;var bossBalanceFactorsSum=1;var triggerBalanceFactorsSum=1;for(var factorType in factors){switch(factorType){case"general":for(var _i=0,_a=factors[factorType];_i<_a.length;_i++){var factor=_a[_i];if(factor!=undefined&&isNumber(factor)){generalFactorsSum+=(factor-1);}}
break;case"BossBalance":for(var _b=0,_c=factors[factorType];_b<_c.length;_b++){var factor=_c[_b];if(factor!=undefined&&isNumber(factor)){bossBalanceFactorsSum+=(factor-1);}}
break;case"TriggerBalance":for(var _d=0,_e=factors[factorType];_d<_e.length;_d++){var factor=_e[_d];if(factor!=undefined&&isNumber(factor)){triggerBalanceFactorsSum+=(factor-1);}}
break;default:for(var _f=0,_g=factors[factorType];_f<_g.length;_f++){var factor=_g[_f];if(factor!=undefined&&isNumber(factor)){personalFactorsSum+=(factor-1);}}
break;}}
return Math.max(personalFactorsSum,0.1)*Math.max(generalFactorsSum,0.1)*Math.max(bossBalanceFactorsSum,0.1)*Math.max(triggerBalanceFactorsSum,0.1);}
function calculatePlayerDamage(baseDamage,attributes,factors,boolInformation,battleID){var battle=BattlesMap.get(battleID);if(!battle)
battle=factionWarBattleArchetypesMap.get(battleID);if(boolInformation['useBaseDamage']){return baseDamage;}
if(battleID===1081011||battleID===1081021&&boolInformation['isPlayer']){if(attributes['AttackType']===Attributes.CONSUMABLE_DAMAGE){baseDamage=1;}}
if(battle.Type===BattleType.RAID&&boolInformation['isPlayer']){if(attributes['AttackType']===Attributes.CONSUMABLE_DAMAGE){switch(baseDamage){case 0.02:baseDamage=0.03000;break;case 0.03:baseDamage=0.04500;break;case 0.04:baseDamage=0.07497;break;}
attributes['AttackerAttributes'][attributes['AttackType']]=Math.min(attributes['AttackerAttributes']["MagicPower"],101.25);}}
var defence=attributes['DefenderAttributes'][attributes['DefenseType']];var attack=attributes['AttackerAttributes'][attributes['AttackType']];if(!defence&&attributes['DefenseType']===Attributes.HEAD_DEFENSE){defence=attributes['DefenderAttributes'][Attributes.BODY_DEFENSE];}
if(!attack&&attributes['AttackType']===Attributes.MAGIC_POWER){attack=attributes['AttackerAttributes'][Attributes.BODY_DEFENSE];}
var unarmedDamage=attributes['AttackerAttributes'][Attributes.UNARMED_DAMAGE];var weaponDamage=attributes['AttackerAttributes'][Attributes.WEAPON_DAMAGE];if(attributes['AttackType']===Attributes.WEAPON_DAMAGE&&unarmedDamage!==undefined){attack=Math.max(weaponDamage,(unarmedDamage-6.5));}
var allAttackFactors=Math.max(calcInputFactor(factors['AttackFactor']),0.1);var allDefenseFactors=Math.max(calcInputFactor(factors['DefenseFactor']),0.1);var superMoveMultiplier=attributes['SuperMove']?EnhancementCalculate.getSuperMoveMultiplier(attributes['SuperMove']['ID'],attributes['SuperMove']['StackLevel']):1;superMoveMultiplier=(superMoveMultiplier-1)*0.5+1;var block=boolInformation['isBlock']?0.25:1;var crit=(boolInformation['isHeraldsCrit']&&attributes['AttackerAttributes']['CriticalDamage'])?attributes['AttackerAttributes']['CriticalDamage']:(boolInformation['isCommonCrit']?1.75:1);var powerFactor;var usePvPFormula=battle&&(battle.Subtype===BattleSubtype.CLAN_BATTLE||!!(battle.PlayerAttributeSettings&&battle.PlayerAttributeSettings.UsePvPDamageFormula));if(usePvPFormula){var pvpAttack=attributes['AttackerAttributes'][Attributes.PvP_ATTACK]||0;var pvpDefense=attributes['DefenderAttributes'][Attributes.PvP_DEFENSE]||0;var deltaPower=pvpAttack-pvpDefense;powerFactor=calcClanPowerFactor(deltaPower);}
else{var delta=(attack-defence);powerFactor=calcBasePowerFactor(delta,boolInformation['isPlayer'],battle);}
var result=baseDamage*(allAttackFactors+superMoveMultiplier-1)*powerFactor*block*crit/allDefenseFactors;if(battle.Type===BattleType.RAID&&boolInformation['isPlayer']){var amplifier=void 0;if(attributes['AttackType']===Attributes.CONSUMABLE_DAMAGE){amplifier=battle.RaidPlayerConsumableDamageAmplifier;}
else{amplifier=battle.RaidPlayerCommonDamageAmplifier;}
result*=amplifier;}
if(battle.Type===BattleType.BRAWLER){var weakSlotMultiplier=1;if(boolInformation['isPlayer']){for(var _i=0,_a=[Attributes.WEAPON_DAMAGE,Attributes.UNARMED_DAMAGE,Attributes.MAGIC_POWER,Attributes.RANGED_DAMAGE];_i<_a.length;_i++){var attr=_a[_i];if(attributes['AttackerAttributes'][attr]-attack>2){weakSlotMultiplier=0.7;}}}
var clampedResult=Math.max(Math.min(result,1),0);return weakSlotMultiplier*clampedResult;}
else{return Math.max(Math.min(result,1),0);}}
function compareItems(firstID,firstSL,secondID,secondSL,itemsMap,firstPP,secondPP){var firstItem=itemsMap.checkedGet(firstID);var secondItem=itemsMap.checkedGet(secondID);var firstModifSL=getBaseRarityStackLevelShift(firstItem)+firstSL;var secondModifSL=getBaseRarityStackLevelShift(secondItem)+secondSL;if(firstPP&&secondPP){firstModifSL*=firstPP;secondModifSL*=secondPP;}
return firstModifSL<secondModifSL;}
function extractClassicForms(rawObjInventory){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var inventory=objInventory?new Inventory(objInventory):undefined;var equipments=inventory?(inventory.getEquipmentsClassicForm()):{};var perks=inventory?(inventory.getPerksClassicForm()):{};return{equipments:equipments,perks:perks};}
function extractClassicFormArrays(rawObjInventory){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var inventory=objInventory?new Inventory(objInventory):undefined;var equipments=inventory?(inventory.getEquipmentsClassicFormArray()):[];var perks=inventory?(inventory.getPerksClassicFormArray()):[];return{equipments:equipments,perks:perks};}
function calcLocationDifficulty(currentResistance,recommendedResistance){var difficulty=locationEffectDifficultySteps(currentResistance,recommendedResistance,[1,2,3,4,5]);return{RawDifficulty:difficulty.RawDifficulty,RoundedDifficulty:Math.round(difficulty.RawDifficulty)};}
function multiplyDifficulties(powerDifficulty,locationDifficulty){if(powerDifficulty>=4){return 4;}
if(locationDifficulty.RoundedDifficulty>=4){return 4;}
var powerOffset=locationDifficulty.RawDifficulty>=3?0:1;var result=powerDifficulty+locationDifficulty.RawDifficulty-powerOffset;result=Math.round(Math.max(powerDifficulty,result));return Math.min(Math.max(0,result),4);}
function calcFightDifficulty(rawInventory,battleID,pregeneratedRound,factionWarDTO){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawInventory);var playerParameters=objInventory.parameters;var modifier=0;var maxDiff=4;var minDiff=0;var resultDifficulty=0;if(battleID==1200&&!playerParameters[1]){return DIFFICULTY.INSANE;}
var battle=(factionWarDTO!=null)?factionWarCombineBattleModel(FACTION.LEGION,FACTION.DYNASTY,factionWarDTO):BattlesMap.get(battleID);if(battle.Type===BattleType.SIDE&&battle.Subtype===BattleSubtype.FACTION_WARS_BATTLE){return DIFFICULTY.NORMAL;}
if(battle.Type==BattleType.INTERCHAPTER||battle.MainWithoutEnemy){return 0;}
if(battle.OverwrittenFightDifficulty!=undefined){if(typeof battle.OverwrittenFightDifficulty==="number"){resultDifficulty=battle.OverwrittenFightDifficulty-1;if(!!battle.RecommendedResistance){var playerResistance=(playerParameters[PLAYER_PARAMETER.RESISTANCE])?playerParameters[PLAYER_PARAMETER.RESISTANCE]:0;var locationDifficulty=calcLocationDifficulty(playerResistance,battle.RecommendedResistance);resultDifficulty=multiplyDifficulties(resultDifficulty,locationDifficulty);}
resultDifficulty=Math.min(Math.max(resultDifficulty,0),4);resultDifficulty=(QA_TOOLS&&QA_NO_IMPOSSIBLE_DIFFICULTY)?Math.min(resultDifficulty,3):resultDifficulty;return resultDifficulty;}
else{if(!isNaN(Number(battle.OverwrittenFightDifficulty))){modifier=Number(battle.OverwrittenFightDifficulty);}
else{var limitArr=battle.OverwrittenFightDifficulty.split(" ");if(limitArr[0]=="min"){minDiff=Number(limitArr[1]);}
if(limitArr[0]=="max"){maxDiff=Number(limitArr[1]);}}}}
var _a=extractClassicFormArrays(objInventory),equipments=_a.equipments,perks=_a.perks;var playerAttributes=getPlayerAttributes(equipments,playerParameters,battle);if(playerAttributes["WeaponDamage"]<playerAttributes["UnarmedDamage"]){playerAttributes["WeaponDamage"]=playerAttributes["UnarmedDamage"];}
if(battle["Rules"]){for(var i=0;i<battle["Rules"].length;i++){var rb=battle["Rules"][i]["RuleBlocks"][0];if((rb["ID"]==RoundRules.GiveItem.ID&&rb["Attributes"]["9"]==1000000&&rb["Attributes"]["3"]=="Player")||rb["ID"]==RoundRules.NoPunches.ID){playerAttributes["WeaponDamage"]=playerAttributes["UnarmedDamage"];}}}
var playerPerkPower=1;for(var v=0;v<perks.length;v++){playerPerkPower+=(EnhancementCalculate.power(perks[v]["ModelID"],perks[v]["SL"]))*0.3;}
var pInf={exp:20,faction:1,level:4,mainBattleID:battle.ID,mainFightIndex:0,playerVars:{1:999999},};var generatedRound;generatedRound=pregeneratedRound?pregeneratedRound:generateBattle(battleID,pInf,0,objInventory).generateBattle.fights[0].rounds[0];var enemyWP=generatedRound["warrior"]["power"]+modifier*ruleDifficultyScale;var enemyAttributes=getEnemyAttributes(enemyWP);var enemyPerkPower=1;var enemyPerks=generatedRound["warrior"]["perks"];for(var w=0;w<enemyPerks.length;w++){if(PerkModelsMap.checkedGet(enemyPerks[w]["modelId"]).PerkType==EnchantmentType.Perk){enemyPerkPower+=(EnhancementCalculate.power(enemyPerks[w]["modelId"],enemyPerks[w]["stackLevel"]))*0.3;}}
var playerHits={};var playerHitsFrequencies={};var playerBestHit;var playerBestHitPower=0;var playerCritChance=playerAttributes["CriticalChance"];if(!playerCritChance){playerCritChance=0.08;}
var playerCritDamage=playerAttributes["CriticalDamage"];if(!playerCritDamage){playerCritDamage=1.75;}
var enemyHits={};var enemyHitsFrequencies={};var enemyBestHit;var enemyBestHitPower=0;var enemyCritChance=enemyAttributes["CriticalChance"];var inf=Math.pow(attributesInflation,1/stackPerLevel);for(var _i=0,_b=["WeaponDamage","UnarmedDamage","MagicPower","RangedDamage"];_i<_b.length;_i++){var attackMode=_b[_i];for(var _c=0,_d=["BodyDefense","HeadDefense"];_c<_d.length;_c++){var defenseMode=_d[_c];var id=attackMode+defenseMode;var frequency=hitsFrequency[attackMode]*hitsFrequency[defenseMode];if(attackMode=="MagicPower"||attackMode=="RangedDamage"){if(defenseMode=="BodyDefense"&&playerAttributes[attackMode]){frequency=hitsFrequency[attackMode];}
else{frequency=0;}}
if(frequency>0){var enemyPower_1=Math.pow(inf,enemyAttributes[attackMode]-playerAttributes[defenseMode]);var playerPower_1=Math.pow(inf,playerAttributes[attackMode]-enemyAttributes[defenseMode]);if(enemyPower_1>enemyBestHitPower){enemyBestHit=id;enemyBestHitPower=enemyPower_1;}
if(playerPower_1>playerBestHitPower){playerBestHit=id;playerBestHitPower=playerPower_1;}
playerHits[id]=playerPower_1;enemyHits[id]=enemyPower_1;playerHitsFrequencies[id]=frequency*(1-bestHitFrequency);enemyHitsFrequencies[id]=frequency*(1-bestHitFrequency);}}}
playerHitsFrequencies[playerBestHit]+=bestHitFrequency;enemyHitsFrequencies[enemyBestHit]+=bestHitFrequency;var enemyPower=0;var playerPower=0;for(var id in playerHits){if(playerHits.hasOwnProperty(id)){enemyPower+=enemyHits[id]*enemyHitsFrequencies[id]*(1+enemyCritChance*(1.75+enemyHits[enemyBestHit]));playerPower+=playerHits[id]*playerHitsFrequencies[id]*(1+playerCritChance*(playerCritDamage+playerHits[playerBestHit]));}}
var difficulty=(enemyPower*enemyPerkPower)/(playerPower*playerPerkPower);var difficultyBorders=[0.7,1.1,2,4.4];for(var i=0;i<difficultyBorders.length;++i){resultDifficulty+=(difficulty>difficultyBorders[i])?1:0;}
if(!!battle.RecommendedResistance){var playerResistance=(playerParameters[PLAYER_PARAMETER.RESISTANCE])?playerParameters[PLAYER_PARAMETER.RESISTANCE]:0;var locationDifficulty=calcLocationDifficulty(playerResistance,battle.RecommendedResistance);resultDifficulty=multiplyDifficulties(resultDifficulty,locationDifficulty);}
if(isNaN(resultDifficulty)){return 1;}
resultDifficulty=Math.min(Math.max(resultDifficulty,0),4);resultDifficulty=(QA_TOOLS&&QA_NO_IMPOSSIBLE_DIFFICULTY)?Math.min(resultDifficulty,3):resultDifficulty;if(resultDifficulty>maxDiff){return maxDiff;}
if(resultDifficulty<minDiff){return minDiff;}
return resultDifficulty;}
function findItemPower(item){var itemModel=ItemModelsMap.checkedGet(item["ModelID"]);var itemRarity=itemModel.Rarity;var SLwithSteps=Math.floor(item["SL"]/getRarityStackPerStep(itemRarity))*getRarityStackPerStep(itemRarity);return getBaseRarityStackLevelShift(itemModel)+SLwithSteps;}
function getDeltaFromTwoItems(firstItem,secondItem){return findItemPower(secondItem)-findItemPower(firstItem);}
function getBetterEquipmentID(rawObjInventory,level,noDelta){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var _a=Inventory.getEquipmentsAndEquippedItemsByInventory(objInventory),playerFullEquipments=_a.playerFullEquipments,playerCurrentEquipments=_a.playerCurrentEquipments;var ranged=false;for(var key in playerCurrentEquipments){var item=ItemModelsMap.get(key);if(item&&item.ItemType==ITEMTYPE.RANGED){ranged=true;}}
if(!ranged){playerCurrentEquipments["600"]=1;}
var allItems=equipDictToArray(playerFullEquipments);var equippedItems=equipDictToArray(playerCurrentEquipments);var requiredDelta=noDelta?0:requiredDeltaForItemHint;var biggestDelta=0;var bestID=0;var itemTypePriority=[ITEMTYPE.WEAPON,ITEMTYPE.ARMOR,ITEMTYPE.HELMET,ITEMTYPE.RANGED];for(var _i=0,itemTypePriority_1=itemTypePriority;_i<itemTypePriority_1.length;_i++){var itemType=itemTypePriority_1[_i];for(var _b=0,equippedItems_1=equippedItems;_b<equippedItems_1.length;_b++){var eItem=equippedItems_1[_b];if(!!eItem){if(ItemModelsMap.getValues()[eItem["ModelID"]].ItemType==itemType){for(var _c=0,allItems_1=allItems;_c<allItems_1.length;_c++){var item=allItems_1[_c];if(!!item){var oneItem=ItemModelsMap.getValues()[item["ModelID"]];if(!!oneItem&&oneItem.Level<=level&&oneItem.ItemType==itemType){var delta=getDeltaFromTwoItems(eItem,item);if(delta>biggestDelta){biggestDelta=delta;bestID=item["ModelID"];}}}}
if(biggestDelta>requiredDelta&&Number(bestID)!=null){return Number(bestID);}}}}}
return 0;}
function getLocationDifficulty(currentResistance,battleId){var battle=BattlesMap.get(battleId);var result=0;if(!!battle&&!!battle.RecommendedResistance){result=calcLocationDifficulty(currentResistance,battle.RecommendedResistance).RoundedDifficulty;result=result in DIFFICULTY?result:0;}
return result;}
function getBetterRarityID(rawObjInventory,level){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var _a=Inventory.getEquipmentsAndEquippedItemsByInventory(objInventory),playerFullEquipments=_a.playerFullEquipments,playerCurrentEquipments=_a.playerCurrentEquipments;for(var key in playerCurrentEquipments){objInventory.equipments[key].stackLevel=0;}
for(var key in playerFullEquipments){objInventory.equipments[key].stackLevel=0;}
return getBetterEquipmentID(objInventory,level,true);}
function getShadowUpgradableItemID(rawInventory,playerLevel,playerCurrencies,eventID){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawInventory);var inventory=new Inventory(objInventory);var allItems=inventory.getEquipmentsArray();var result=-1;var bestPowerDelta=0;var playerShadow=playerCurrencies[CurrenciesModels.SHADOW.ID];var itemTypeArray=[ITEMTYPE.ARMOR,ITEMTYPE.WEAPON,ITEMTYPE.HELMET,ITEMTYPE.RANGED];var afordableItemsSorted={};var playerItemsSorted={};for(var _i=0,allItems_2=allItems;_i<allItems_2.length;_i++){var item=allItems_2[_i];if(!!item){var model=ItemModelsMap.get(item["ModelID"]);if(!model||!item["SL"]||item["SL"]==null||model.Rarity==RARITY.UNIQUE){continue;}
if(!playerItemsSorted[model["ItemType"]]){playerItemsSorted[model["ItemType"]]=[];}
playerItemsSorted[model["ItemType"]].push({Power:findItemPower(item),Item:item});var afterUpgrage=calcShadowUpgradeParameters(playerLevel,rawInventory,{modelId:model.ID,stackLevel:item.stackLevel},playerCurrencies,eventID);if(afterUpgrage.Price[CurrenciesModels.SHADOW.ID]<=playerShadow&&model.Level<=playerLevel){if(!afordableItemsSorted[model["ItemType"]]){afordableItemsSorted[model["ItemType"]]=[];}
item["SL"]=afterUpgrage.SL;afordableItemsSorted[model["ItemType"]].push({Power:findItemPower(item),Item:item,Price:afterUpgrage.Price});}}}
for(var type in playerItemsSorted){if(playerItemsSorted.hasOwnProperty(type)){playerItemsSorted[type].sort(function(x,y){return y["Power"]-x["Power"];});}}
for(var type in afordableItemsSorted){if(afordableItemsSorted.hasOwnProperty(type)){afordableItemsSorted[type].sort(function(x,y){var dPower=y["Power"]-x["Power"];return dPower!=0?dPower:(x["Price"]-y["Price"]);});}}
var koefs=calcItemsKoes();for(var _a=0,itemTypeArray_1=itemTypeArray;_a<itemTypeArray_1.length;_a++){var itemType=itemTypeArray_1[_a];if(afordableItemsSorted.hasOwnProperty(String(itemType))&&playerItemsSorted.hasOwnProperty(String(itemType))){var dPower=(afordableItemsSorted[itemType][0]["Power"]-playerItemsSorted[itemType][0]["Power"])*koefs[itemType];if(dPower>bestPowerDelta){bestPowerDelta=dPower;result=Number(afordableItemsSorted[itemType][0]["Item"]["ModelID"]);}}}
if(result==null){result=-1;}
return result;}
function getBestShopOffer(shopOffers,rawObjInventory,level,currencies){var objInventory=InventoryConverter.getLongInterfaceOfInventory(rawObjInventory);var result=null;var bestDelta=0;var playerCoins=currencies[CurrenciesModels.COIN.ID];var affordableOffers={};var newShopOffers=shopOffers;var equipments=extractClassicForms(objInventory).equipments;for(var offerIndex in newShopOffers){var offer=newShopOffers[offerIndex];var coinPrice=offer.price[CurrenciesModels.COIN.ID];var shopLoot=offer.loot;var item=shopLoot["equipments"][0];if(coinPrice&&coinPrice<=playerCoins&&item){affordableOffers[offerIndex]=offer;affordableOffers[offerIndex]["item"]=item;}}
var bestItems=calcBestItems(level,equipments,EventItemsIDs);var koefs=calcItemsKoes();for(var key in affordableOffers)
if(affordableOffers.hasOwnProperty(key)){var offer=affordableOffers[key];var itemModel=ItemModelsMap.checkedGet(Object.keys(offer["item"])[0]);var itemType=itemModel.ItemType;var bestItem={ModelID:bestItems[itemType].Item.ID,SL:bestItems[itemType].SL};var offerItem={ModelID:itemModel.ID,SL:offer["item"][itemModel.ID]};var powerDelta=getDeltaFromTwoItems(bestItem,offerItem)*koefs[itemType];if(powerDelta>bestDelta){bestDelta=powerDelta;result=Number(key);}}
return result;}
function getWfieldFromBattle(battle,fightIndex,fieldName){var warriorSettings;var battleModel=BattlesMap.checkedGet(battle);if(typeof battleModel.Fights==="number"){warriorSettings=battleModel.Warriors;}
else{if(fightIndex<0||fightIndex>=battleModel.Fights.length){throw"getWfieldFromBattle: fight index out of range: "+fightIndex+" (battle "+battle+" has "+battleModel.Fights.length+" fights)";}
warriorSettings=battleModel.Fights[fightIndex].Warriors;}
return getWarriorField(warriorSettings,fieldName);}
function getModWP(currDiff,currWP,currPP){var currAmp;switch(currDiff){case(DIFFICULTY.NORMAL):currAmp=DIFFICULTY_AMPLIF.EASY;break;case(DIFFICULTY.HARD):currAmp=DIFFICULTY_AMPLIF.NORMAL;break;case(DIFFICULTY.INSANE):currAmp=DIFFICULTY_AMPLIF.HARD;break;}
return makeWP(currWP,currAmp,currPP*100);}
function sumWeights(weightArray){var result=0;for(var objName in weightArray){if(weightArray.hasOwnProperty(objName)){var obj=weightArray[objName];if(!obj.hasOwnProperty("Weight")){obj.Weight=1;}
result+=obj.Weight;}}
return result;}
function getOddsString(probability){if(!probability||probability<=0){return;}
if(probability>=1){return"1:1";}
if(probability<=0.5){var leftSide=1;var rightSide=Math.ceil(roundToSplitDigit(1/probability,1.5));return leftSide+":"+rightSide;}
else{var numeratorStr=probability.toString();var denumerator=Math.pow(10,numeratorStr.length-2);while(numeratorStr.charAt(0)==='0'||numeratorStr.charAt(0)==='.'){numeratorStr=numeratorStr.substr(1);}
var denumeratorStr=denumerator.toString();if(numeratorStr.length>2){numeratorStr=numeratorStr.substr(0,2);denumeratorStr=denumeratorStr.substr(0,3);}
var array1=getSimpleNums(parseInt(numeratorStr));var array2=getSimpleNums(parseInt(denumeratorStr));removeDiff(array1,array2);return multiplyElements(array1)+":"+multiplyElements(array2);}}
function getSimpleNums(x){var arr=[];var num=2;getSimpleNumsRecursive(x,arr,num);return arr;}
function getSimpleNumsRecursive(x,arr,num){if(x==='1'){arr.push(1);}
if(x%num===0){arr.push(num);x=x/num;getSimpleNumsRecursive(x,arr,num);}
else if(x%num!==0){if(!(x<=num)){num++;getSimpleNumsRecursive(x,arr,num);}}}
function removeDiff(arr1,arr2){var i=0;var find=false;while(i<arr1.length){var j=0;while(j<arr2.length){if(arr1[i]===arr2[j]){arr1.splice(i,1);arr2.splice(j,1);find=true;break;}
else{j++;}}
if(!find){i++;}
find=false;}
if(arr1.length===0){arr1.push('1');}
if(arr2.length===0){arr2.push('1');}}
function multiplyElements(arr){var result=1;for(var i=0;i<arr.length;i++){result*=arr[i];}
return result;}
function makeChoice(weightArray){var partSum=0;var weightSum=sumWeights(weightArray);var randChoice=Math.random()*weightSum;for(var objName in weightArray){if(weightArray.hasOwnProperty(objName)){var obj=weightArray[objName];partSum+=obj.Weight;if(partSum>randChoice){return obj;}}}
throw"makeChoise: can't make choise";}
function roundCoinsForInApps(initialCoins,playerLevel,roundTo){return Math.ceil((calcCoinLevelInflation(initialCoins*coinBase,playerLevel))/roundTo)*roundTo;}
function calcSLupgradeLimit(PlayerLevel,ModelID){var model=ItemModelsMap.checkedGet(ModelID);if(model.UpgradeCurrencyName){return MAX_SAFE_INTEGER;}
else{return(PlayerLevel+4)*stackPerLevel;}}
function canEnterBattle(battleID,dan){var battle=BattlesMap.checkedGet(battleID);if(battle.MinimumDan&&battle.MinimumDan>dan){return false;}
else{return true;}}
function calcChangeAppearanceCost(changeCount){if(changeCount<FreeChangeAppearanceAttempts){return{};}
else{return new Currencies({BONUS:FreeChangeAppearanceBonusCost}).toMap();}}
function calcChangeNickNameCost(changeCount){if(changeCount<FreeChangeNickNameAttempts){return{};}
else{return new Currencies({BONUS:FreeChangeNickNameBonusCost}).toMap();}}
function equipDictToArray(equipments){var result=[];for(var id in equipments){result.push({ModelID:id,SL:equipments[id]});}
return result;}
function calcBestOwnedPower(playerLevel,ownedMap,excluded,clampSLToBase){if(clampSLToBase===void 0){clampSLToBase=false;}
var bestPower={};for(var itemID in ownedMap){var item=ItemModelsMap.get(itemID);if(!item||excluded.indexOf(itemID)!=-1||(item.Level>playerLevel)){continue;}
var stackLevel=clampSLToBase?getBaseStackLevel(ownedMap[itemID],item.Rarity):ownedMap[itemID];var itemPower=stackLevel+getBaseRarityStackLevelShift(item);if(bestPower[item.ItemType]==null||itemPower>bestPower[item.ItemType]){bestPower[item.ItemType]=itemPower;}}
return bestPower;}
function calcBestOwnedPowers(playerLevel,ownedMap,excluded){try{var bestPower={};for(var itemID in ownedMap){var item=ItemModelsMap.get(itemID);if(!item||excluded.indexOf(item)!=-1||(item.Level>playerLevel)){continue;}
var itemPower=ownedMap[itemID]+getBaseRarityStackLevelShift(item);if(bestPower[item.ItemType]==null||itemPower>bestPower[item.ItemType]){bestPower[item.ItemType]=itemPower;}}
var totalPower=0;for(var selected in bestPower){totalPower+=bestPower[selected];}
return(totalPower/Object.keys(bestPower).length);}
catch(e){throw new Error(e.message+
("(playerLevel: "+playerLevel+" \n            ownedMap: "+JSON.stringify(javaDictToJs(ownedMap))+" \n            excluded: "+JSON.stringify(excluded)+")"));}}
function calcBestItems(playerLevel,ownedMap,excluded,epicOrBest){var bestPower={};var bestItems={};var drawback={};for(var itemID in ownedMap){var item=ItemModelsMap.get(itemID);if(!item||excluded.indexOf(itemID)!=-1||(item.Level>playerLevel)){continue;}
var itemPower=ownedMap[itemID]+getBaseRarityStackLevelShift(item);if(bestPower[item.ItemType]==null||itemPower>bestPower[item.ItemType]["Power"]){if(epicOrBest&&(item.Rarity!=RARITY.EPIC&&item.Rarity!=RARITY.LEGENDARY)){drawback[item.ItemType]={ID:itemID,Power:itemPower};continue;}
bestPower[item.ItemType]={ID:itemID,Power:itemPower};}}
bestPower=(Object.keys(bestPower).length>0)?bestPower:drawback;for(var item in bestPower){var selectedItem=ItemModelsMap.get(bestPower[item]["ID"]);bestItems[item]={Item:selectedItem,SL:ownedMap[selectedItem.ID]};}
return bestItems;}
function convertBonusToCoins(bonus,playerLevel){return calcCoinZoneInflation((bonus*coinBase*baseCoinForBonus),getZoneByLevel(playerLevel));}
function getPartLevel(level,exp){return level;}
function getVisualPowerForBrawler(allPlayerEquipments,botEquipments,playerRating,inTop){var SL=0;for(var key in botEquipments){SL=botEquipments[key];}
if(SL<0){var defaultItems=(_a={},_a[ITEMTYPE.ARMOR]=ItemModels.ARM_STR_02.ID,_a[ITEMTYPE.HELMET]=ItemModels.HLM_STR_01.ID,_a[ITEMTYPE.WEAPON]=ItemModels.WPN_ONEHANDED_SWORD_01_01.ID,_a[ITEMTYPE.RANGED]=ItemModels.RNG_ARBALEST_01.ID,_a);var equipArray=[];for(var id in botEquipments){var item=ItemModelsMap.get(Number(id));equipArray.push({ModelID:defaultItems[item.ItemType],SL:-botEquipments[id]});}
return calcVisibleEquipPower(equipArray,true);}
else{var bestEquipMap_1=(_b={},_b[ITEMTYPE.WEAPON]={modelId:0,stackLevel:0},_b[ITEMTYPE.HELMET]={modelId:0,stackLevel:0},_b[ITEMTYPE.RANGED]={modelId:0,stackLevel:0},_b[ITEMTYPE.ARMOR]={modelId:0,stackLevel:0},_b);Object.keys(allPlayerEquipments).forEach(function(ID){var item=ItemModelsMap.get(ID);if(!!item){bestEquipMap_1[item.ItemType]=(bestEquipMap_1[item.ItemType].stackLevel<allPlayerEquipments[ID])?{modelId:Number(ID),stackLevel:allPlayerEquipments[ID]}:bestEquipMap_1[item.ItemType];}});var bestEquip_1={};Object.keys(bestEquipMap_1).forEach(function(x){if(bestEquipMap_1[x].modelId)
bestEquip_1[bestEquipMap_1[x].modelId]=bestEquipMap_1[x].stackLevel;});var playerVPower=getSumOfVisiblePowers(bestEquip_1);var botVPower=getSumOfVisiblePowers(botEquipments);if(!inTop)
return botVPower;var diff=Math.abs(playerVPower-botVPower);var vfp=visualPowerFakeParameters;var percentDiff=diff/playerVPower*(1-vfp.EarlyRatingPenalty/(playerRating+vfp.EarlyRatingPenalty));var powerOfFake=0;var rndK=(Math.random()*2-1)*0.03;var x1=vfp.Start-vfp.Smoothness/2+rndK;var x2=vfp.Start+vfp.Smoothness/2+rndK;var x3=vfp.End-vfp.Smoothness/2+rndK;var x4=vfp.End+vfp.Smoothness/2+rndK;if(percentDiff>=x1){if(percentDiff<x2){powerOfFake=-(Math.cos((percentDiff-x1)/(x2-x1)*Math.PI)-1)/2*vfp.Power;}
else if(percentDiff<x3){powerOfFake=vfp.Power;}
else if(percentDiff<x4){powerOfFake=vfp.Power+(Math.cos((percentDiff-x3)/(x4-x3)*Math.PI)-1)/2*vfp.Power;}}
return Math.ceil(botVPower*(1-powerOfFake)+playerVPower*powerOfFake);}
var _a,_b;}
function convertNewGameLevel(level){var additionalNewGameZoneLevel=undefined;if(level>=Zones.Zone8.MinLevel&&level<=Zones.Zone8.MaxLevel){level=Zones.Zone8.AlternativeMaxLevel;}
if(level>=Zones.Zone9.MinLevel&&level<=Zones.Zone9.MaxLevel){level=Zones.Zone9.AlternativeMaxLevel;}
if(level>=Zones.Zone10.MinLevel&&level<=Zones.Zone10.MaxLevel){level=Zones.Zone10.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone10.AdditionalLevel;}
if(level>=Zones.Zone11.MinLevel&&level<=Zones.Zone11.MaxLevel){level=Zones.Zone11.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone11.AdditionalLevel;}
if(level>=Zones.Zone12.MinLevel&&level<=Zones.Zone12.MaxLevel){level=Zones.Zone12.AlternativeMaxLevel;}
if(level>=Zones.Zone13.MinLevel&&level<=Zones.Zone13.MaxLevel){level=Zones.Zone13.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone13.AdditionalLevel;}
if(level>=Zones.Zone14.MinLevel&&level<=Zones.Zone14.MaxLevel){level=Zones.Zone14.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone14.AdditionalLevel;}
if(level>=Zones.Zone15.MinLevel&&level<=Zones.Zone15.MaxLevel){level=Zones.Zone15.AlternativeMaxLevel;}
if(level>=Zones.Zone16.MinLevel&&level<=Zones.Zone16.MaxLevel){level=Zones.Zone16.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone16.AdditionalLevel;}
if(level>=Zones.Zone17.MinLevel&&level<=Zones.Zone17.MaxLevel){level=Zones.Zone17.AlternativeMaxLevel;additionalNewGameZoneLevel=Zones.Zone17.AdditionalLevel;}
return{level:level,additionalNewGameZoneLevel:additionalNewGameZoneLevel};}
function changeAttributesByResistance(attributes,currentResistance,recommendedResistance){var result={};for(var _i=0,attributes_1=attributes;_i<attributes_1.length;_i++){var attr=attributes_1[_i];result[attr.AttrId]=String(attr.ChangeAttributeValueFunction(currentResistance,recommendedResistance));}
return result;}
function getResistanceStep(recommendedResistance){if(recommendedResistance<=lastRecommendedResistanceNG1){return recommendedResistanceStepNG1;}
if(recommendedResistance<=lastRecommendedResistanceNG2){return recommendedResistanceStepNG2;}
if(recommendedResistance<=lastRecommendedResistanceNG3_1){return recommendedResistanceStepNG3_1;}
if(recommendedResistance<=lastRecommendedResistanceNG3_2){return recommendedResistanceStepNG3_2;}
if(recommendedResistance<=lastRecommendedResistanceNG3_3){return recommendedResistanceStepNG3_3;}
if(recommendedResistance<=lastRecommendedResistanceNG3_4){return recommendedResistanceStepNG3_4;}
return recommendedResistanceStepNG3_4;}
function linearInterpolation(X,Y,x){if(!X.length||!Y.length||X.length!=Y.length){throw new Error("Incorrect input arrays");}
var n=X.length;if(n==1||x<X[0]){return Y[0];}
if(x>X[n-1]){return Y[n-1];}
for(var i=1;i<n;i++){if(x>=X[i-1]&&x<=X[i]){return Y[i-1]+(Y[i]-Y[i-1])*(x-X[i-1])/(X[i]-X[i-1]);}}
return Y[n-1];}
function locationEffectDifficultySteps(currentResistance,recommendedResistance,bounds){if(!bounds||bounds.length!=5){throw"Incorrect bounds array for variable rule!";}
var difStep=getResistanceStep(recommendedResistance)/4;var resistanceBounds=[0,difStep,difStep*2,difStep*3,difStep*4];var delta=recommendedResistance-currentResistance;if(delta<=0){return{Value:bounds[0],RawDifficulty:0};}
if(delta>=difStep*4){return{Value:bounds[4],RawDifficulty:4};}
var result={Value:linearInterpolation(resistanceBounds,bounds,Math.max(delta,0)),RawDifficulty:linearInterpolation(resistanceBounds,[0,1,2,3,4],Math.max(delta,0))};return result;}
function calcRecommendedVisiblePower(generatedBattle,battle){if(!((generatedBattle.fights&&generatedBattle.fights[0].rounds[0].warrior)&&!(battle.PlayerAttributeSettings&&!battle.PlayerAttributeSettings.StackLevel)&&!(battle.OverwrittenFightDifficulty in DIFFICULTY)&&!battle.HideDifficulty)){return undefined;}
var wp=0;var startSl=0;var finishSL=0;if(generatedBattle.fights&&generatedBattle.fights.length>0){wp=generatedBattle.fights[0].rounds[0].warrior.power;startSl=Math.max(wp-10,0);finishSL=wp+100;var lastResult=startSl;for(startSl;startSl<=finishSL;startSl+=getRarityStackPerStep(RARITY.COMMON)){var items=battle.ID>=60?new Inventory((_a={},_a[20]=new ModelIdAndStackLevel({modelId:20,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_a[203]=new ModelIdAndStackLevel({modelId:203,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_a[401]=new ModelIdAndStackLevel({modelId:401,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_a[614]=new ModelIdAndStackLevel({modelId:614,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_a),{}):new Inventory((_b={},_b[20]=new ModelIdAndStackLevel({modelId:20,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_b[203]=new ModelIdAndStackLevel({modelId:203,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_b[401]=new ModelIdAndStackLevel({modelId:401,stackLevel:startSl,newGameRate:NEW_GAME_RATES.DEFAULT}),_b),{});items.parameters=(_c={},_c[PLAYER_PARAMETER.RESISTANCE]=999999,_c);var result=calcFightDifficulty(items,battle.ID,generatedBattle.fights[0].rounds[0]);lastResult=startSl;if(result==DIFFICULTY.EASY){break;}}
var resultItem=battle.ID>=60?[{ModelID:20,SL:lastResult},{ModelID:203,SL:lastResult},{ModelID:401,SL:lastResult},{ModelID:614,SL:lastResult},]:[{ModelID:20,SL:lastResult},{ModelID:203,SL:lastResult},{ModelID:401,SL:lastResult},];return roundUpToSignificantDigits(calcVisibleEquipPower(resultItem),3,10);;}
return 0;var _a,_b,_c;}
function calcRecommendedParams(generatedBattle,battle){if(battle.RecommendedResistance!=undefined){generatedBattle.recommendedResistance=battle.RecommendedResistance;}
var recommendedVisiblePower=RecommendedVisiblePowerHash[battle.ID];generatedBattle.recommendedVisiblePower=recommendedVisiblePower?recommendedVisiblePower:null;}
function calcRecommendedEventPower(generatedBattle,battle){if(battle.RecommendedPower){generatedBattle.recommendedVisiblePower=battle.RecommendedPower;}
else{generatedBattle.recommendedVisiblePower=null;}}
function subtractStackLevel(owned,target,rarity,delta){if(delta===void 0){delta=0.1;}
var added=0;var eps=0.000001;var left=added;var right=target+delta;var center=(left+right)/2;var result=mergeStackLevels(owned,center,rarity);var iterator=1;var prevResultDelta;var point={sigma:MAX_SAFE_INTEGER,center:center};while((result<target||(result-target)>delta)&&iterator<100){if(result<target){left=center;}
else{right=center;}
center=(left+right)*0.5;var prevResult=result;result=mergeStackLevels(owned,center,rarity);iterator++;var sigma=result-target;if((sigma>0)&&(sigma<point.sigma)){point.sigma=sigma;point.center=center;}
var resultDelta=Math.abs(prevResult-result);if(prevResultDelta&&resultDelta<prevResultDelta&&Math.abs(prevResult-result)<eps){return point.center;}
prevResultDelta=resultDelta;}
return center;}
function getPointsByCardPrice(token,priceForOne,pointsForOne){if(token>=priceForOne&&token%priceForOne==0){return pointsForOne*token/priceForOne;}
else{return 0;}}
function getLinearFunc(x1,y1,x2,y2){var a=(y2-y1)/(x2-x1);var b=-x1*(y2-y1)/(x2-x1)+y1;return function(x){return x*a+b;};}
function getLimitedLinearFunc(x1,y1,x2,y2,minLimit,maxLimit){var a=(y2-y1)/(x2-x1);var b=-x1*(y2-y1)/(x2-x1)+y1;return function(x){return Math.min(Math.max(x*a+b,minLimit),maxLimit);};}
function decomposeIntoSums(numbers,x){var sorted=numbers.slice().sort(function(a,b){return b-a;});var result={};var remaining=x;for(var _i=0,sorted_1=sorted;_i<sorted_1.length;_i++){var num=sorted_1[_i];if(remaining<=0)
break;if(num>x)
continue;var count=Math.floor(remaining/num);if(count>0){result[num]=count;remaining-=num*count;}}
return result;}