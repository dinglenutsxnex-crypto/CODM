function checkState(b,errorMessageTemplate,p1){if(errorMessageTemplate===void 0){errorMessageTemplate="";}
if(p1===void 0){p1=null;}
if(!b){errorMessageTemplate=errorMessageTemplate?errorMessageTemplate:"";p1=p1?p1:"";throw new Error("IllegalStateException: "+errorMessageTemplate+", obj="+p1);}}
function checkNotNull(obj,errorMessageTemplate,p1){if(errorMessageTemplate===void 0){errorMessageTemplate="";}
if(p1===void 0){p1=null;}
if(obj==null){throw new Error("NullPointerException: "+errorMessageTemplate+", obj="+p1);}
return obj;}
function checkArgument(expression,errorMessage){if(errorMessage===void 0){errorMessage=null;}
if(!expression){throw new Error("IllegalArgumentException: "+errorMessage);}}