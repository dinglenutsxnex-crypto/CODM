function getBattlesMap(){return convertMapForServer(BattlesMap,ServerBattle);}
function getBoostersMap(){return convertMapForServer(BoosterModelsMap,ServerBooster);}
function getBoardGamesMap(){return convertMapForServer(BoardGamesMap,ServerBoardGame);}
function getInAppsMap(){return convertMapForServer(InAppPurchaseMap,ServerInAppModel);}
function getPromosMap(){return convertMapForServer(PromoMap,ServerPromo);}
function getQuestsMap(){return convertMapForServer(QuestModelsMap,ServerQuests);}
function getAbPromosMap(abTag){if(abTag===null||ABPromos[abTag]===undefined||getABPromos(abTag)===null){return convertMapForServer(PromoMap,ServerPromo);}
return convertMapForServer(OrderMap.merge(PromoMap,ABPromoMap[abTag]),ServerPromo);}