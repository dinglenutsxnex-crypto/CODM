var CallBackAPIImplEnum={NODE_JS:"nodejs",SERVER:"server",CLIENT:"client"};var callBackAPI;function initCallBackAPI(implEnum,logger){switch(implEnum){case CallBackAPIImplEnum.SERVER:callBackAPI=new CallBackAPIServer(logger);break;case CallBackAPIImplEnum.CLIENT:callBackAPI=new CallBackAPIClient();break;default:callBackAPI=new CallBackAPINodeJS();}}
initCallBackAPI(CallBackAPIImplEnum.NODE_JS);var BattleGeneratorInstance=new BattleGenerator();var MissionGeneratorInstance=new MissionGenerator();var BrawlerGeneratorInstance=new BrawlerGenerator();var EventSurvivalGeneratorInstance=new EventSurvivalGenerator();var EventSurvivalGeneratorTemporaryInstance=new EventSurvivalAscencionGenerator();var EventAscensionGeneratorInstance=new EventAscensionGenerator();var SubscriptionGeneratorInstance=new SubscriptionGenerator();var EventMissionGeneratorInstance=new EventMissionGenerator();var InterchapterGeneratorInstance=new InterchapterGenerator();function generateBattle(battleID,playerInfo,seed,rawInventory,factionWarParameters,warriorID,enemyClanData){var inventory=InventoryConverter.getLongInterfaceOfInventory(rawInventory);RandomInstance.setSeed(seed);playerInfo.rawLevel=playerInfo.level;var _a=extractClassicForms(inventory),equipments=_a.equipments,perks=_a.perks;var battle=factionWarBattleArchetypesMap.get(battleID)?factionWarCombineBattleModel(FACTION.LEGION,FACTION.DYNASTY,factionWarParameters.dto,factionWarParameters.basePower):ClanOutpostBattlesIDs.indexOf(battleID)!==-1?prepareClanBattle(enemyClanData,RandomInstance,battleID):BattlesMap.checkedGet(battleID);var battleModel=new BattleGeneratorModel(battle,undefined,playerInfo,factionWarParameters?factionWarParameters.players:null);var gb;var type=battleModel.type;if(type==BattleType.MAIN){playerInfo.level=getLevelPropOfMain(battleID);}
else{playerInfo.level=verifyLevel(playerInfo.level,playerInfo.mainBattleID);}
var mainBattleID=playerInfo.mainBattleID;var mainFightIndex=playerInfo.mainFightIndex;var generator=BattleGeneratorInstance;playerInfo.faction=verifyFaction(playerInfo.level,playerInfo.faction);try{if(type==BattleType.SURVIVAL){gb=EventSurvivalGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else if(type==BattleType.SURVIVAL_ASCENSION||type==BattleType.ADV_GRIND){battleModel=battleModel.getVariant(playerInfo,battle);gb=EventSurvivalGeneratorTemporaryInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);calcRecommendedEventPower(gb,battle);}
else if(type==BattleType.EVENT_MISSION){battleModel=battleModel.getVariant(playerInfo,battle);gb=EventMissionGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else if(type==BattleType.BRAWLER){gb=BrawlerGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else if(type==BattleType.EVENT_ASCENSION){battleModel=battleModel.getVariant(playerInfo,battle);gb=EventAscensionGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else if(type==BattleType.SUBSCRIPTION){var wpSource=void 0;wpSource=mainBattleID&&mainBattleID!=-1&&(mainFightIndex!=null&&mainFightIndex!=undefined)?getWPSourceFromCompletedFight(mainBattleID,mainFightIndex):{};gb=SubscriptionGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory,wpSource,mainBattleID,warriorID);}
else if(type==BattleType.INTERCHAPTER||battle.MainWithoutEnemy){gb=InterchapterGeneratorInstance.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else{if(type==BattleType.LOCAL||type==BattleType.DOJO||type==BattleType.TEST){gb=generator.generateBattle(battleModel,playerInfo,RandomInstance,inventory);}
else{battleModel=battleModel.getVariant(playerInfo);if(type==BattleType.MAIN){mainBattleID=battleID;mainFightIndex=0;}
else if(type==BattleType.MISSION||type==BattleType.SIDE){generator=MissionGeneratorInstance;}
var wpSource=void 0,wpLevel=void 0;if(!!battle.WPLevel){wpLevel=battle.WPLevel;}
else{if(mainBattleID&&(mainFightIndex!=null&&mainFightIndex!=undefined)){if(type==BattleType.MISSION){wpSource=getWPSourceFromCompletedFight(mainBattleID,mainFightIndex);}
else{wpSource={};}}
wpLevel=wpSource?wpSource.Level:playerInfo.level;}
var zone=(battle.Chapters)?battle.Chapters[0].Zone:null;playerInfo.faction=verifyFaction(Math.min(playerInfo.level,wpLevel),playerInfo.faction,zone);gb=generator.generateBattle(battleModel,playerInfo,RandomInstance,inventory,wpSource,battle);}}
if(type==BattleType.MAIN||type==BattleType.MISSION||(type==BattleType.SIDE&&battle.Subtype!=BattleSubtype.FACTION_WARS_BATTLE)){calcRecommendedParams(gb,battle);}
return new GeneratedBattleResult(gb,RandomInstance.nextInt(RandomInstance.MAX_INTEGER()));}
catch(e){var playerVarsObj={};for(var key in playerInfo.playerVars){playerVarsObj[key]=playerInfo.playerVars[key];}
throw new Error(e.message+" (battleID: "+battleID+", playerLvl: "+playerInfo.level+", faction: "+playerInfo.faction+", seed: "+seed+", currentMainBattleId: "+playerInfo.mainBattleID+", currentMainFightIndex: "+playerInfo.mainFightIndex+", playerVars: "+JSON.stringify(playerVarsObj)+")\nOriginal error:\n"+e.stack+"\nCaught:");}}
function generateFreeLootReward(pInf,eventIDs){if(eventIDs===void 0){eventIDs=[];}
var override=StackLevelOverride.TUTORIAL;var stackLevels=getStackLevels(pInf,override);var level=pInf.level;var multipliers=new Currencies({COIN:calcCoinLevelInflation(1,level)});var adLootPreset=DefaultLootPresets.FreeLoot_1;var isChromopackLaunch=function(){return eventIDs.indexOf(25)!=-1;};var noActiveTokenEvents=function(){for(var _i=0,eventIDs_1=eventIDs;_i<eventIDs_1.length;_i++){var eID=eventIDs_1[_i];var event_1=GameEventMap.get(eID);if(event_1.currencies.indexOf(CurrenciesModels.TOKEN.ID)>-1)
return false;}
return true;};var isNY2021=eventIDs.indexOf(42)!=-1;var isNinjato=eventIDs.indexOf(67)!=-1;var isNY2024=eventIDs.indexOf(68)!=-1;switch(true){case(level<4):break;case(noActiveTokenEvents()):adLootPreset=DefaultLootPresets.FreeLootNoActiveEvent;break;case(isNinjato):adLootPreset=DefaultLootPresets.FreeLoot_Ninjato;break;case(isNY2024):adLootPreset=DefaultLootPresets.FreeLoot_NY2024;break;case(isChromopackLaunch()):adLootPreset=DefaultLootPresets.FreeLoot_ChromopackLaunch;break;case(level>=4&&level<=9):adLootPreset=isNY2021?DefaultLootPresets.FreeLoot_NY2021:DefaultLootPresets.FreeLoot_2;break;case(level>=10):adLootPreset=isNY2021?DefaultLootPresets.FreeLoot_NY2021:DefaultLootPresets.FreeLoot_3;break;}
return adLootPreset.generate(pInf,RandomInstance,stackLevels,multipliers,Inventory.emptyInventory,false);}
function getBonusCardCount(){return newAdRewardSystem?newAdRewardSystemCardCount:oldAdRewardSystemCardCount;}
function getStackLevelForRarity(pInf,rarity){return getStackLevels(pInf)[RARITY[rarity]];}
function calcVisibleEquipPower(equipArray,notRoundedToStep){if(notRoundedToStep===void 0){notRoundedToStep=false;}
var result=0;for(var i=0;i<equipArray.length;i++){if(ItemModelsMap.checkedGet(equipArray[i]["ModelID"]).Default!=1){var modelId=equipArray[i]["ModelID"];var sl=equipArray[i]["SL"];result+=getVisibleItemPower(sl,modelId,notRoundedToStep);}}
return result;}
function getItemsFromTactics(){var result=[];var tacticArray=getAllTacticStyles();if(!tacticArray.length){throw new Error("getItemsFromTactics: No Item with StandardStyle.");}
for(var i=0;i<tacticArray.length;i++){var tag=tacticArray[i];var suitableItemsID=[];for(var key in ItemModels){if(ItemModels[key].StandardStyle===1&&ItemModels[key].Style===tag){suitableItemsID.push(ItemModels[key].ID);}}
if(!suitableItemsID.length){throw new Error("getItemsFromTactics: No Item matching Style "+tag+".");}
var resultingItem=ItemModelsMap.getValues()[suitableItemsID[0]];var suitablePerks=[];for(var key in Supers){if(Supers[key].TacticStyle!=='NONE'&&(Supers[key].TargetTag===tag||(Array.isArray(Supers[key].TargetTag)&&Supers[key].TargetTag.indexOf(tag)!==-1))){var leveling=Supers[key].Leveling;for(var key_1 in leveling){for(var _i=0,_a=leveling[key_1].Effects;_i<_a.length;_i++){var effect=_a[_i];for(var i_1=0;i_1<effect.Tags.length;i_1++){if(suitablePerks.indexOf(effect.Tags[i_1])===-1){suitablePerks.push(effect.Tags[i_1]);}}}}}}
for(var i_2=0;i_2<suitablePerks.length;i_2++){if(resultingItem.Tags.indexOf(suitablePerks[i_2])===-1){resultingItem.Tags.push(suitablePerks[i_2]);}}
result.push(resultingItem);}
return result;}
function getRangedForTactics(){var rangedStyles=[];for(var key in ItemModels){if(ItemModels.hasOwnProperty(key)&&!ItemModels[key].NoShop&&ItemModels[key].ItemType==ITEMTYPE.RANGED&&ItemModels[key].Style&&rangedStyles.indexOf(ItemModels[key].Style)==-1){rangedStyles.push(ItemModels[key].Style);}}
var result=[];for(var i=0;i<rangedStyles.length;i++){var suitableModels=[];for(var key in ItemModels){if(ItemModels.hasOwnProperty(key)&&ItemModels[key].Style==rangedStyles[i]){suitableModels.push(ItemModels[key]);}}
result.push(suitableModels[Math.floor(Math.random()*suitableModels.length)]);}
return result;}
function getRandomFightLocationFromChapter(chapterID){var zone=getChapterZoneID(chapterID);var finalLocationsObj;switch(zone){case 1:finalLocationsObj=Chapter1Locations;break;case 2:finalLocationsObj=Chapter2Locations;break;case 3:finalLocationsObj=Chapter3Locations;break;case 4:finalLocationsObj=Chapter4Locations;break;case 5:finalLocationsObj=Chapter5Locations;break;case 6:finalLocationsObj=Chapter6Locations;break;case 7:finalLocationsObj=Chapter7_1Locations;break;case 8:finalLocationsObj=Chapter7_2Locations;break;case 9:finalLocationsObj=Chapter8Locations;break;case 10:finalLocationsObj=Chapter9Locations;break;case 11:finalLocationsObj=Chapter10Locations;break;case 12:finalLocationsObj=Chapter11Locations;break;case 13:finalLocationsObj=Chapter12Locations;break;case 14:finalLocationsObj=Chapter13Locations;break;default:finalLocationsObj=Chapter3Locations;}
var suitableLocations=[];for(var key in finalLocationsObj){if(finalLocationsObj.hasOwnProperty(key)&&finalLocationsObj[key]["BrawlerPlace"]==true){suitableLocations.push(finalLocationsObj[key]);}}
if(suitableLocations.length==0){throw"getRandomFightLocationFromChapter no suitable location for chapterID "+chapterID;}
var index=Math.floor(Math.random()*suitableLocations.length);return suitableLocations[index];}
function getTacticsMode(modeID){return TacticsModesMap.checkedGet(modeID);}
function getTacticsFromFight(battleID,fightIndex,roundIndex){if(fightIndex===void 0){fightIndex=0;}
if(roundIndex===void 0){roundIndex=null;}
var battle=BattlesMap.get(battleID);var warriorSettings;if(typeof battle.Fights==="number"){warriorSettings=battle.Warriors;}
else{warriorSettings=battle.Fights[fightIndex].Warriors;}
var aiMode=getWarriorField(warriorSettings,"AiMode",roundIndex);if(!aiMode){aiMode=AiMode.OLD_REGULAR_MODE;}
return getTacticsMode(aiMode);}
function findLastBattleIDfromZone(zoneID){if(!ZonesMap.getValues().hasOwnProperty(zoneID)){throw"findLastBattleIDfromZone no zone with ID "+zoneID;}
var bestID;var battles=BattlesMap.getValues();for(var key in battles){if(battles[key].Type==BattleType.MAIN){if(battles[key].Chapters[0].Zone.ID>zoneID){break;}
if(battles[key].Chapters[0].Zone.ID==zoneID){bestID=battles[key].ID;}}}
if(bestID){return bestID;}
else{throw"findLastBattleIDfromZone no last battle for zone ID "+zoneID;}}
function findLastBattleIDfromChapter(chapterID){if(!ChapterModelsMap.getValues().hasOwnProperty(chapterID)){throw"findLastBattleIDfromChapter no chapter with ID "+chapterID;}
var bestID;var battles=BattlesMap.getValues();for(var key in battles){if(battles[key].Type==BattleType.MAIN){if(battles[key].Chapters[0].ID>chapterID){break;}
if(battles[key].Chapters[0].ID==chapterID){bestID=battles[key].ID;}}}
if(bestID){return bestID;}
else{throw"findLastBattleIDfromChapter no last battle for chapter ID "+chapterID;}}
function getPromisedDanRewards(danID,level){var dan=RatingDansMap.checkedGet(danID);var coins=roundReward(calcBrawlerCoinZoneInflation(baseBrawlerCoins*dan.CoinMultiplier,getZoneByLevel(level)));var chestChances={COMMON_CHEST:null,RARE_CHEST:null,EPIC_CHEST:null,LEGENDARY_CHEST:null,EPIC_CHEST_NEW:null,LEGENDARY_CHEST_NEW:null,};switch(dan.ID){case 2:chestChances.EPIC_CHEST_NEW="x1.15";chestChances.LEGENDARY_CHEST_NEW="x1.1";break;case 3:chestChances.EPIC_CHEST_NEW="x1.3";chestChances.LEGENDARY_CHEST_NEW="x1.25";break;case 4:chestChances.EPIC_CHEST_NEW="x1.5";chestChances.LEGENDARY_CHEST_NEW="x1.4";break;case 5:chestChances.EPIC_CHEST_NEW="x1.75";chestChances.LEGENDARY_CHEST_NEW="x1.55";break;case 6:chestChances.EPIC_CHEST_NEW="x2";chestChances.LEGENDARY_CHEST_NEW="x1.75";break;case 7:chestChances.EPIC_CHEST_NEW="x2";chestChances.LEGENDARY_CHEST_NEW="x2";break;}
return{COINS:Number(coins),WINCOUNT:brawlerFightsToWinCoins,CHESTS:chestChances};}
function convertCurrency(currencyTypeFrom,currencyTypeTo,currencyAmountTo,playerLevel){checkCriticalUndef(CoinsPacksMap,"convertCurrency","CoinsPacksMap");if(currencyTypeFrom!=CurrenciesModels.BONUS.ID){throw new Error("convertCurrency: currencyTypeFrom must be BONUS");}
var fromValue,toValue;switch(currencyTypeTo){case CurrenciesModels.COIN.ID:var basePrice=calcBaseCoinPriceFromInflated(currencyAmountTo/coinBase,playerLevel);var benefit=0;for(var _i=0,_a=CoinsPacksMap.getKeys();_i<_a.length;_i++){var coinsPackID=_a[_i];var coinsPack=CoinsPacksMap.get(coinsPackID);if(coinsPack.quantity<=basePrice&&coinsPack.benefit>benefit){benefit=coinsPack.benefit;}}
var multiplier=1.5-benefit/100;fromValue=Math.ceil(basePrice/(multiplier*baseCoinForBonus));toValue=Math.ceil(calcCoinLevelInflation(fromValue*baseCoinForBonus*multiplier*coinBase,playerLevel));break;default:throw new Error("convertCurrency: currencyTypeTo must be COIN");}
var result={};result[currencyTypeFrom]=fromValue;result[currencyTypeTo]=toValue;return result;}
function generateShop(playerLevel,seed){throw"generateShop: this is used somewhere. please remove it.";}
function generateLootByTemplateNameForTest(templateName,seed){throw"generateLootByTemplateNameForTest: this is used somewhere. please remove it.";}
function generateLootByTemplate(template,seed){throw"generateLootByTemplate: this is used somewhere. please remove it.";}
function getSideArrayFromZoneID(zoneID){var result=[];var battles=BattlesMap.getValues();for(var key in battles){if(battles.hasOwnProperty(key)&&battles[key].Type==BattleType.SIDE&&getChapterZoneID(battles[key].Chapters[0].ID)==zoneID){result.push(battles[key].ID);}}
return result;}
function getBattlesArrayFromZoneID(zoneID,battleType){var result=[];var battles=BattlesMap.getValues();for(var key in battles){if(battles.hasOwnProperty(key)&&(battles[key].Type==battleType||(battleType==BattleType.MAIN&&battles[key].Type==BattleType.LOCAL&&battles[key].VisibleType==VisibleBattleType.MAIN_QUEST))&&getChapterZoneID(battles[key].Chapters[0].ID)==zoneID){result.push(battles[key].ID);}}
return result;}
var EquipmentsAndPerks=(function(){function EquipmentsAndPerks(equipments,perks){this.equipments=equipments;this.perks=perks;}
return EquipmentsAndPerks;}());function getRandomBattleIdForAnimators(){var listOfBattles=BattlesMap.getKeys();var possibleBattles=listOfBattles.filter(function(ID){var battle=BattlesMap.get(ID);return battle.Type===BattleType.TEST&&battle.ForAnimators;});return possibleBattles[Math.floor(Math.random()*possibleBattles.length)];}
function getSurvivalCurrencyLimit(level,battleID){var result=null;var limits=(_a={},_a[BattlesSurvival.Z1_Survival_Tuesday.ID]=new RoundedSurvivalCurrencies({SHADOW:400}).toMap(),_a[BattlesSurvival.Z1_Survival_Thursday.ID]=new RoundedSurvivalCurrencies({COIN:calcCoinZoneInflation(2000,getZoneByLevel(level))}).toMap(),_a[BattlesSurvival.Z2_Survival_Saturday.ID]=new Currencies({RARE_KEY:80}).toMap(),_a);if(limits[battleID]){result=limits[battleID];}
return result;var _a;}
function getFightLocation(level,chapterId,battleID,FCTN,warriorId,battleInfo){var zone=ChapterModelsMap.get(chapterId).Zone;var battle=BattlesMap.checkedGet(battleID);switch(battle.Type){case BattleType.SUBSCRIPTION:return getSubscriptionLocation(chapterId,warriorId);case BattleType.SURVIVAL:return getSurvivalLocation(zone.ID,level);case BattleType.BRAWLER:return getBrawlerLocation(zone.ID,level);default:return getDefaultBattleLocation(battle,battleInfo,chapterId,zone,FCTN);}
function getSubscriptionLocation(chapterId,warriorId){if(!warriorId&&CHECK_SUBS_LOCATIONS){throw"getFightLocation: warrior is "+warriorId+" in chapter "+chapterId;}
if(warriorId===0)
return Locations.Gorge_event;var warrior=SubscriptionWarriorsMap.get(warriorId);if(!warrior&&CHECK_SUBS_LOCATIONS){throw"getFightLocation: there are no warrior "+warriorId+" in map "+JSON.stringify(SubscriptionWarriorsMap.getKeys())+" in chapter "+chapterId;}
var mainChapterId=chapterId>=ChapterModels.Chapter3.ID?chapterId:chapterId<ChapterModels.Chapter2.ID?ChapterModels.Chapter1_0.ID:ChapterModels.Chapter2.ID;if(warrior&&warrior.Locations[mainChapterId]){return warrior.Locations[mainChapterId];}
if(mainChapterId>=ChapterModels.Chapter17.ID&&Locations.Void_Room_Red_ch17){return Locations.Void_Room_Red_ch17;}
if(CHECK_SUBS_LOCATIONS){throw"getFightLocation: no location available for warrior "+warriorId+" in chapter "+chapterId;}
return Locations.Dojo_Legion;}
function getSurvivalLocation(zoneId,level){var survivalMap=(_a={},_a[Zones.Zone2.ID]="Backstreets",_a[Zones.Zone3.ID]="Temple_ch3",_a[Zones.Zone4.ID]="Sphere_Temple_ch4",_a[Zones.Zone5.ID]="Port_ch5",_a[Zones.Zone6.ID]="Crypt_ch6",_a[Zones.Zone7.ID]="legion_future_ch_7_1",_a[Zones.Zone8.ID]="legion_future_ch_7_1",_a[Zones.Zone9.ID]="Dojo_Kibo_ch8",_a[Zones.Zone10.ID]="Port_ch9",_a[Zones.Zone11.ID]="glitch_clear_ch10",_a[Zones.Zone12.ID]="Market_ch11",_a[Zones.Zone13.ID]="Market_ch12",_a[Zones.Zone14.ID]="Market_ch13",_a[Zones.Zone15.ID]="legion_streets_ch14",_a[Zones.Zone16.ID]="legion_streets_ch15",_a[Zones.Zone17.ID]="Legion_streets_ch16",_a);if(zoneId===Zones.Zone18.ID){if(level<55&&Locations.SurvivalValleyNight){return Locations.SurvivalValleyNight;}
if(Locations.Void_Room_Red_ch17){return Locations.Void_Room_Red_ch17;}}
var locKey=survivalMap[zoneId];if(locKey&&Locations.hasOwnProperty(locKey)){return Locations[locKey];}
return Locations.Dojo_Legion;var _a;}
function getBrawlerLocation(zoneId,level){var locations;if(zoneId===1)
locations=Chapter1Locations;else if(zoneId===2)
locations=Chapter2Locations;else if(zoneId>2&&zoneId<=18)
locations=ColosseumLocations;else
return Locations.Dojo_Legion;var suitable=Object.keys(locations).map(function(key){return locations[key];}).filter(function(loc){return loc.BrawlerPlace;});if(!suitable.length){throw"getRandomFightLocationFromChapter no suitable location for Level "+level;}
var index=Math.floor(Math.random()*suitable.length);return suitable[index];}
function getDefaultBattleLocation(battle,battleInfo,chapterId,zone,FCTN){var resultLocation=null;if(battle.BattleVariantKey==="FCTN"&&FCTN&&battle.BattleVariants){resultLocation=battle.BattleVariants[FCTN-1].Location;}
if(!resultLocation&&battle.RandomLocations){var zoneName=ZonesMap.get(zone.ID).Name;var possible=battle.RandomLocations[zoneName];if(possible&&possible.length){resultLocation=possible[RandomInstance.nextInt(possible.length)];}}
if(!resultLocation&&battle.Location){if(battle.Location.OverridesByChapter&&chapterId){for(var _i=0,_a=battle.Location.OverridesByChapter;_i<_a.length;_i++){var override=_a[_i];if((!override.from||override.from<=chapterId)&&(!override.to||override.to>chapterId)){resultLocation=override.override;break;}}}
if(!resultLocation){if(!Array.isArray(battle.Location)){resultLocation=battle.Location;}
else if(battle.Location[battleInfo.fightIndex]){if(battle.Location[battleInfo.fightIndex][battleInfo.roundPlayed])
resultLocation=battle.Location[battleInfo.fightIndex][battleInfo.roundPlayed];else
resultLocation=battle.Location[battleInfo.fightIndex][0];}
else{resultLocation=battle.Location[0][0];}}}
if(resultLocation){var res=deepCopy(resultLocation);res.X=battle.LocationCoordinates?battle.LocationCoordinates.X:resultLocation.X;res.Y=battle.LocationCoordinates?battle.LocationCoordinates.Y:resultLocation.Y;return res;}
return Locations.Dojo_Legion;}}
function getSubsBattleDesc(warriorId){if(warriorId==0){return"fakeSubFightDesc";}
var desc="desc_";desc=!!SubscriptionWarriorsMap.get(warriorId)&&SubscriptionWarriorsMap.get(warriorId).hasOwnProperty("Warriors")&&SubscriptionWarriorsMap.get(warriorId).Warriors.length&&SubscriptionWarriorsMap.get(warriorId).Warriors[0].hasOwnProperty("Alias")?desc+SubscriptionWarriorsMap.get(warriorId).Warriors[0].Alias:desc+"battle_subscription";return desc;}
function countWeaponsByFaction(items,faction){var result=0;for(var key in items){var item=ItemModelsMap.get(key);if(item.ItemType==ITEMTYPE.WEAPON&&item.Faction==faction){result++;}}
return result;}
function refreshBattleRule(battleId,currentResistance){var result=null;var battle=BattlesMap.get(battleId);if(!!battle&&!!battle.VariableRules){var recommendedResistance=battle.RecommendedResistance?battle.RecommendedResistance:0;var variableRules=battle.VariableRules;result=variableRules;for(var fight in variableRules){if(variableRules.hasOwnProperty(fight)){for(var round in variableRules[fight]){if(variableRules[fight].hasOwnProperty(round)){for(var _i=0,_a=variableRules[fight][round];_i<_a.length;_i++){var rule_1=_a[_i];var ruleIndex=variableRules[fight][round].indexOf(rule_1);for(var _b=0,_c=rule_1.Attributes;_b<_c.length;_b++){var attr=_c[_b];var attrIndex=rule_1.Attributes.indexOf(attr);var value=attr.ChangeAttributeValueFunction(currentResistance,recommendedResistance);result[fight][round][ruleIndex]["Attributes"][attrIndex]["Value"]=convertRuleAttributeToInt(rule_1.RuleId,attr.AttrId,value);}}}}}}}
else{return null;}
return result;}
function convertRuleAttributeToInt(ruleID,attrID,value){if(VariableRulesRoundingSettings[ruleID]&&VariableRulesRoundingSettings[ruleID].indexOf(attrID)!=-1){return Math.round(value);}
else{return value;}}
function addStreakCheat(battleID,difficulty,currentStreak,fightResult){var battle=BattlesMap.get(battleID);if(!battle)
battle=factionWarBattleArchetypesMap.get(battleID);var result=currentStreak;var battleType=battle.Type;var delta=fightResult==FightResult.WIN?1:-1;if(delta*result<0){result=0;}
if((battleType==BattleType.MAIN||battleType==BattleType.SIDE)&&difficulty<=2){result+=delta;}
return result;}
function calcStreakCheatShift(battleID,streak,difficulty){var battle=BattlesMap.get(battleID);if(!battle)
battle=factionWarBattleArchetypesMap.get(battleID);var battleType=battle.Type;if((battleType==BattleType.MAIN||battleType==BattleType.SIDE)&&streak<=loserCheat.CounterStart&&difficulty<=2){var overStreak=Math.max(streak-loserCheat.CounterStart,loserCheat.CounterEnd-loserCheat.CounterStart);var stepPower=(loserCheat.WPshiftEnd-loserCheat.WPshiftStart)/(loserCheat.CounterEnd-loserCheat.CounterStart);return loserCheat.WPshiftStart+overStreak*stepPower;}
return 0;}
function getUITags(platform){var platformID=String(platform);if(uiTagsByPlatform.hasOwnProperty(platformID))
return uiTagsByPlatform[platformID];else
throw"Invalid platform "+platformID;}
function getAdBlockedAppID(platform){var platformID=String(platform);if(AdBlockedOnAppIDByPlatform.hasOwnProperty(platformID)){return AdBlockedOnAppIDByPlatform[platformID];}
else{return[];}}
function getCurrentOrderMapsSize(extended,onlyBattles){if(onlyBattles===void 0){onlyBattles=false;}
var result="---------- Order Maps ----------\n";if(!onlyBattles){result+="---- configs/scripts/analytics.ts:\n";result+=getStringOrderMapSize(LogLevelMap,"LogLevelMap",extended);}
result+="---- configs/scripts/battle-parameters.ts:\n";result+=getStringOrderMapSize(SubscriptionWarriorsMap,"SubscriptionWarriorsMap",extended);result+=getStringOrderMapSize(SurvivalWarriorMap,"SurvivalWarriorMap",extended);result+="---- configs/scripts/battles.ts:\n";result+=getStringOrderMapSize(BattlesMap,"BattlesMap",extended);if(!onlyBattles){result+="---- configs/scripts/boosters.ts:\n";result+=getStringOrderMapSize(BoosterModelsMap,"BoosterModelsMap",extended);result+="---- configs/scripts/chapters.ts:\n";result+=getStringOrderMapSize(ZonesMap,"ZonesMap",extended);result+=getStringOrderMapSize(ChapterModelsMap,"ChapterModelsMap",extended);result+="---- configs/scripts/chests.ts:\n";result+=getStringOrderMapSize(ChestModelsMap,"ChestModelsMap",extended);result+="---- configs/scripts/coins-packs.ts:\n";result+=getStringOrderMapSize(CoinsPacksMap,"CoinsPacksMap",extended);result+="---- configs/scripts/colors.ts:\n";result+=getStringOrderMapSize(ColorsMap,"ColorsMap",extended);result+="---- configs/scripts/follow-us.ts:\n";result+=getStringOrderMapSize(FollowUsMap,"FollowUsMap",extended);result+="---- configs/scripts/game-events.ts:\n";result+=getStringOrderMapSize(GameEventMap,"GameEventMap",extended);result+="---- configs/scripts/hairs.ts:\n";result+=getStringOrderMapSize(HairsMap,"HairsMap",extended);result+="---- configs/scripts/heads.ts:\n";result+=getStringOrderMapSize(HeadsMap,"HeadsMap",extended);result+="---- configs/scripts/inapps.ts:\n";result+=getStringOrderMapSize(GemPacksMap,"GemPacksMap",extended);result+=getStringOrderMapSize(SubscriptionPacksMap,"SubscriptionPacksMap",extended);result+=getStringOrderMapSize(PromoPacksMap,"PromoPacksMap",extended);result+="---- configs/scripts/itemmodels.ts:\n";result+=getStringOrderMapSize(ItemModelsMap,"ItemModelsMap",extended);result+="---- configs/scripts/lobby-music.ts:\n";result+=getStringOrderMapSize(MusicTracksMap,"MusicTracksMap",extended);result+="---- configs/scripts/offer-quest.ts:\n";result+=getStringOrderMapSize(OfferQuestMap,"OfferQuestMap",extended);result+="---- configs/scripts/perkmodels.ts:\n";result+=getStringOrderMapSize(PerkModelsMap,"PerkModelsMap",extended);result+="---- configs/scripts/promos.ts:\n";result+=getStringOrderMapSize(PromoMap,"PromoMap",extended);result+="---- configs/scripts/quests.ts:\n";result+=getStringOrderMapSize(EventQuestModelsMap,"EventQuestModelsMap",extended);result+=getStringOrderMapSize(QuestModelsMap,"QuestModelsMap",extended);result+="---- configs/scripts/rating-dans.ts:\n";result+=getStringOrderMapSize(RatingDansMap,"RatingDansMap",extended);result+="---- configs/scripts/rewardsmultipliers.ts:\n";result+=getStringOrderMapSize(RewardMultipliersMap,"RewardMultipliersMap",extended);result+="---- configs/scripts/roundrules.ts:\n";result+=getStringOrderMapSize(RoundRulesMap,"RoundRulesMap",extended);result+="---- configs/scripts/tactics.ts:\n";result+=getStringOrderMapSize(TacticsModesMap,"TacticsModesMap",extended);result+="---- configs/scripts/warrior-appearences.ts:\n";result+=getStringOrderMapSize(WarriorAppearencesMap,"WarriorAppearencesMap",extended);}
return result;}
function getStringOrderMapSize(map,mapName,extended){if(extended===void 0){extended=false;}
var result=mapName+": "+map.getKeys().length+"\n";if(extended){for(var _i=0,_a=map.getKeys();_i<_a.length;_i++){var key=_a[_i];var obj=map.get(key);if(obj){result+="\t"+key+": { ID: "+obj.ID+"; Name: "+obj.Name+" }\n";}
else{result+="\t"+key+": obj is undefined\n";}}}
return result;}
function getCurrentMapsSize(extended,onlyBattles){if(onlyBattles===void 0){onlyBattles=false;}
var result="---------- Maps ----------\n";result+="---- configs/scripts/battle-parameters.ts:\n";result+=getStringMapSize(Warriors,"Warriors",extended);result+=getStringMapSize(Locations,"Locations",extended);result+=getStringMapSize(WarriorBlockPresets,"WarriorBlockPresets",extended);result+=getStringMapSize(SurvivalWarriors,"SurvivalWarriors",extended);result+=getStringMapSize(SubscriptionWarriors,"SubscriptionWarriors",extended);result+="---- configs/scripts/battles.ts:\n";result+=getStringMapSize(Battles,"Battles",extended);if(!onlyBattles){result+="---- configs/scripts/boosters.ts:\n";result+=getStringMapSize(BoosterModels,"BoosterModels",extended);result+="---- configs/scripts/inapps.ts:\n";result+=getStringMapSize(InAppPurchases,"InAppPurchases",extended);result+="---- configs/scripts/offer-quest.ts:\n";result+=getStringMapSize(AllMarathons,"AllMarathons",extended);result+="---- configs/scripts/promos.ts:\n";result+=getStringMapSize(AllPromos,"AllPromos",extended);result+="---- configs/scripts/quests.ts:\n";result+=getStringMapSize(QuestModels,"QuestModels",extended);}
return result;}
function getStringMapSize(map,mapName,extended){if(extended===void 0){extended=false;}
var result=mapName+": "+Object.keys(map).length+"\n";if(extended){for(var key in map){var obj=map[key];if(obj){result+="\t"+key+": { ID: "+obj.ID+"; Name: "+obj.Name+" }\n";}
else{result+="\t"+key+": obj is undefined\n";}}}
return result;}
function getOneTimeRoundReward(battleId,pInf,bestRoundIdx,currentRoundIdx,seed){return{loot:new Loot(),newSeed:seed};}
function getRandomSkinIDForEnemyItem(itemID,playerSkinID){var item=ItemModelsMap.get(itemID);if(item.CollectionID){var collection=CollectionMap.get(item.CollectionID);return CollectionCalculate.getRandomSkinIDForCollection(collection,playerSkinID);}
else{return undefined;}}
function getRandomSkinIDsForEnemyEquipment(enemyEquipment,playerSkinId){var collection=CollectionCalculate.getCollectionByEquip(enemyEquipment);if(collection){return CollectionCalculate.getRandomSkinIDForCollection(collection,playerSkinId);}
else{var allCollectionsByEquipment=CollectionCalculate.getItemSetCollections(enemyEquipment);if(!allCollectionsByEquipment){return undefined;}
var availableRecolors=allCollectionsByEquipment.map(function(collection){return new BasicSet(collection.recolors);}).reduce(function(a,b){a.isect(b);return a;});if(playerSkinId&&availableRecolors.includes(playerSkinId)){availableRecolors.sub(playerSkinId);}
return availableRecolors.length?Number(availableRecolors.nextItem()):undefined;}}
function calcVisibleItemPower(stackLevel,modelID,precise){if(precise===void 0){precise=false;}
return getVisibleItemPower(stackLevel,modelID,precise);}
function getBattleChoiceWindowInfo(battleID){var battle=BattlesMap.get(battleID);return battle.ChoiceInfo;}
function getHash(buildId){if(hashes.hasOwnProperty(buildId))
return hashes[buildId];else
return[];}
function getLobbyPlateBackground(className,isOpen){return isOpen?openedPlatesBackgroundPaths[className]:closedPlatesBackgroundPaths[className];}
function getUmoneyPaymentMethods(version){if(version===null){return"bank_card";}
var parsedVersion=new Version(version);var baseVersion=new Version("1.38.2");return parsedVersion.lessThan(baseVersion)?"bank_card":null;}
function getApplicationSuffix(applicationId){switch(applicationId){case"com.wanda.sf3.wd":return"WD";case"com.hoolai.sf3.bytedance.gamecenter":return"BD";case"com.wanda.sf3.huawei":return"HW";case"com.wanda.sf3.nearme.gamecenter":return"OP";case"com.wanda.sf3.vivo":return"VI";case"com.wanda.sf3.honor":return"HN";case"com.hahd.aygd3.mi":return"XI";case"com.wanda.sf3.m4399":return"43";case"com.wanda.sf3.aligames":return"AG";case"com.tencent.tmgp.sf3":return"YB";case"com.wanda.sf3.bilibili":return"BL";case"com.wanda.sf3.yofun.mumu":return"YF";case"com.wanda.sf3.ld":return"ID";case"com.wanda.aygd3.meta":return"MT";case"com.wanda.sf3.xq":return"XQ";case"com.wanda.sf3.ios":return"AP";case"com.wanda.sf3.brand":return"BR";case"com.wanda.sf3.lb":return"LB";}
return"";}
function getAppLovinRetryDelay(attempt){return Math.min(60,Math.pow(2,Math.min(6,attempt)));}
function getAccountDeletionSettings(){return{isActive:IsUserDataDeletionThroughButtonActive,revertPeriod:UserDataDeletionRevertPeriod};}
function isEmailBindingEnabled(mainBattle){return!EmailBindingDisabled&&mainBattle>=EmailBindingEnableMainBattle;}
function migratePromoToLabel(userPromos){var PermanentPromoID=1010303112;var labelID=null;var duration;var deletedPromo=[];if(Object.keys(userPromos).indexOf(""+PermanentPromoID)!==-1){labelID=PremiumLabelType.BOARD_GAME_FREE_ROLL_PERMANENT;duration=-1;deletedPromo.push(PermanentPromoID);}
["1010303102","1010303104","1010303106","1010303108","1010303110"].map(function(ID){if(Object.keys(userPromos).indexOf(ID)!==-1){!labelID?labelID=PremiumLabelType.BOARD_GAME_FREE_ROLL_1:null;!duration?duration=Number(userPromos[ID]):null;deletedPromo.push(Number(ID));}});if(labelID===null)
return null;return{LabelID:labelID,Duration:duration,DeletedPromo:deletedPromo};}