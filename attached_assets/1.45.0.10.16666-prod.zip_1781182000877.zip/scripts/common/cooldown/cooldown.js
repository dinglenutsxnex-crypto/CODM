var Cooldown=(function(){function Cooldown(settings){if(settings.Label&&!Cooldown.checkLabelLength(settings.Label)){throw new Error("Length of Label must be shorter than "+Cooldown.LabelLimitLength+" characters.");}
for(var key in settings){this[key]=settings[key];}}
Cooldown.prototype.getSkipPrice=function(playerInfo,timeLeft){var _this=this;if(!this.Scale){return this.SkipPrice.toMap();}
if(this.Duration<timeLeft){timeLeft=this.Duration;}
checkForValidTime(this.Duration,timeLeft);var result=this.SkipPrice.apply(function(fullPrice){return Math.ceil(timeLeft*fullPrice/_this.Duration);});if(result["COIN"]){result["COIN"]=roundPrice(calcCoinLevelInflation(result["COIN"],playerInfo.level));}
return result.toMap();};Cooldown.checkLabelLength=function(label){return label.length<=Cooldown.LabelLimitLength;};Cooldown.LabelLimitLength=6;return Cooldown;}());