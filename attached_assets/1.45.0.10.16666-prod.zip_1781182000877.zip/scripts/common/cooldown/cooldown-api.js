function calcMissionCooldownSkipPrice(timeLeft){checkForValidTime(battleMissionCooldownTime,timeLeft);return battleMissionCooldownSkipPrice.apply(function(fullPrice){return Math.ceil(timeLeft*fullPrice/battleMissionCooldownTime);}).toMap();}
function calcMissionSkipPrice(battleID,timeLeft){var result=new RoundedCurrencies({BONUS:battleMissionCooldownTime*baseBonusHourMissionSkip/(1000*60*60)});if(timeLeft>battleMissionCooldownTime){timeLeft=battleMissionCooldownTime;}
checkForValidTime(battleMissionCooldownTime,timeLeft);return result.apply(function(fullPrice){return Math.ceil(timeLeft*fullPrice/battleMissionCooldownTime);}).toMap();}
function calcTimeForNextMissionUpdate(battleID,timeLeft){var pulse=battleMissionCooldownTime/baseBonusHourMissionSkip;if(timeLeft>battleMissionCooldownTime){timeLeft=battleMissionCooldownTime;}
checkForValidTime(battleMissionCooldownTime,timeLeft);return timeLeft%pulse;}
function checkForValidTime(totalCoolDown,timeLeft){if(!isSafeInteger(timeLeft)){throw new Error("Time left is not safe integer.");}
if(totalCoolDown<timeLeft){throw new Error("Time left exceeds total cooldown.");}
if(timeLeft<0){throw new Error("Time left can not be negative.");}}
function getBattleCooldownSkipPrice(battleID,timeLeft,rawPlayerInfo){var battle=BattlesMap.get(battleID);var playerInfo=new PlayerInfo(rawPlayerInfo,{level:getLevelByMainBattle(rawPlayerInfo.mainBattleID,rawPlayerInfo.level)});if(!battle.BattleCooldown||!battle.BattleCooldown.SkipPrice){return undefined;}
return battle.BattleCooldown.getSkipPrice(playerInfo,timeLeft);}