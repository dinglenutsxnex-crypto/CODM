var endgameZone=Zones.Zone18;var allChaptersArray=[];Object.keys(ChapterModels).forEach(function(x){if(ChapterModels[x].Zone!=Zones.Tutorial)
allChaptersArray.push(ChapterModels[x]);});var ZonesMap=createIDMap(Zones,"ZonesMap");var ChapterModelsMap=createIDMap(ChapterModels,"ChapterModelsMap");var ZonesBaseLevelsMap=getZonesBaseLevelsMap();function getZonesBaseLevelsMap(){checkCriticalUndef(ZonesMap,"getZonesBaseLevelsMap","ZonesMap");var result={};for(var _i=0,_a=ZonesMap.getKeys();_i<_a.length;_i++){var key=_a[_i];var zone=ZonesMap.get(key);if(!zone.Locked){result[zone.MinLevel]=zone;}}
return result;}
function getChapterZoneID(chapterID){var result=ChapterModelsMap.checkedGet(chapterID);if(result&&result.hasOwnProperty("Zone")){return result.Zone.ID;}
throw"No zone binding to chapterID: "+chapterID;}
function getChapterImage(chapterID){var result=ChapterModelsMap.checkedGet(chapterID);if(result&&result.hasOwnProperty("Image")){return result.Image;}
throw"No zone binding to chapterID: "+chapterID;}
function getChapterZoneValue(chapterID){var result=ChapterModelsMap.checkedGet(chapterID);if(result&&result.hasOwnProperty("Zone")){return result.Zone.Value;}
throw"No zone binding to chapterID: "+chapterID;}
function getChapterByZone(zoneID){for(var chapterID in ChapterModelsMap.getValues()){var chapter=ChapterModelsMap.checkedGet(chapterID);if(chapter&&chapter.Zone.ID==zoneID){return chapter;}}
throw"No chapter binding to zoneID: "+zoneID;}
function getZoneByLevel(level){for(var _i=0,_a=ZonesMap.getKeys();_i<_a.length;_i++){var zoneID=_a[_i];var zone=ZonesMap.get(zoneID);if(!zone.Locked&&level<=zone.MaxLevel){return zone;}}
return endgameZone;}
function verifyFaction(level,faction,zone){if(level<=Zones.Zone3.MaxLevel){var zone_1=getZoneByLevel(level);return zone_1.Factions[0];}
else{if(!faction||!FACTION[faction]){return FACTION.HERALDS;}
else{if(zone&&zone.Factions.indexOf(faction)==-1){return zone.Factions[0];}
return faction;}}}
function getLevelPropOfMain(mainID){var battle=BattlesMap.get(mainID);if(!!battle){var battleLevel=battle.Level;if(!battleLevel){var battleVariants=battle.hasOwnProperty("BattleVariants")?battle.BattleVariants:[];for(var _i=0,battleVariants_1=battleVariants;_i<battleVariants_1.length;_i++){var variant=battleVariants_1[_i];if(variant.Level){battleLevel=variant.Level;break;}}}
return!!battleLevel?battleLevel:null;}
else{return null;}}
function verifyLevel(level,currentMainID){if(currentMainID==0){return level;}
if(currentMainID==1670){return 34;}
else if(currentMainID!=-1){var battleLevel=getLevelPropOfMain(currentMainID);if(!battleLevel){return 1;}
var battle=BattlesMap.get(currentMainID);var parentLevel=void 0;var parentBattle=battle.hasOwnProperty("Parent")?BattlesMap.get(battle.Parent.BattleId):undefined;if(!!parentBattle){parentLevel=getLevelPropOfMain(parentBattle.ID);battleLevel=!!parentLevel?parentLevel:battleLevel;}
var battleZone=battle.Chapters[0].Zone;if(battleLevel>battleZone.MaxLevel){battleLevel=battleZone.MaxLevel;}
if(battleLevel!=level){}
return battleLevel;}
return 1;}
function getAllowedFaction(pInf){var zone=getZoneByLevel(pInf.level);if(zone&&zone.Factions.indexOf(pInf.faction)==-1){return verifyFaction(pInf.level,pInf.faction);}
else{return pInf.faction;}}