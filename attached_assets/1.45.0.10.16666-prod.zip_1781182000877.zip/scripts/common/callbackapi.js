function flushLogBuffer(callBackImpl){if(logBuffer.length>0){for(var i=0;i<logBuffer.length;i++){callBackImpl.log(logBuffer[i]);}
logBuffer=[];}}
var CallBackAPINodeJS=(function(){function CallBackAPINodeJS(){}
CallBackAPINodeJS.prototype.log=function(log){if(!LOG_RANDOM)
return;};CallBackAPINodeJS.prototype.flush=function(){if(!LOG_RANDOM)
return;flushLogBuffer(this);};return CallBackAPINodeJS;}());var clientLog=function(log){};var clientFlush=function(){};var CallBackAPIClient=(function(){function CallBackAPIClient(){}
CallBackAPIClient.prototype.log=function(log){if(!LOG_RANDOM)
return;clientLog(log);};CallBackAPIClient.prototype.flush=function(){if(!LOG_RANDOM)
return;flushLogBuffer(this);clientFlush();};return CallBackAPIClient;}());var CallBackAPIServer=(function(){function CallBackAPIServer(logger){this.serverCallBackAPI=logger;}
CallBackAPIServer.prototype.log=function(log){if(!LOG_RANDOM)
return;this.serverCallBackAPI.addLog(log);};CallBackAPIServer.prototype.flush=function(){if(!LOG_RANDOM)
return;flushLogBuffer(this);this.serverCallBackAPI.flushLog();};return CallBackAPIServer;}());function enableLogging(enable){LOG_RANDOM=enable;}