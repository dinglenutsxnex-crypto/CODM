var Group4Tip17MarathonQuests={SPRINT_GROUP4_TIP17_LAUNCH_1_ALL:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+1)*10+1),Alias:"questShowMore_completeMarathons_common",Image:"",questPoints:{legion_marathon:{points:150,alias:'questShowMore_completeMarathons_styles_legion_marathon'},dynasty_marathon:{points:150,alias:'questShowMore_completeMarathons_styles_dynasty_marathon'},heralds_marathon:{points:150,alias:'questShowMore_completeMarathons_styles_heralds_marathon'},},Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_ALL,EventType:QuestEventType.ON_QUEST_INCREMENT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["quest_id"]==this.ID)
return 0;var attachedQuests=[((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+2)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+3)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+4)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+5)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+5)*10+2),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+6)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+6)*10+2),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+7)*10+1),((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+7)*10+2),];if(attachedQuests.indexOf(eventParameters["quest_id"])!=-1&&eventParameters["delta_progress"]!=0&&eventParameters["marathon_progress"]<eventParameters["max_progress"]&&eventParameters["marathon_progress"]+eventParameters["delta_progress"]>=eventParameters["max_progress"]){return 150;}
return 0;}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION_KNUCKLES:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+2)*10+1),Alias:"questShowMore_fightWin_legion_GIANTSWORD_02_common",Image:"",questPoints:{duelWin_legion:{points:2,alias:'questShowMore_duelWin_legion'},missionWin_legion:{points:2,alias:'questShowMore_missionWin_legion'},main_legion:{points:75,alias:'questShowMore_main_legion'},subBossWin_legion:{points:200,alias:'questShowMore_subBossWin_legion'},duelWin_legion_KNUCKLES_01:{points:3,alias:'questShowMore_duelWin_legion_GIANTSWORD_02'},missionWin_legion_KNUCKLES_01:{points:3,alias:'questShowMore_missionWin_legion_GIANTSWORD_02'},main_legion_KNUCKLES_01:{points:75,alias:'questShowMore_main_legion_GIANTSWORD_02'},subBossWin_legion_KNUCKLES_01:{points:200,alias:'questShowMore_subBossWin_legion_GIANTSWORD_02'},},Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION,EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet1=[CollectionModels.L_LEGENDARY_WPN_GIANTSWORD_02,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.LEGION&&ItemModelsMap.get((setMap.WPN)).Tags.indexOf("FISTS")==-1){weapon=true;}
fullSet1.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.MAIN:{if(equip)
return 150;if(weapon)
return 75;}
case BattleType.SIDE:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.MISSION:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.BRAWLER:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY_SABERS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+3)*10+1),Alias:"questShowMore_fightWin_dynasty_DUAL_CLEAVERS_01_01_common",Image:"",questPoints:{duelWin_dynasty:{points:2,alias:'questShowMore_duelWin_dynasty'},missionWin_dynasty:{points:2,alias:'questShowMore_missionWin_dynasty'},main_dynasty:{points:75,alias:'questShowMore_main_dynasty'},subBossWin_dynasty:{points:200,alias:'questShowMore_subBossWin_dynasty'},duelWin_dynasty_SABERS_01_04:{points:3,alias:'questShowMore_duelWin_dynasty_DUAL_CLEAVERS_01_01'},missionWin_dynasty_SABERS_01_04:{points:3,alias:'questShowMore_missionWin_dynasty_DUAL_CLEAVERS_01_01'},main_dynasty_SABERS_01_04:{points:75,alias:'questShowMore_main_dynasty_DUAL_CLEAVERS_01_01'},subBossWin_dynasty_SABERS_01_04:{points:200,alias:'questShowMore_subBossWin_dynasty_DUAL_CLEAVERS_01_01'},},Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY,EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet2=[CollectionModels.D_LEGENDARY_WPN_DUAL_CLEAVERS_01_01,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.DYNASTY){weapon=true;}
fullSet2.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.MAIN:{if(equip)
return 150;if(weapon)
return 75;}
case BattleType.SIDE:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.MISSION:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.BRAWLER:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS_KATANA_SCABBARD:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+4)*10+1),Alias:"questShowMore_fightWin_heralds_NINJATO_04_common",Image:"",Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS,questPoints:{duelWin_heralds:{points:2,alias:'questShowMore_duelWin_heralds'},missionWin_heralds:{points:2,alias:'questShowMore_missionWin_heralds'},main_heralds:{points:75,alias:'questShowMore_main_heralds'},subBossWin_heralds:{points:200,alias:'questShowMore_subBossWin_heralds'},duelWin_heralds_KATANA_SCABBARD_01_04:{points:3,alias:'questShowMore_duelWin_heralds_NINJATO_04'},missionWin_heralds_KATANA_SCABBARD_01_04:{points:3,alias:'questShowMore_missionWin_heralds_NINJATO_04'},main_heralds_KATANA_SCABBARD_01_04:{points:75,alias:'questShowMore_main_heralds_NINJATO_04'},subBossWin_heralds_KATANA_SCABBARD_01_04:{points:200,alias:'questShowMore_subBossWin_heralds_NINJATO_04'},},EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet3=[CollectionModels.H_LEGENDARY_WPN_NINJATO_04,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.HERALDS){weapon=true;}
fullSet3.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.MAIN:{if(equip)
return 150;if(weapon)
return 75;}
case BattleType.SIDE:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.MISSION:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.BRAWLER:{if(equip)
return 5;if(weapon)
return 2;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION_KNUCKLES_MARKUS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+5)*10+1),Alias:"questShowMore_fightWin_legion_GIANTSWORD_02_common",Image:"",questPoints:{duelWin_legion:{points:5,alias:'questShowMore_duelWin_legion'},subBossWin_legion:{points:200,alias:'questShowMore_subBossWin_legion'},duelWin_legion_KNUCKLES_01:{points:15,alias:'questShowMore_duelWin_legion_GIANTSWORD_02'},subBossWin_legion_KNUCKLES_01:{points:200,alias:'questShowMore_subBossWin_legion_GIANTSWORD_02'},},Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION_MARKUS,EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet1=[CollectionModels.L_LEGENDARY_WPN_GIANTSWORD_02,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.LEGION&&ItemModelsMap.get((setMap.WPN)).Tags.indexOf("FISTS")==-1){weapon=true;}
fullSet1.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.BRAWLER:{if(equip)
return 20;if(weapon)
return 5;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION_RAIDS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+5)*10+2),Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_LEGION_MARKUS,Alias:"questShowMore_openBooster_common",Description:"",Image:"",questPoints:{epic:{points:40,alias:'questShowMore_openBooster_epic'},legendary:{points:200,alias:'questShowMore_openBooster_legendary'},},showMaxProgress:false,EventType:QuestEventType.ON_BOOSTER_OPEN,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){var points=0;var booster=BoosterModelsMap.get(eventParameters["booster_id"]);var rarityPoints=(_a={},_a[RARITY.EPIC]=40,_a[RARITY.LEGENDARY]=200,_a);if(rarityPoints.hasOwnProperty(booster.Type)){points=points+rarityPoints[booster.Type];}
return points;var _a;}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY_SABERS_MARKUS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+6)*10+1),Alias:"questShowMore_fightWin_dynasty_DUAL_CLEAVERS_01_01_common",Image:"",questPoints:{duelWin_dynasty:{points:5,alias:'questShowMore_duelWin_dynasty'},subBossWin_dynasty:{points:200,alias:'questShowMore_subBossWin_dynasty'},duelWin_dynasty_SABERS_01_04:{points:15,alias:'questShowMore_duelWin_dynasty_DUAL_CLEAVERS_01_01'},subBossWin_dynasty_SABERS_01_04:{points:200,alias:'questShowMore_subBossWin_dynasty_DUAL_CLEAVERS_01_01'},},Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY_MARKUS,EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet2=[CollectionModels.D_LEGENDARY_WPN_DUAL_CLEAVERS_01_01,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.DYNASTY){weapon=true;}
fullSet2.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.BRAWLER:{if(equip)
return 20;if(weapon)
return 5;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY_RAIDS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+6)*10+2),Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_DYNASTY_MARKUS,Alias:"questShowMore_questChestOpen_common",Image:"",questPoints:{questChestOpen_epic:{points:10,alias:'questShowMore_questChestOpen_epic'},questChestOpen_legendary:{points:75,alias:'questShowMore_questChestOpen_legendary'},},showMaxProgress:false,EventType:QuestEventType.ON_CHEST_OPEN,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){var chest=ChestModelsMap.get(eventParameters["chest_id"]);if(!chest.IsQuestChest){return 0;}
var points=(_a={},_a[QuestChests.QUEST_EPIC_CHEST.ID]=10,_a[QuestChests.QUEST_LEGENDARY_CHEST.ID]=75,_a);if(points.hasOwnProperty(chest.ID)){return points[chest.ID];}
return 0;var _a;}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS_KATANA_SCABBARD_MARKUS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+7)*10+1),Alias:"questShowMore_fightWin_heralds_NINJATO_04_common",Image:"",Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS_MARKUS,questPoints:{duelWin_heralds:{points:5,alias:'questShowMore_duelWin_heralds'},subBossWin_heralds:{points:200,alias:'questShowMore_subBossWin_heralds'},duelWin_heralds_KATANA_SCABBARD_01_04:{points:15,alias:'questShowMore_duelWin_heralds_NINJATO_04'},subBossWin_heralds_KATANA_SCABBARD_01_04:{points:200,alias:'questShowMore_subBossWin_heralds_NINJATO_04'},},EventType:QuestEventType.AFTER_FIGHT,showMaxProgress:false,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var battle=BattlesMap.checkedGet(eventParameters["battle_id"]);var equip=false;var weapon=false;var setMap={WPN:eventParameters["weapon_id"],HLM:eventParameters["helmet_id"],ARM:eventParameters["armor_id"],RND:eventParameters["ranged_id"]};var fullSet3=[CollectionModels.H_LEGENDARY_WPN_NINJATO_04,];if(ItemModelsMap.get(setMap.WPN).Faction==FACTION.HERALDS){weapon=true;}
fullSet3.forEach(function(value){if(value.bucket.isCollectedAtLeastOneItemOfAllTypes([setMap.WPN,setMap.ARM,setMap.HLM,setMap.RND])){equip=true;}});switch(battle.Type){case BattleType.BRAWLER:{if(equip)
return 20;if(weapon)
return 5;}
case BattleType.SUBSCRIPTION:{if(equip)
return 400;if(weapon)
return 200;}
default:return 0;}}}),SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS_RAIDS:new PromoQuestModel({ID:((promoSchedule.GROUP4_TIP17.MarathonlaunchNumber*10+7)*10+2),Parent:Group4Tip17OfferQuests.SPRINT_GROUP4_TIP17_LAUNCH_1_DIFF_STYLES_HERALDS_MARKUS,Alias:"questShowMore_openEventBooster_common",Image:"",questPoints:{rewardCommon:{points:30,alias:'questShowMore_openEventBooster_standart'},rewardPrem:{points:150,alias:'questShowMore_openEventBooster_premium'},},showMaxProgress:false,EventType:QuestEventType.ON_BOOSTER_OPEN,generate:function(quest,level,rnd){quest.max_progress=this.Parent!=null?this.Parent.MaxProgress:0;},update:function(questAttributes,eventParameters){var booster=BoosterModelsMap.get(eventParameters["booster_id"]);if(booster){if(booster.Type==BoosterType.UNIQUE_BOOSTER&&booster.EventRarity!=undefined&&booster.EventID==75){if(booster.EventRarity==RARITY.RARE){return 30;}
if(booster.EventRarity==RARITY.EPIC){return 150;}}}
return 0;}}),};createInstances(PromoQuestModels,Group4Tip17MarathonQuests,function(settings){return settings;});