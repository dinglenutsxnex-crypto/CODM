var __extends=(this&&this.__extends)||(function(){var extendStatics=Object.setPrototypeOf||({__proto__:[]}instanceof Array&&function(d,b){d.__proto__=b;})||function(d,b){for(var p in b)if(b.hasOwnProperty(p))d[p]=b[p];};return function(d,b){extendStatics(d,b);function __(){this.constructor=d;}
d.prototype=b===null?Object.create(b):(__.prototype=b.prototype,new __());};})();var Retexture=(function(_super){__extends(Retexture,_super);function Retexture(settings){var _this=_super.call(this,settings)||this;_this.CollectionID=settings.CollectionID;_this.Model=settings.Model;_this.Image=settings.Image;if(settings.KeepDefaultGlowColor){_this.KeepDefaultGlowColor=settings.KeepDefaultGlowColor;}
_this.SetIcon=settings.SetIcon;_this.IconColor=settings.IconColor;_this.Alias=settings.Alias;_this.SetAlias=settings.SetAlias;_this.ChromopackBack=settings.ChromopackBack;_this.ChromopackIcon=settings.ChromopackIcon;_this.makeChromopacks(settings.AvailableColors);if(settings.SortingOrder){_this.SortingOrder=settings.SortingOrder;}
if(settings.MaskColorChannels){_this.MaskColorChannels=settings.MaskColorChannels;}
if(settings.OfferView2d){_this.OfferView2d=settings.OfferView2d;}
return _this;}
Retexture.prototype.setCollectionAlias=function(CollectionAlias){if(this.SetAlias){return;}
else if(CollectionAlias){this.SetAlias=CollectionAlias;}
else{throw new Error("Retexture with ID: "+this.ID+" has no Collection Alias and SetAlias fields.");}};Retexture.prototype.makeChromopacks=function(available){var _this=this;this.ChromopackIDs=[];available.forEach(function(x,i){if(x){var chromopack=new Chromopack(_this,x,i+1);_this.ChromopackIDs.push(chromopack.ID);if(x.Default){if(x.ID<1||x.ID>9999){throw new Error("SkinBoosters "+_this.ID+": default chromopack ID ("+x.ID+") must be 1-9999");}
_this.DefaultChromopack=x.ID;}
ChromopackModels[chromopack.ID]=chromopack;}});if(!this.DefaultChromopack){throw new Error('Default Chromopack is not defined!');}};return Retexture;}(Skin));