var __extends=(this&&this.__extends)||(function(){var extendStatics=Object.setPrototypeOf||({__proto__:[]}instanceof Array&&function(d,b){d.__proto__=b;})||function(d,b){for(var p in b)if(b.hasOwnProperty(p))d[p]=b[p];};return function(d,b){extendStatics(d,b);function __(){this.constructor=d;}
d.prototype=b===null?Object.create(b):(__.prototype=b.prototype,new __());};})();var Recolor=(function(_super){__extends(Recolor,_super);function Recolor(settings){var _this=_super.call(this,settings)||this;_this.DyeId=settings.DyeId;if(settings.Alias){_this.Alias=settings.Alias;}
else{_this.Alias=_this.DyeId?DyeModelsMap.get(_this.DyeId).Alias:"";}
_this.Color=settings.Color;if(settings.ColorMark){_this.ColorMark=settings.ColorMark;}
_this.Image=recolorImages[settings.Rarity];return _this;}
Recolor.prototype.canBeAppliedToItem=function(itemID){var item=ItemModelsMap.get(itemID);return!!item.CollectionID&&CollectionMap.get(item.CollectionID);};return Recolor;}(Skin));