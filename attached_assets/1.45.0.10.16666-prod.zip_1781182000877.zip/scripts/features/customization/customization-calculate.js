var CustomizationCalculate;(function(CustomizationCalculate){function compensation(settings,defaultCompensation){var compensation=new Loot();if(!settings){compensation.setCurrencies(defaultCompensation);return compensation;}
if(settings.Currencies){compensation.setCurrencies(settings.Currencies);}
else if(settings.Dyes){compensation.setDyes(settings.Dyes);}
return compensation;}
CustomizationCalculate.compensation=compensation;})(CustomizationCalculate||(CustomizationCalculate={}));