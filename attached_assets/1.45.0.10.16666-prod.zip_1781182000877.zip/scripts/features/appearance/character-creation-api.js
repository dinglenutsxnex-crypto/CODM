function createCharacterGetColor(){var result=[];for(var key in Colors){if(Colors[key].CharCreation){result.push(Colors[key].ID);}}
return result;}
function createCharacterGetHair(){var result=[];for(var key in ItemModels){if(ItemModels[key].CharCreation){result.push(ItemModels[key]);}}
return result;}
function createCharacterWA(){var result=[];for(var key in WarriorAppearences){if(WarriorAppearences[key].CharCreation){result.push(WarriorAppearences[key]);}}
return result;}
var createCharacterColorHairValue=createCharacterGetColor();