var WarriorAppearance=(function(){function WarriorAppearance(settings){for(var key in settings){this[key]=settings[key];}}
return WarriorAppearance;}());