function convertWarriorBlockToRulesClassic(warriorBlock,rounds,fightLength){if(rounds===void 0){rounds=[];}
if(fightLength===void 0){fightLength=1;}
var resultRules=[];if(warriorBlock.Alias){resultRules.push({RuleBlocks:[rule(RoundRules.SetAlias,RRA.Alias,warriorBlock.Alias)],});}
if(warriorBlock.Gender){resultRules.push({RuleBlocks:[rule(RoundRules.SetGender,RRA.Gender,warriorBlock.Gender,RRA.ApplyTo,PLAYER)],});}
if(warriorBlock.Appearance){resultRules.push({RuleBlocks:[rule(RoundRules.SetAppearance,RRA.ID,warriorBlock.Appearance.ID)],});}
if(warriorBlock.Equipments){for(var _i=0,_a=warriorBlock.Equipments;_i<_a.length;_i++){var equipment=_a[_i];resultRules.push({RuleBlocks:[rule(RoundRules.GiveItem,RRA.ID,equipment.ID)],});}}
if(warriorBlock.Tags){for(var _b=0,_c=warriorBlock.Tags;_b<_c.length;_b++){var tag=_c[_b];resultRules.push({RuleBlocks:[rule(RoundRules.GiveTag,RRA.Tag,tag,RRA.ApplyTo,PLAYER)],});}}
if(warriorBlock.Rules){resultRules=resultRules.concat(warriorBlock.Rules);}
var adjustedRules=[];if(rounds.length>1){var roundRules=[];for(var _d=0,resultRules_1=resultRules;_d<resultRules_1.length;_d++){var ruleBlock=resultRules_1[_d];for(var i=1;i<=(fightLength!==-1?fightLength:rounds[rounds.length-1]);i++){if(rounds.indexOf(i)!==-1){roundRules.push.apply(roundRules,ruleBlock.RuleBlocks);}
else{roundRules.push(rule(RoundRules.ApplyFactor,RRA.WeaponDamage,1));}}
adjustedRules.push({RuleBlocks:roundRules});roundRules=[];}}
else{adjustedRules=resultRules;}
return adjustedRules;}