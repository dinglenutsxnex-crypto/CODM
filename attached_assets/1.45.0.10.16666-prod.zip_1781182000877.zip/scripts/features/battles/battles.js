var __assign=(this&&this.__assign)||Object.assign||function(t){for(var s,i=1,n=arguments.length;i<n;i++){s=arguments[i];for(var p in s)if(Object.prototype.hasOwnProperty.call(s,p))
t[p]=s[p];}
return t;};if(!Helper.isEmpty(BattlesChapter2Main)&&QA_TOOLS&&QA_LOCK_CUSTOMISATION_TUTORIAL){BattlesChapter2Main.Z2_MQ_4_1.CustomLootSettings.DyesSlots=[];}
var MainBattles=__assign({},BattlesChapter1Main,BattlesChapter2Main,BattlesChapter3Main,BattlesChapter4Main,BattlesChapter5Main,BattlesChapter6Main,BattlesChapter7_1Main,BattlesChapter7_2Main,BattlesChapter8Main,BattlesChapter9Main,BattlesChapter10Main,BattlesChapter11Main,BattlesChapter12Main,BattlesChapter13Main,BattlesChapter14Main,BattlesChapter15Main,BattlesChapter16Main,BattlesChapter17Main);var MissionBattles=__assign({},BattlesChapter1Missions,BattlesChapter2Missions,BattlesChapter3Missions,BattlesChapter4Missions,BattlesChapter5Missions,BattlesChapter6Missions,BattlesChapter7_1Missions,BattlesChapter7_2Missions);var SideBattles=__assign({},BattlesChapter1Side,BattlesChapter2Side,BattlesChapter3Side,BattlesChapter4Side,BattlesChapter5Side,BattlesChapter6Side,BattlesChapter7_1Side,BattlesChapter7_2Side);var Battles=__assign({},MainBattles,MissionBattles,SideBattles,BattlesDojos,BattlesTutorials,BattlesBrawler,BattlesSurvival,BattlesSubscription,BattlesEvents,BattlesTest,RaidBattles,AdventureBattles,GrindBattles);var BattlesMap=createIDMap(Battles,"BattlesMap");function setMissionDifficulty(battle,difficulty){var modifier=0;if(battle.OverwrittenFightDifficulty!=undefined){if(typeof battle.OverwrittenFightDifficulty!=="number"&&Number(battle.OverwrittenFightDifficulty)){modifier=Number(battle.OverwrittenFightDifficulty);}}
battle.Difficulty=difficulty-modifier;}
function setBattleDefaultLoot(battle,battleType,zone,faction){var lootSettings="Empty";if(battle.hasOwnProperty("DefaultLootSettings")){lootSettings=battle.DefaultLootSettings;}
else{if(battleType==BattleType.MISSION||battleType==BattleType.SIDE){lootSettings="Mission";}
battle.DefaultLootSettings=lootSettings;}
battle.DefaultLootPreset=DefaultLootPresets[lootSettings];var rewardIcons=battle.DefaultLootPreset.getMinimumRaritiesTypes();if(battle.hasOwnProperty("CustomLootSettings")){battle.CustomLootPreset=createLootPreset(battle.CustomLootSettings);var customRewardIcons=battle.CustomLootPreset.getMinimumRaritiesTypes();rewardIcons=extend(rewardIcons,customRewardIcons);}
battle.RewardIcon=rewardIcons;if(battle.Fights){for(var _i=0,_a=battle.Fights;_i<_a.length;_i++){var fight=_a[_i];setBattleDefaultLoot(fight,battleType,zone,faction);}
battle.FightCount=battle.Fights.length;}
else{battle.FightCount=1;}}
function setFeatureUnlocks(){for(var unlocker in featureLockers){var unlockedFeatures=featureLockers[unlocker].Features;var mask=bitwiseORArray(unlockedFeatures);var battleID=featureLockers[unlocker].ID;var battleValue=BattlesMap.get(battleID);if(!battleValue)
continue;var unlockFeatures={Mask:0,Features:[]};unlockFeatures.Mask=mask;unlockFeatures.Features=[];for(var i in unlockedFeatures){var feature=unlockedFeatures[i];var level=BattlesMap.get(battleID).Level;var behaviour=featureUnlockBehaviourMap[GameFeature[feature]];var alias=featureUnlockBehaviourAlias[FeatureUnlockBehaviours[behaviour]];unlockFeatures.Features.push({Mask:feature,Behaviour:behaviour,Alias:alias,Level:level});}
featureLockers[unlocker].ClientData=unlockFeatures;}}
function setAllMainWPshift(battlesMap,mainArray){var fShift=maximumWPshift;var arrL=mainArray.length;for(var i=0;i<arrL;i++){var shift=fShift/arrL*Math.pow((Math.pow(arrL,(1/arrL))),i);var battle=battlesMap.get(mainArray[i]);var fights=[];if(battle.BattleVariants){for(var _i=0,_a=battle.BattleVariants;_i<_a.length;_i++){var bbf=_a[_i];if(bbf.Fights){fights.concat(bbf.Fights);}
else{fights.push(bbf);}}}
else{if(battle.Fights){fights.concat(battle.Fights);}
else{fights.push(battle);}}
for(var _b=0,fights_1=fights;_b<fights_1.length;_b++){var fight=fights_1[_b];for(var _c=0,_d=fight.Warriors;_c<_d.length;_c++){var warriorBlocks=_d[_c];for(var _e=0,_f=warriorBlocks.WarriorBlocks;_e<_f.length;_e++){var block=_f[_e];if(block.WarriorPower){block.WarriorPower+=shift;}}}}}}
function pregenerateBattleData(battlesMap){checkCriticalUndef(battlesMap,"pregenerateBattleData","battlesMap");for(var _i=0,_a=battlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=battlesMap.get(battleID);var zone=Zones.Zone1;if(battle.hasOwnProperty("Chapters")&&battle.Chapters[0]){zone=battle.Chapters[0].Zone;}
var faction=zone.Factions[0];if(battle.hasOwnProperty("Parent")){var parent_1=battle.Parent();battle.Parent=parent_1;if(!(parent_1.hasOwnProperty("FightWins"))){parent_1.FightWins=getFightCount(BattlesMap.get(parent_1.BattleId));}}
if(battle.hasOwnProperty("CloseAfter")){battle.CloseAfter=battle.CloseAfter();}
if(battle.Type==BattleType.MISSION){setMissionDifficulty(battle,DIFFICULTY.HARD);}
if(battle.hasOwnProperty("BattleVariants")){for(var _b=0,_c=battle.BattleVariants;_b<_c.length;_b++){var battleVariant=_c[_b];setBattleDefaultLoot(battleVariant,battle.Type,zone,faction);if(!battle.FightCount){battle.FightCount=battleVariant.FightCount;}
else{if(battle.FightCount!=battleVariant.FightCount){throw new Error("pregenerateBattleData: battle "+battle.ID+" has different fight counts in its variants.");}}}}
else{setBattleDefaultLoot(battle,battle.Type,zone,faction);}}}
setFeatureUnlocks();pregenerateBattleData(BattlesMap);function getWPSourceFromCompletedFight(currentMainBattleId,currentMainFightIndex){var prevSource=BattlesMap.checkedGet(currentMainBattleId);if(currentMainFightIndex>0){if(currentMainFightIndex>1){throw new Error("getWPSourceFromCompletedFight: currentMainFightIndex out of bounds");}
return prevSource;}
else if(prevSource.Parent){var parentBattle=BattlesMap.get(prevSource.Parent.BattleId);prevSource=!!parentBattle?parentBattle:prevSource;}
else{prevSource=BattlesMap.get(BattlesChapter1MainId.Z1_MQ_Tutorial_ShadowForm);}
return prevSource;}
function GetBattlesScheduled(){checkCriticalUndef(BattlesMap,"GetBattlesScheduled","BattlesMap");var scheduled=[];for(var _i=0,_a=BattlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=BattlesMap.get(battleID);if(battle.hasOwnProperty("Schedule")){scheduled.push(battle);}}
return scheduled;}
function GetFutureAvailableBattles(parentBattleIDs,wonFightsInBattle){checkCriticalUndef(BattlesMap,"GetFutureAvailableBattles","BattlesMap");var availableBattles=[];for(var i=0;i<parentBattleIDs.length;i++){for(var _i=0,_a=BattlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=BattlesMap.get(battleID);if(battle.Type==BattleType.MAIN||battle.Type==BattleType.SIDE){if(!battle.hasOwnProperty("Parent"))
continue;if(battle.Parent.BattleId==parentBattleIDs[i]&&battle.Parent.FightWins<=wonFightsInBattle[i]){availableBattles.push(battleID);}}}}
return availableBattles;}
function GetBattlesWithType(battleType){checkCriticalUndef(BattlesMap,"GetBattlesWithType","BattlesMap");var battles=[];for(var _i=0,_a=BattlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=BattlesMap.get(battleID);if(battle.Type==battleType){battles.push(battle);}}
return battles;}
function GetMainBattleIndex(targetBattleId){checkCriticalUndef(BattlesMap,"GetMainBattleIndex","BattlesMap");var mainBattleIndex=0;for(var _i=0,_a=BattlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=BattlesMap.get(battleID);if(battle.Type==BattleType.MAIN){if(battle.ID==targetBattleId){return mainBattleIndex;}
mainBattleIndex++;}}
return-1;}
function GetLockedFeaturesBattles(currentBattleIndex,featureIds){checkCriticalUndef(BattlesMap,"GetLockedFeaturesBattles","BattlesMap");var battles={};var battleIndex=-1;for(var _i=0,_a=BattlesMap.getKeys();_i<_a.length;_i++){var battleID=_a[_i];var battle=BattlesMap.get(battleID);if(battle.Type!=BattleType.MAIN)
continue;battleIndex++;if(!battle.hasOwnProperty("UnlockedFeatures")||!battle.UnlockedFeatures.hasOwnProperty("Mask"))
continue;if(battle.UnlockedFeatures.Mask<=0||battleIndex<currentBattleIndex)
continue;for(var _b=0,featureIds_1=featureIds;_b<featureIds_1.length;_b++){var feature=featureIds_1[_b];if((feature&battle.UnlockedFeatures.Mask)!=feature)
continue;battles[battleIndex]=battle;}}
return battles;}
var battlesWithoutSurrender=BattlesMap.getKeys().filter(function(x){return BattlesMap.get(x).RestrictSurrender;});