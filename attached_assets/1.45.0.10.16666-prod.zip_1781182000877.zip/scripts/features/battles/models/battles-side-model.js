var __extends=(this&&this.__extends)||(function(){var extendStatics=Object.setPrototypeOf||({__proto__:[]}instanceof Array&&function(d,b){d.__proto__=b;})||function(d,b){for(var p in b)if(b.hasOwnProperty(p))d[p]=b[p];};return function(d,b){extendStatics(d,b);function __(){this.constructor=d;}
d.prototype=b===null?Object.create(b):(__.prototype=b.prototype,new __());};})();var SideBattle=(function(_super){__extends(SideBattle,_super);function SideBattle(obj){var _this=_super.call(this,obj)||this;for(var key in obj)
_this[key]=obj[key];return _this;}
return SideBattle;}(StoryBattle));