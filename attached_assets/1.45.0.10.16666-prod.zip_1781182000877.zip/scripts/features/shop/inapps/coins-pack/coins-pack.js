var CoinsPack=(function(){function CoinsPack(settings){this.defaultSelection=false;for(var key in settings){this[key]=settings[key];}}
return CoinsPack;}());