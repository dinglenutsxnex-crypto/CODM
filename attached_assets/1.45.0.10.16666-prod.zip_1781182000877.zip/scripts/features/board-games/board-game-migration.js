var BoardGameForDeletion=[47];function migrateDeletedBoardGames(playerBoardGames){var deletedBoardGames=[];for(var _i=0,playerBoardGames_1=playerBoardGames;_i<playerBoardGames_1.length;_i++){var boardGameID=playerBoardGames_1[_i];if(BoardGameForDeletion.indexOf(boardGameID)!==-1){deletedBoardGames.push(boardGameID);}}
return deletedBoardGames;}
function migrateBoardGamesDates(playerBoardGames){function getEndDate(boardGame,activationTime){if(!boardGame){return-1;}
if(boardGame.EndDate){return Date.parse(boardGame.EndDate);}
if(boardGame.Duration){return activationTime+boardGame.Duration;}
return-1;}
return playerBoardGames.map(function(playerBoardGame){var boardGameID=playerBoardGame.id;var boardGame=BoardGamesMap.get(boardGameID);return{boardGameID:boardGameID,endDate:getEndDate(boardGame,playerBoardGame.activationTime)};});}