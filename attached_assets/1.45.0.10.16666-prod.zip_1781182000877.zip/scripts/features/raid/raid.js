var Raid=(function(){function Raid(settings){for(var key in settings)
this[key]=settings[key];if(this.mapType===undefined){this.mapType=MapType.Raids;}
if(QA_TOOLS&&QA_OPEN_ALL_RAID_LEVELS){this.raidLevels.forEach(function(lvl,index){if(index>0&&lvl.hasCondition==undefined){lvl.hasCondition=true;lvl.condition=function(raidPower){return true;};lvl.tooltip="";}});}}
return Raid;}());