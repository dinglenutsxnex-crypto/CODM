var QuestUpdatesLib=(function(){function QuestUpdatesLib(){}
QuestUpdatesLib.winByStyle=function(questAttributes,eventParameters,style){var weapon=ItemModelsMap.get(eventParameters["weapon_id"]);if(eventParameters["fight_result"]==FightResult.WIN&&(weapon.OverrideQuestStyle==style||weapon.Style==style)){return 1;}
return 0;};QuestUpdatesLib.entryByCollectionArray=function(questAttributes,eventParameters,collectionsIdArray,isSet){if(isSet===void 0){isSet=false;}
var itemsIdArray=[eventParameters["weapon_id"],eventParameters["armor_id"],eventParameters["helmet_id"],eventParameters["ranged_id"],];return CollectionCalculate.isFullCollectionInList(itemsIdArray,collectionsIdArray,isSet)?1:0;};QuestUpdatesLib.winByCollectionArray=function(questAttributes,eventParameters,collectionsIdArray,isSet){if(isSet===void 0){isSet=false;}
return eventParameters["fight_result"]==FightResult.WIN?this.entryByCollectionArray(questAttributes,eventParameters,collectionsIdArray,isSet):0;};QuestUpdatesLib.winByRaids=function(questAttributes,eventParameters,raidBattles){if(eventParameters["raid_result"]!=RaidResult.WIN){return 0;}
var battleId=eventParameters["battle_id"];return raidBattles.indexOf(battleId)!=-1?1:0;};QuestUpdatesLib.winByFactionsCollection=function(questAttributes,eventParameters,factions,isSet){if(isSet===void 0){isSet=false;}
if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var collectionItems=[eventParameters["weapon_id"],eventParameters["helmet_id"],eventParameters["armor_id"],eventParameters["ranged_id"]];var collection=CollectionCalculate.getCollectionByEquip(collectionItems);var result=collection&&factions.indexOf(collection.faction)!==-1&&(isSet&&!!collection.leveling||!isSet);return result?1:0;};QuestUpdatesLib.winByRaritiesCollection=function(questAttributes,eventParameters,rarities,isSet){if(isSet===void 0){isSet=false;}
if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
var collectionItems=[eventParameters["weapon_id"],eventParameters["helmet_id"],eventParameters["armor_id"],eventParameters["ranged_id"]];var collection=CollectionCalculate.getCollectionByEquip(collectionItems);var result=collection&&rarities.indexOf(collection.collectionRarity)!==-1&&(isSet&&!!collection.leveling||!isSet);return result?1:0;};QuestUpdatesLib.winByBattleTypeAndByFactionsCollectionOrWeapon=function(questAttributes,eventParameters,battleTypes,factions,points,isSet){if(isSet===void 0){isSet=false;}
if(eventParameters["fight_result"]!=FightResult.WIN){return 0;}
if(battleTypes.indexOf(BattlesMap.checkedGet(eventParameters["battle_id"]).Type)===-1){return 0;}
var result=this.winByFactionsCollection(questAttributes,eventParameters,factions)*points.fullSet;if(result==0){result=factions.indexOf(ItemModelsMap.get(eventParameters["weapon_id"]).Faction)!==-1?points.onlyWeapon:0;}
return result;};QuestUpdatesLib.winByBattleTypeAndByRaritiesCollection=function(questAttributes,eventParameters,battleTypes,rarities,points,isSet){if(isSet===void 0){isSet=false;}
if(battleTypes.indexOf(BattlesMap.checkedGet(eventParameters["battle_id"]).Type)===-1){return 0;}
var pointsByRarity=points[ItemModelsMap.get(eventParameters["weapon_id"]).Rarity];if(!pointsByRarity){return 0;}
return this.winByRaritiesCollection(questAttributes,eventParameters,rarities)*pointsByRarity;};QuestUpdatesLib.openChests=function(questAttributes,eventParameters,settings){if(!settings){return 1;}
if(settings.ids){return settings.ids.indexOf(eventParameters["chest_id"])!=-1?1:0;}
if(settings.chestTypes){var chest=ChestModelsMap.get(eventParameters["chest_id"]);if(!chest){return 0;}
else{var result=0;if(settings.chestTypes.brawler==true){result=!chest.IsQuestChest?1:0;}
if(settings.chestTypes.raid==true){result=chest.IsRaidChest?1:0;}
if(settings.chestTypes.daily==true){result=chest.IsQuestChest&&!chest.IsRaidChest?1:0;}
return result;}}
else{return 1;}};return QuestUpdatesLib;}());