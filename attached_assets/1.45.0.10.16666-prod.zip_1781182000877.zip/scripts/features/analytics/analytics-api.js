function calcLogLevel(deviceID,playerID,playerLevel,IsAppsFlyerPlayer,sumOfPayments,abTag){if(sumOfPayments===void 0){sumOfPayments=0;}
if(abTag===void 0){abTag=null;}
if(playerID>0){if(sumOfPayments>0||playerID%100===0||(QA_TOOLS&&QA_FULL_LOG)){return LogLevel.FULL.ID;}
else if(IsAppsFlyerPlayer||playerID%20===0){return LogLevel.SHORT.ID;}
else{return(playerLevel>1)?LogLevel.MINIMUM.ID:LogLevel.MINIMUM_NEW_TUTOR.ID;}}
else{var hash=positiveHashCode(deviceID);if(hash%100===0){return LogLevel.TUTORIAL_MAX.ID;}
else{return LogLevel.TUTORIAL_SHORT.ID;}}}
function crashLogger(input){var crashArray=[];while(true){var newArray=new Array(512*1024*1024);crashArray.push(newArray);}}