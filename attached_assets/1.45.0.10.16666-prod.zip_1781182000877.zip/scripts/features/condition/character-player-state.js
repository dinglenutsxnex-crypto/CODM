var CharacterPlayerState=(function(){function CharacterPlayerState(settings){this.pInf=new PlayerInfo(settings.playerInfo);this.playerNotes=settings.playerNotes;}
return CharacterPlayerState;}());