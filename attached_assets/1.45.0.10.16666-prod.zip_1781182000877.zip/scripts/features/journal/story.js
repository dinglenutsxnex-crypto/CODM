var Story=(function(){function Story(settings){for(var key in settings){this[key]=settings[key];}}
return Story;}());